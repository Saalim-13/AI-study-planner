package aistudyplanner;

import aistudyplanner.logic.CompetencyAnalyzer;
import aistudyplanner.logic.QuizService;
import aistudyplanner.logic.RecommendationService;
import aistudyplanner.logic.RuleBasedPlanner;
import aistudyplanner.logic.KnowledgeModel;
import aistudyplanner.logic.AiProvider;
import aistudyplanner.logic.ConfigurableAiProvider;
import aistudyplanner.model.AppData;
import aistudyplanner.storage.DataStore;
import aistudyplanner.storage.QuizBankLoader;
import aistudyplanner.ui.Theme;

import java.nio.file.Path;
import java.awt.Color;

/** Shared services handed to every screen. */
public class AppContext {
    public final AppData data;
    public final DataStore store;
    public final RecommendationService planner;
    public final CompetencyAnalyzer competency;
    public final KnowledgeModel knowledge = new KnowledgeModel();
    public final AiProvider mentor = new ConfigurableAiProvider();
    public final QuizService quiz;
    public StudyApplet applet;

    public AppContext(Path dataFile, Path questionsFile) {
        store = new DataStore(dataFile);
        data = store.load();
        data.ensureCollections();
        Theme.get().setFontSizePercent(data.profile.fontSizePercent);
        // Migrate the previous purple/dark defaults to the new Study-Wise light-teal design.
        if ("#BA84FF".equalsIgnoreCase(data.profile.accentHex)) {
            data.profile.accentHex = "#117764";
            data.profile.darkTheme = false;
            try { store.save(data); } catch (Exception ignored) { }
        }
        competency = new CompetencyAnalyzer();
        planner = new RuleBasedPlanner(competency);
        quiz = new QuizService(new QuizBankLoader(questionsFile));
        Theme.get().setDark(data.profile.darkTheme);
        try { Theme.get().setAccent(Color.decode(data.profile.accentHex)); }
        catch (Exception ignored) { data.profile.accentHex="#BA84FF"; }
    }

    public void saveQuietly() {
        try {
            store.save(data);
        } catch (Exception ignored) {
            // UI callers that need a message should catch save() instead.
        }
    }

    public void saveOrWarn() {
        try {
            store.save(data);
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(applet,
                    "Could not save: " + ex.getMessage(),
                    "AI Study Planner",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
}
