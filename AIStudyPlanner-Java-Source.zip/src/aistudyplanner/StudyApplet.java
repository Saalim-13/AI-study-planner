package aistudyplanner;

import aistudyplanner.model.StudySession;
import aistudyplanner.ui.Sidebar;
import aistudyplanner.ui.SlidePane;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.screens.DashboardScreen;
import aistudyplanner.ui.screens.Onboarding;
import aistudyplanner.ui.screens.PlannerScreen;
import aistudyplanner.ui.screens.PomodoroScreen;
import aistudyplanner.ui.screens.ProgressScreen;
import aistudyplanner.ui.screens.QuizScreen;
import aistudyplanner.ui.screens.MentorScreen;
import aistudyplanner.ui.screens.GoalsScreen;
import aistudyplanner.ui.screens.InsightsScreen;
import aistudyplanner.logic.DailyCheckIn;
import aistudyplanner.ui.screens.SettingsScreen;
import aistudyplanner.ui.screens.SubjectsScreen;
import aistudyplanner.ui.screens.UploadMaterialScreen;
import aistudyplanner.ui.screens.RevisionNotesScreen;
import aistudyplanner.ui.screens.DailyPracticeScreen;
import aistudyplanner.ui.screens.MentorChatDialog;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.util.TimeFmt;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLayeredPane;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.nio.file.Path;

/**
 * Applet-style application root.
 * <p>
 * Real {@code javax.swing.JApplet} was removed in JDK 17, so this panel
 * keeps the same lifecycle: {@code init()}, {@code start()}, {@code stop()},
 * {@code destroy()}. {@link Main} hosts it inside a JFrame. On JDK 8 you
 * could wrap the same class with appletviewer using {@code StudyApplet.html}.
 */
public class StudyApplet extends JPanel {
    public AppContext ctx;
    public String focusSubject = "General";
    public String focusTopic = "";
    public int remaining;
    public int planned;
    public boolean running;
    public boolean breakMode;
    public int completedPomodoros;
    public JLabel clockLabel;
    public boolean ready;

    private Sidebar sidebar;
    private SlidePane slides;
    private Timer ticker;
    private long lastTick;
    private String screen = "Dashboard";
    private java.time.LocalDateTime sessionStartedAt;
    private Timer reminderTicker;
    private String lastReminderKey = "";

    public StudyApplet() {
        super(new BorderLayout());
        setOpaque(false);
    }

    /** Build UI and load saved data. Return false if the user cancelled onboarding. */
    public void init() {
        Path root = Path.of("").toAbsolutePath();
        init(new AppContext(root.resolve("data").resolve("planner.dat"),
                root.resolve("data").resolve("questions.csv")));
    }

    /** Build the Swing interface using a context loaded while the startup splash is visible. */
    public void init(AppContext loadedContext) {
        ctx = loadedContext;
        ctx.applet = this;
        if (!Onboarding.run(ctx)) {
            ready = false;
            return;
        }
        DailyCheckIn.run(ctx);
        ready = true;

        sidebar = new Sidebar(ctx, this::showScreen, this::toggleTheme);
        slides = new SlidePane();
        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.add(new AssistantLayer(slides, () -> MentorChatDialog.show(ctx)), BorderLayout.CENTER);
        center.setBorder(javax.swing.BorderFactory.createEmptyBorder());

        add(sidebar, BorderLayout.WEST);
        add(center, BorderLayout.CENTER);

        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("SPACE"), "pomodoro");
        getActionMap().put("pomodoro", new javax.swing.AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if (running) {
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control N"), "newTask");
        getActionMap().put("newTask", new javax.swing.AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                showScreen("Planner");
                PlannerScreen.quickAdd(ctx);
            }
        });
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control Q"), "openQuiz");
        getActionMap().put("openQuiz", new javax.swing.AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) { showScreen("Quiz"); }
        });
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control P"), "openPomodoro");
        getActionMap().put("openPomodoro", new javax.swing.AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) { showScreen("Pomodoro"); }
        });
        applyThemePaint();
        showScreen("Dashboard");
        reminderTicker = new Timer(30000, e -> checkReminder());
        reminderTicker.start();
    }

    public void start() {
        // Applet lifecycle hook: window is showing.
    }

    public void stop() {
        pauseTimer();
        if (ctx != null) {
            ctx.saveQuietly();
        }
    }

    public void destroy() {
        if (ticker != null) {
            ticker.stop();
        }
        if (ctx != null) {
            ctx.saveQuietly();
        }
        if (reminderTicker != null) reminderTicker.stop();
    }

    public void showScreen(String name) {
        screen = name;
        if (sidebar != null) {
            sidebar.setActive(name);
        }
        JPanel next;
        switch (name) {
            case "Planner":
            case "Study Planner":
                next = PlannerScreen.build(ctx);
                break;
            case "Subjects":
                next = SubjectsScreen.build(ctx);
                break;
            case "Upload Material":
                next = UploadMaterialScreen.build(ctx);
                break;
            case "Daily Quiz":
                next = QuizScreen.buildDailyPractice(ctx);
                break;
            case "Quiz":
            case "Quiz Center":
                next = QuizScreen.build(ctx);
                break;
            case "Mentor":
            case "AI Mentor":
                next = MentorScreen.build(ctx);
                break;
            case "Goals":
            case "Goals & Readiness":
                next = GoalsScreen.build(ctx);
                break;
            case "Insights":
            case "Weekly Insights":
                next = InsightsScreen.build(ctx);
                break;
            case "Progress":
            case "Progress & Weak Areas":
                next = ProgressScreen.build(ctx);
                break;
            case "Pomodoro":
            case "Timer":
                next = PomodoroScreen.build(ctx);
                break;
            case "Revision Notes":
                next = RevisionNotesScreen.build(ctx);
                break;
            case "Current Affairs / Daily Practice":
                next = DailyPracticeScreen.build(ctx);
                break;
            case "Settings":
                next = SettingsScreen.build(ctx);
                break;
            default:
                next = DashboardScreen.build(ctx);
                break;
        }
        installTooltips(next);
        slides.showPanel(next);
    }

    private void installTooltips(java.awt.Container container) {
        for (java.awt.Component component : container.getComponents()) {
            if (component instanceof javax.swing.AbstractButton) {
                javax.swing.AbstractButton button=(javax.swing.AbstractButton)component;
                if (button.getToolTipText()==null || button.getToolTipText().isBlank())
                    button.setToolTipText(button.getText()==null?"Click to activate":button.getText());
            }
            if (component instanceof java.awt.Container) installTooltips((java.awt.Container)component);
        }
    }

    private void checkReminder() {
        if (ctx==null || ctx.data.profile.reminderTime==null) return;
        String now=java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
        String key=java.time.LocalDate.now()+" "+now;
        if(now.equals(ctx.data.profile.reminderTime) && !key.equals(lastReminderKey)) {
            lastReminderKey=key;
            if(ctx.data.profile.soundEnabled) java.awt.Toolkit.getDefaultToolkit().beep();
            JOptionPane.showMessageDialog(this,"A gentle nudge from your study plan: take a short focus block or review a due topic.","Study reminder",JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void refreshTheme() { applyThemePaint(); if(sidebar!=null)sidebar.refreshTheme(); repaint(); }

    public void toggleTheme() {
        Theme.get().toggle();
        try { Theme.get().setAccent(java.awt.Color.decode(ctx.data.profile.accentHex)); } catch (Exception ignored) { }
        ctx.data.profile.darkTheme = Theme.get().dark;
        ctx.saveQuietly();
        applyThemePaint();
        sidebar.refreshTheme();
        showScreen(screen);
    }

    private void applyThemePaint() {
        setBackground(Theme.get().bg);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(Theme.get().bg);
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.dispose();
        super.paintComponent(g);
    }

    public void startTimer() {
        if (running) {
            return;
        }
        if (remaining <= 0) {
            remaining = ctx.data.profile.focusMinutes * 60;
            planned = remaining;
        }
        if (!breakMode && sessionStartedAt == null) sessionStartedAt = java.time.LocalDateTime.now();
        running = true;
        lastTick = System.currentTimeMillis();
        if (ticker == null) {
            ticker = new Timer(250, e -> tick());
        }
        ticker.start();
    }

    public void pauseTimer() {
        if (!running) {
            return;
        }
        tick();
        running = false;
        if (ticker != null) {
            ticker.stop();
        }
    }

    public void resetTimer() {
        if (ticker != null) {
            ticker.stop();
        }
        running = false;
        remaining = 0;
        planned = 0;
        sessionStartedAt = null;
    }

    public void skipBlock() {
        if (running) {
            pauseTimer();
        }
        if (!breakMode && planned > 0) {
            record(false);
        }
        remaining = 0;
        planned = 0;
        breakMode = false;
        sessionStartedAt = null;
    }

    public void startBreak() {
        if (ticker != null) {
            ticker.stop();
        }
        running = false;
        breakMode = true;
        remaining = ctx.data.profile.breakMinutes * 60;
        planned = remaining;
    }

    private void tick() {
        long now = System.currentTimeMillis();
        remaining = Math.max(0, remaining - (int) ((now - lastTick) / 1000));
        lastTick = now;
        if (clockLabel != null) {
            clockLabel.setText(TimeFmt.clock(remaining));
        }
        repaint();
        if (remaining == 0 && running) {
            running = false;
            if (ticker != null) {
                ticker.stop();
            }
            if (!breakMode) {
                if (ctx.data.profile.soundEnabled) java.awt.Toolkit.getDefaultToolkit().beep();
                record(true);
                completedPomodoros++;
                JOptionPane.showMessageDialog(this, "Focus complete. Time for a short break.");
                if (ctx.data.profile.autoBreak) {
                    startBreak();
                    startTimer();
                }
            } else {
                breakMode = false;
                JOptionPane.showMessageDialog(this, "Break complete. Ready when you are.");
                remaining = 0;
                planned = 0;
            }
            if ("Pomodoro".equals(screen)) {
                showScreen("Pomodoro");
            }
        }
    }

    private void record(boolean complete) {
        int actual = complete ? planned / 60 : Math.max(0, planned / 60 - remaining / 60);
        if (actual > 0) {
            java.time.LocalDateTime began=sessionStartedAt == null ? java.time.LocalDateTime.now() : sessionStartedAt;
            ctx.data.sessions.add(new StudySession(focusSubject, focusTopic, planned / 60, actual, complete, began));
            ctx.knowledge.recordStudy(ctx.data,focusSubject,focusTopic,began.toLocalDate());
            ctx.saveQuietly();
        }
        sessionStartedAt = null;
    }

    public void attachClosing(JFrame frame) {
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                destroy();
                frame.dispose();
            }
        });
    }

    /** Keeps the mentor shortcut visible above every screen and its scroll content. */
    private static final class AssistantLayer extends JLayeredPane {
        private final SlidePane content;
        private final AccentButton mentor = AccentButton.primary("✦  Ask your mentor");

        AssistantLayer(SlidePane content, Runnable openMentor) {
            this.content = content;
            setOpaque(false);
            mentor.setToolTipText("Open a resizable study mentor chat without leaving this screen");
            mentor.setPreferredSize(new Dimension(190, 44));
            mentor.addActionListener(e -> openMentor.run());
            add(content, Integer.valueOf(DEFAULT_LAYER));
            add(mentor, Integer.valueOf(PALETTE_LAYER));
        }

        @Override public void doLayout() {
            content.setBounds(0, 0, getWidth(), getHeight());
            Dimension size = mentor.getPreferredSize();
            mentor.setBounds(Math.max(16, getWidth() - size.width - 24),
                    Math.max(16, getHeight() - size.height - 22), size.width, size.height);
        }
    }
}
