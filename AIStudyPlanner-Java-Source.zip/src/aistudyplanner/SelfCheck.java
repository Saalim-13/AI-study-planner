package aistudyplanner;

import aistudyplanner.logic.KnowledgeModel;

/** Small dependency-free checks for core adaptive-learning math and schedule insertion. */
public final class SelfCheck {
    private SelfCheck() { }
    public static void main(String[] args) {
        check("SM-2 intervals and reset after a missed answer", KnowledgeModel.selfCheckSm2());
        check("Mastery rises on recall and falls on a miss", KnowledgeModel.selfCheckMasteryUpdate());
        check("Due topic is inserted into generated schedule", KnowledgeModel.selfCheckScheduler());
        System.out.println("Adaptive learning self-checks passed.");
    }
    private static void check(String name, boolean success) {
        if (!success) throw new IllegalStateException("Self-check failed: " + name);
        System.out.println("PASS: " + name);
    }
}
