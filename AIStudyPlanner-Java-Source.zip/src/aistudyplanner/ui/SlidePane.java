package aistudyplanner.ui;

import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/** Fades and slides the next screen in using a Swing Timer. */
public class SlidePane extends JPanel {
    private JPanel current = new JPanel(new BorderLayout());
    private BufferedImage outgoing;
    private float progress = 1f;
    private Timer timer;

    public SlidePane() {
        super(new BorderLayout());
        setOpaque(false);
        current.setOpaque(false);
        add(current, BorderLayout.CENTER);
    }

    public void showPanel(JPanel next) {
        if (getWidth() > 0 && getHeight() > 0 && current.getWidth() > 0) {
            outgoing = new BufferedImage(Math.max(1, getWidth()), Math.max(1, getHeight()), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = outgoing.createGraphics();
            current.paint(g2);
            g2.dispose();
        }
        removeAll();
        current = next;
        current.setOpaque(false);
        add(current, BorderLayout.CENTER);
        progress = 0f;
        if (timer != null) {
            timer.stop();
        }
        timer = new Timer(16, e -> {
            progress = Math.min(1f, progress + 0.08f);
            revalidate();
            repaint();
            if (progress >= 1f) {
                ((Timer) e.getSource()).stop();
                outgoing = null;
            }
        });
        timer.start();
        revalidate();
        repaint();
    }

    @Override
    protected void paintChildren(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        int w = getWidth();
        int offset = (int) ((1f - progress) * 48);
        g2.translate(offset, 0);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, progress));
        super.paintChildren(g2);
        g2.dispose();
        if (outgoing != null && progress < 1f) {
            Graphics2D old = (Graphics2D) g.create();
            old.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f - progress));
            old.drawImage(outgoing, (int) (-progress * 40), 0, null);
            old.dispose();
        }
        // silence unused warning on w in some compilers
        if (w < 0) {
            return;
        }
    }
}
