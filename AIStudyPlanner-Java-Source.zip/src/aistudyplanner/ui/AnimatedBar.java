package aistudyplanner.ui;

import javax.swing.JComponent;
import javax.swing.Timer;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class AnimatedBar extends JComponent {
    private float shown;
    private float target;
    private String text = "";
    private final Timer animator;

    public AnimatedBar() {
        setOpaque(false);
        setPreferredSize(new Dimension(200, 28));
        animator = new Timer(16, e -> {
            float diff = target - shown;
            if (Math.abs(diff) < 0.004f) {
                shown = target;
                ((Timer) e.getSource()).stop();
            } else {
                shown += diff * 0.14f;
            }
            repaint();
        });
    }

    public void setProgress(float value, String text) {
        this.target = Math.max(0f, Math.min(1f, value));
        this.text = text;
        if (!animator.isRunning()) {
            animator.start();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        Theme theme = Theme.get();
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int h = 12;
        int y = (getHeight() - h) / 2;
        g2.setColor(theme.cardAlt);
        g2.fillRoundRect(0, y, getWidth(), h, h, h);
        g2.setColor(theme.accent);
        g2.fillRoundRect(0, y, Math.max(h, (int) (getWidth() * shown)), h, h, h);
        g2.setFont(theme.smallFont);
        g2.setColor(theme.muted);
        g2.drawString(text, 0, y - 2);
        g2.dispose();
    }
}
