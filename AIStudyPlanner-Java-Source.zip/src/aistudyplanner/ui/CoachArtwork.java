package aistudyplanner.ui;

import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

/** A scalable, dependency-free Java2D study illustration used as in-app artwork. */
public final class CoachArtwork extends JPanel {
    public CoachArtwork() {
        setOpaque(false);
        setPreferredSize(new Dimension(240, 150));
        setMinimumSize(new Dimension(150, 110));
        setToolTipText("Study Flow mentor artwork, drawn with Java2D");
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        double scale = Math.min(getWidth() / 240.0, getHeight() / 150.0);
        g.translate((getWidth() - 240 * scale) / 2, (getHeight() - 150 * scale) / 2);
        g.scale(scale, scale);

        // Soft orbital backdrop and floating progress bubbles.
        g.setColor(new Color(255, 255, 255, 24));
        g.fill(new Ellipse2D.Double(91, 3, 140, 140));
        g.setColor(new Color(255, 255, 255, 35));
        g.fill(new Ellipse2D.Double(118, 17, 94, 94));
        g.setColor(new Color(102, 234, 207));
        g.fill(new Ellipse2D.Double(196, 18, 10, 10));
        g.setColor(new Color(255, 205, 111));
        g.fill(new Ellipse2D.Double(112, 38, 7, 7));

        // Open book, built from rounded pages and a highlighted center fold.
        g.setColor(new Color(24, 22, 55, 50));
        g.fillRoundRect(40, 108, 150, 17, 8, 8);
        g.setPaint(new GradientPaint(48, 52, new Color(255, 255, 255), 119, 113, new Color(220, 215, 255)));
        g.fill(new RoundRectangle2D.Double(40, 43, 77, 69, 12, 12));
        g.setPaint(new GradientPaint(119, 46, new Color(255, 255, 255), 190, 112, new Color(204, 245, 238)));
        g.fill(new RoundRectangle2D.Double(119, 43, 72, 69, 12, 12));
        Color tealLine = Theme.get().accent;
        g.setColor(new Color(tealLine.getRed(), tealLine.getGreen(), tealLine.getBlue(), 115));
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawLine(119, 51, 119, 106);
        for (int i = 0; i < 3; i++) {
            g.drawLine(55, 66 + i * 12, 101, 66 + i * 12);
            g.drawLine(135, 66 + i * 12, 175, 66 + i * 12);
        }

        // Rising mastery mark and spark.
        g.setColor(Theme.get().accent);
        g.setStroke(new BasicStroke(4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawPolyline(new int[]{147, 160, 170, 185}, new int[]{37, 29, 33, 16}, 4);
        g.fillOval(180, 11, 10, 10);
        g.setColor(new Color(255, 201, 104));
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawLine(211, 44, 211, 57);
        g.drawLine(205, 50, 218, 50);
        g.dispose();
    }
}
