package aistudyplanner.ui;

import javax.swing.JComponent;
import javax.swing.Timer;
import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/** Circular progress that eases toward a target value. */
public class ProgressRing extends JComponent {
    private float shown;
    private float target;
    private String caption = "";
    private final Timer animator;

    public ProgressRing() {
        setOpaque(false);
        setPreferredSize(new Dimension(160, 160));
        animator = new Timer(16, e -> {
            float diff = target - shown;
            if (Math.abs(diff) < 0.004f) {
                shown = target;
                ((Timer) e.getSource()).stop();
            } else {
                shown += diff * 0.12f;
            }
            repaint();
        });
    }

    public void setProgress(float value, String caption) {
        this.target = Math.max(0f, Math.min(1f, value));
        this.caption = caption;
        if (!animator.isRunning()) {
            animator.start();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        Theme theme = Theme.get();
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int size = Math.min(getWidth(), getHeight()) - 16;
        int x = (getWidth() - size) / 2;
        int y = (getHeight() - size) / 2;
        g2.setStroke(new BasicStroke(12f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.setColor(theme.cardAlt);
        g2.drawArc(x, y, size, size, 90, -360);
        g2.setColor(theme.accent);
        g2.drawArc(x, y, size, size, 90, (int) (-360 * shown));
        g2.setColor(theme.text);
        g2.setFont(theme.headingFont);
        String pct = Math.round(shown * 100) + "%";
        int tw = g2.getFontMetrics().stringWidth(pct);
        g2.drawString(pct, getWidth() / 2 - tw / 2, getHeight() / 2);
        g2.setFont(theme.smallFont);
        g2.setColor(theme.muted);
        int cw = g2.getFontMetrics().stringWidth(caption);
        g2.drawString(caption, getWidth() / 2 - cw / 2, getHeight() / 2 + 18);
        g2.dispose();
    }
}
