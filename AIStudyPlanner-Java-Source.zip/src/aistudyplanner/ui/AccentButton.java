package aistudyplanner.ui;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Rounded primary/secondary button with subtle hover feedback. */
public class AccentButton extends JButton {
    private boolean hover;
    private boolean filled;

    public AccentButton(String text, boolean filled) {
        super(text);
        this.filled = filled;
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setFont(Theme.get().bodyFont.deriveFont(java.awt.Font.BOLD, 14f));
        setToolTipText(text);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hover = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hover = false;
                repaint();
            }
        });
    }

    public static AccentButton primary(String text) {
        return new AccentButton(text, true);
    }

    public static AccentButton ghost(String text) {
        return new AccentButton(text, false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Theme theme = Theme.get();
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Color fill = filled ? theme.accent : (hover ? theme.accentSoft : theme.card);
        if (filled && hover) fill = fill.brighter();
        int w = getWidth(), h = getHeight();
        g2.setColor(theme.shadow);
        g2.fillRoundRect(2, 3, Math.max(0, w - 4), Math.max(0, h - 5), 16, 16);
        g2.setColor(fill);
        g2.fillRoundRect(0, 0, Math.max(0, w - 2), Math.max(0, h - 3), 16, 16);
        if (!filled) {
            g2.setColor(hover ? theme.accent : new Color(theme.accent.getRed(), theme.accent.getGreen(), theme.accent.getBlue(), 75));
            g2.drawRoundRect(0, 0, Math.max(0, w - 3), Math.max(0, h - 4), 16, 16);
        }
        g2.dispose();
        Color old = getForeground();
        setForeground(filled ? Color.WHITE : theme.text);
        super.paintComponent(g);
        setForeground(old);
    }
}
