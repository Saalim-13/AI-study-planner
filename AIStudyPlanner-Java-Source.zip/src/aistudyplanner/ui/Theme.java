package aistudyplanner.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.ArrayList;
import java.util.List;

/**
 * All colors, fonts and radii live here so the look can be changed in one file.
 * Screens should never hard-code a Color or Font.
 */
public class Theme {
    private static final Theme INSTANCE = new Theme();

    public boolean dark = false;
    public Color bg;
    public Color sidebar;
    public Color card;
    public Color cardAlt;
    public Color accent;
    public Color accentSoft;
    public Color text;
    public Color muted;
    public Color danger;
    public Color success;
    public Color headerTop;
    public Color headerBottom;
    public Color shadow;
    public Color retroPaper;
    public Color retroEdge;
    public Color retroHighlight;
    public Color retroShadow;
    public Font titleFont;
    public Font headingFont;
    public Font bodyFont;
    public Font smallFont;
    public int radius = 18;
    public int pad = 16;
    private int fontSizePercent = 100;

    private final List<Runnable> listeners = new ArrayList<>();

    private Theme() {
        pickFonts();
        applyLight();
    }

    public static Theme get() {
        return INSTANCE;
    }

    public void toggle() {
        setDark(!dark);
    }

    public void setDark(boolean value) {
        dark = value;
        if (dark) {
            applyDark();
        } else {
            applyLight();
        }
        for (Runnable listener : listeners) {
            listener.run();
        }
    }

    public void onChange(Runnable listener) {
        listeners.add(listener);
    }

    public void setAccent(Color color) {
        accent = color;
        accentSoft = new Color(color.getRed(), color.getGreen(), color.getBlue(), dark ? 58 : 38);
        for (Runnable listener : listeners) listener.run();
    }

    public void setFontSizePercent(int percent) {
        fontSizePercent = Math.max(85, Math.min(130, percent));
        pickFonts();
        for (Runnable listener : listeners) listener.run();
    }

    private void applyDark() {
        bg = new Color(14, 19, 39);
        sidebar = new Color(19, 22, 48);
        card = new Color(30, 37, 70);
        cardAlt = new Color(39, 47, 83);
        accent = new Color(135, 117, 255);
        accentSoft = new Color(108, 95, 238, 66);
        text = new Color(240, 244, 255);
        muted = new Color(154, 162, 190);
        danger = new Color(255, 122, 140);
        success = new Color(92, 235, 197);
        headerTop = new Color(54, 76, 160);
        headerBottom = new Color(25, 31, 68);
        shadow = new Color(8, 4, 24, 115);
        retroPaper = new Color(48, 45, 67);
        retroEdge = new Color(225, 184, 95);
        retroHighlight = new Color(255, 235, 174);
        retroShadow = new Color(11, 12, 27);
    }

    private void applyLight() {
        bg = new Color(243, 242, 249);
        sidebar = new Color(255, 255, 255);
        card = new Color(255, 255, 255);
        cardAlt = new Color(241, 247, 246);
        accent = new Color(17, 119, 100);
        accentSoft = new Color(203, 243, 231);
        text = new Color(29, 37, 50);
        muted = new Color(105, 123, 143);
        danger = new Color(191, 74, 81);
        success = new Color(20, 137, 111);
        headerTop = new Color(243, 242, 249);
        headerBottom = new Color(243, 242, 249);
        shadow = new Color(32, 45, 66, 18);
        retroPaper = new Color(250, 246, 231);
        retroEdge = new Color(142, 104, 50);
        retroHighlight = new Color(255, 255, 242);
        retroShadow = new Color(103, 77, 42);
    }

    /** One clean, modern font family across navigation, cards, titles, and controls. */
    private void pickFonts() {
        String[] available = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        String family = findFont(available,
                new String[]{"Segoe UI", "Inter", "Poppins", "Arial"}, "SansSerif");
        titleFont = new Font(family, Font.BOLD, scaled(29));
        headingFont = new Font(family, Font.BOLD, scaled(18));
        bodyFont = new Font(family, Font.PLAIN, scaled(14));
        smallFont = new Font(family, Font.PLAIN, scaled(12));
    }

    private int scaled(int size) { return Math.max(10, Math.round(size * fontSizePercent / 100f)); }

    private static String findFont(String[] available, String[] preferred, String fallback) {
        for (String want : preferred) {
            for (String have : available) {
                if (have.equalsIgnoreCase(want)) return have;
            }
        }
        return fallback;
    }
}
