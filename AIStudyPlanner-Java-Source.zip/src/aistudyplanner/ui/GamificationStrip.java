package aistudyplanner.ui;

import aistudyplanner.logic.GamificationService;
import aistudyplanner.model.AppData;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;

/** XP meter and medal badges painted with Java2D. */
public final class GamificationStrip extends JPanel {
    private final AppData data;
    public GamificationStrip(AppData data) { this.data=data;setOpaque(false);setPreferredSize(new Dimension(300,78));setToolTipText(""); }
    @Override public String getToolTipText(MouseEvent e) {
        int index=(e.getX()-250)/58;
        return index>=0&&index<data.badges.size()?data.badges.get(index):"No badge earned here yet";
    }
    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);Theme t=Theme.get();Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        x.setColor(t.text);x.setFont(t.headingFont.deriveFont(Font.BOLD,15f));x.drawString("LEVEL "+GamificationService.level(data.xp),12,22);
        x.setFont(t.smallFont);x.setColor(t.muted);x.drawString(data.xp+" XP total  •  "+GamificationService.progressInLevel(data.xp)+" / 100 to next level",12,43);
        x.setColor(t.cardAlt);x.fillRoundRect(12,52,210,10,10,10);x.setPaint(new GradientPaint(12,52,t.accent,222,62,t.success));x.fillRoundRect(12,52,(int)(210*GamificationService.progressInLevel(data.xp)/100.0),10,10,10);
        x.setFont(t.smallFont);x.setColor(t.muted);x.drawString("BADGES",248,22);
        int show=Math.min(4,data.badges.size());
        for(int i=0;i<4;i++){int cx=267+i*44,cy=53,r=15;x.setColor(i<show?new Color(255,198,88):t.cardAlt);x.fillOval(cx-r,cy-r,2*r,2*r);if(i<show){Path2D star=new Path2D.Double();for(int j=0;j<10;j++){double a=-Math.PI/2+j*Math.PI/5,rr=j%2==0?11:5,px=cx+rr*Math.cos(a),py=cy+rr*Math.sin(a);if(j==0)star.moveTo(px,py);else star.lineTo(px,py);}star.closePath();x.setColor(new Color(105,64,163));x.fill(star);}else{x.setColor(t.muted);x.drawOval(cx-3,cy-3,6,6);}}
        x.dispose();
    }
}
