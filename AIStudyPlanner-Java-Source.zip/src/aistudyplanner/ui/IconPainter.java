package aistudyplanner.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;

/** Vector nav icons so the app does not need image files. */
public final class IconPainter {
    public enum Kind {
        DASHBOARD, PLANNER, SUBJECTS, QUIZ, PROGRESS, GOAL, INSIGHTS, POMODORO, MENTOR, SETTINGS, SUN, MOON
    }

    private IconPainter() {
    }

    public static void paint(Graphics2D g, Kind kind, int x, int y, int size, Color color) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(Math.max(1.6f, size / 12f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        int s = size;
        switch (kind) {
            case DASHBOARD:
                g2.draw(new RoundRectangle2D.Float(x, y, s * 0.42f, s * 0.42f, 4, 4));
                g2.draw(new RoundRectangle2D.Float(x + s * 0.55f, y, s * 0.42f, s * 0.28f, 4, 4));
                g2.draw(new RoundRectangle2D.Float(x, y + s * 0.55f, s * 0.42f, s * 0.42f, 4, 4));
                g2.draw(new RoundRectangle2D.Float(x + s * 0.55f, y + s * 0.42f, s * 0.42f, s * 0.55f, 4, 4));
                break;
            case PLANNER:
                g2.drawRoundRect(x, y + 3, s, s - 3, 5, 5);
                g2.drawLine(x, y + s / 3, x + s, y + s / 3);
                g2.drawLine(x + s / 3, y, x + s / 3, y + 8);
                g2.drawLine(x + 2 * s / 3, y, x + 2 * s / 3, y + 8);
                break;
            case SUBJECTS:
                g2.drawRoundRect(x + 2, y + 2, s - 4, s - 4, 6, 6);
                g2.drawLine(x + 7, y + s / 3, x + s - 7, y + s / 3);
                g2.drawLine(x + 7, y + s / 2, x + s - 7, y + s / 2);
                g2.drawLine(x + 7, y + 2 * s / 3, x + s - 10, y + 2 * s / 3);
                break;
            case QUIZ:
                g2.drawOval(x + 1, y + 1, s - 2, s - 2);
                g2.drawArc(x + s / 4, y + s / 5, s / 2, s / 2, 200, 220);
                g2.fillOval(x + s / 2 - 2, y + s - 8, 4, 4);
                break;
            case PROGRESS:
                g2.drawLine(x, y + s, x + s, y + s);
                g2.drawLine(x, y + s, x, y);
                g2.drawPolyline(
                        new int[]{x + 3, x + s / 3, x + s / 2, x + s - 2},
                        new int[]{y + 2 * s / 3, y + s / 2, y + s / 3, y + 6},
                        4);
                break;
            case GOAL:
                g2.drawOval(x+1,y+1,s-2,s-2);g2.drawOval(x+s/4,y+s/4,s/2,s/2);g2.fillOval(x+s/2-2,y+s/2-2,4,4);
                break;
            case INSIGHTS:
                g2.drawRoundRect(x+2,y+2,s-4,s-4,5,5);g2.drawLine(x+6,y+s-5,x+6,y+s/2);g2.drawLine(x+s/2,y+s-5,x+s/2,y+s/3);g2.drawLine(x+s-6,y+s-5,x+s-6,y+5);
                break;
            case POMODORO:
                g2.drawOval(x + 2, y + 4, s - 4, s - 6);
                g2.drawLine(x + s / 2, y + 4, x + s / 2, y);
                g2.drawLine(x + s / 2, y + 4 + (s - 6) / 2, x + s - 6, y + s / 3);
                break;
            case SETTINGS:
                g2.drawOval(x + s / 3, y + s / 3, s / 3, s / 3);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    int x1 = x + s / 2 + (int) (Math.cos(a) * s * 0.28);
                    int y1 = y + s / 2 + (int) (Math.sin(a) * s * 0.28);
                    int x2 = x + s / 2 + (int) (Math.cos(a) * s * 0.46);
                    int y2 = y + s / 2 + (int) (Math.sin(a) * s * 0.46);
                    g2.drawLine(x1, y1, x2, y2);
                }
                break;
            case MENTOR:
                g2.drawRoundRect(x + 2, y + 2, s - 4, s - 6, 6, 6);
                g2.drawLine(x + 6, y + s - 3, x + 4, y + s + 2);
                g2.drawLine(x + 6, y + s / 3, x + s - 6, y + s / 3);
                g2.drawLine(x + 6, y + 2 * s / 3, x + s - 6, y + 2 * s / 3);
                break;
            case SUN:
                g2.drawOval(x + s / 4, y + s / 4, s / 2, s / 2);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    g2.drawLine(
                            x + s / 2 + (int) (Math.cos(a) * s * 0.32),
                            y + s / 2 + (int) (Math.sin(a) * s * 0.32),
                            x + s / 2 + (int) (Math.cos(a) * s * 0.48),
                            y + s / 2 + (int) (Math.sin(a) * s * 0.48));
                }
                break;
            case MOON:
                g2.drawArc(x + 2, y + 2, s - 4, s - 4, 40, 280);
                break;
            default:
                break;
        }
        g2.dispose();
    }
}
