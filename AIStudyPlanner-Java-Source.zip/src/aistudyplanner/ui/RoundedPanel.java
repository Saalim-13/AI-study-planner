package aistudyplanner.ui;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.Color;
import java.awt.RenderingHints;

/** Card with a soft drop shadow and rounded corners. */
public class RoundedPanel extends JPanel {
    private Color fillColor;
    public RoundedPanel() {
        this(null);
    }

    public RoundedPanel(LayoutManager layout) {
        super(layout);
        setOpaque(false);
    }

    public void setFillColor(Color color) {
        fillColor = color;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Theme theme = Theme.get();
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(theme.shadow);
        g2.fillRoundRect(3, 5, getWidth() - 7, getHeight() - 7, theme.radius, theme.radius);
        g2.setColor(fillColor == null ? theme.card : fillColor);
        g2.fillRoundRect(0, 0, getWidth() - 6, getHeight() - 8, theme.radius, theme.radius);
        g2.dispose();
        super.paintComponent(g);
    }
}
