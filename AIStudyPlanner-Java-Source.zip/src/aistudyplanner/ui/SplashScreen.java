package aistudyplanner.ui;

import javax.swing.*;
import java.awt.*;

/** Brief Java2D splash animation shown while the local data profile is loaded. */
public final class SplashScreen {
    private SplashScreen() { }
    public static SplashHandle open() {
        JWindow window=new JWindow();
        JPanel art=new JPanel(){long began=System.currentTimeMillis();protected void paintComponent(Graphics g){Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);x.setPaint(new GradientPaint(0,0,new Color(44,25,88),getWidth(),getHeight(),new Color(16,22,51)));x.fillRect(0,0,getWidth(),getHeight());int cx=getWidth()/2,cy=getHeight()/2-14;double phase=(System.currentTimeMillis()-began)/220.0;for(int i=0;i<3;i++){int r=30+i*18+(int)(5*Math.sin(phase+i));x.setColor(new Color(180,130,255,150-i*30));x.setStroke(new BasicStroke(2.2f));x.drawOval(cx-r,cy-r,2*r,2*r);}x.setColor(new Color(255,213,127));x.fillOval(cx-13,cy-13,26,26);x.setFont(Theme.get().headingFont.deriveFont(Font.BOLD,22f));x.setColor(Color.WHITE);String title="AI STUDY PLANNER";x.drawString(title,cx-x.getFontMetrics().stringWidth(title)/2,cy+82);x.setFont(Theme.get().bodyFont.deriveFont(13f));x.setColor(new Color(203,203,231));String line="Preparing your learning space…";x.drawString(line,cx-x.getFontMetrics().stringWidth(line)/2,cy+110);x.dispose();}};
        art.setPreferredSize(new Dimension(450,290));window.setContentPane(art);window.pack();window.setLocationRelativeTo(null);window.setVisible(true);
        Timer animation=new Timer(35,e->art.repaint());animation.start();
        return new SplashHandle(window,animation);
    }

    public static final class SplashHandle {
        private final JWindow window;private final Timer animation;
        private SplashHandle(JWindow window,Timer animation){this.window=window;this.animation=animation;}
        public void close(){animation.stop();window.dispose();}
    }
}

