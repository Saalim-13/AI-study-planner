package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.Subject;
import aistudyplanner.model.Topic;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.ProgressRing;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Local mastery-based goal and study-time scenario estimator. */
public final class GoalsScreen {
    private GoalsScreen() { }
    public static JPanel build(AppContext ctx) {
        Theme theme=Theme.get();JPanel page=Ui.page("Goal & What-if Simulator","Set your exam target and explore a study-time scenario using your current topic mastery.");
        JPanel form=new JPanel(new GridLayout(0,2,10,10));form.setOpaque(false);
        JTextField date=new JTextField((ctx.data.profile.targetExamDate==null?LocalDate.now().plusWeeks(4):ctx.data.profile.targetExamDate).toString());
        JSpinner target=new JSpinner(new SpinnerNumberModel(ctx.data.profile.targetScore,1,100,1));
        form.add(Ui.label("Target exam date (YYYY-MM-DD)",theme.bodyFont,theme.text));form.add(date);
        form.add(Ui.label("Target score (%)",theme.bodyFont,theme.text));form.add(target);
        JSlider extra=new JSlider(0,180,0);extra.setMajorTickSpacing(60);extra.setMinorTickSpacing(15);extra.setPaintTicks(true);extra.setPaintLabels(true);
        RoundedPanel meter=Ui.card();meter.setLayout(new BorderLayout(12,8));ProgressRing ring=new ProgressRing();ring.setPreferredSize(new Dimension(170,170));
        JLabel details=Ui.label("",theme.bodyFont,theme.text);meter.add(ring,BorderLayout.WEST);meter.add(details,BorderLayout.CENTER);
        JLabel sliderLabel=Ui.label("Extra study time per day: 0 minutes",theme.bodyFont,theme.text);
        AccentButton save=AccentButton.primary("Save goal");
        Runnable refresh=()->{LocalDate exam=parseDate(date.getText());int score=estimatedScore(ctx);int days=(int)Math.max(0,ChronoUnit.DAYS.between(LocalDate.now(),exam));int scenario=(int)Math.min(100,score+Math.min(15,extra.getValue()*Math.max(1,days)/360));int ready=(int)Math.min(100,100.0*scenario/Math.max(1,(Integer)target.getValue()));ring.setProgress(ready/100f,"readiness");details.setText("<html><b>Current mastery-based score estimate: "+score+"%</b><br>With +"+extra.getValue()+" min/day: "+scenario+"% estimated score<br>Target: "+target.getValue()+"%<br>Readiness in this scenario: "+ready+"%<br>Days to exam: "+days+"<br><br>This is a planning estimate based on your current topic mastery, not a calibrated exam prediction.</html>");sliderLabel.setText("Extra study time per day: "+extra.getValue()+" minutes");};
        extra.addChangeListener(e->refresh.run());target.addChangeListener(e->refresh.run());date.addActionListener(e->refresh.run());
        save.addActionListener(e->{try{ctx.data.profile.targetExamDate=LocalDate.parse(date.getText().trim());ctx.data.profile.targetScore=(Integer)target.getValue();ctx.saveOrWarn();refresh.run();JOptionPane.showMessageDialog(page,"Exam goal saved.");}catch(Exception ex){JOptionPane.showMessageDialog(page,"Enter a valid exam date as YYYY-MM-DD.");}});
        JPanel controls=new JPanel(new BorderLayout(0,8));controls.setOpaque(false);controls.add(sliderLabel,BorderLayout.NORTH);controls.add(extra,BorderLayout.CENTER);controls.add(save,BorderLayout.SOUTH);
        JPanel body=new JPanel(new BorderLayout(0,16));body.setOpaque(false);body.add(form,BorderLayout.NORTH);body.add(meter,BorderLayout.CENTER);body.add(controls,BorderLayout.SOUTH);page.add(body,BorderLayout.CENTER);refresh.run();return page;
    }
    private static LocalDate parseDate(String text){try{return LocalDate.parse(text.trim());}catch(Exception e){return LocalDate.now().plusWeeks(4);}}
    private static int estimatedScore(AppContext ctx){if(!ctx.data.knowledge.isEmpty())return (int)Math.round(ctx.data.knowledge.values().stream().mapToInt(k->k.mastery).average().orElse(0));int total=0,n=0;for(Subject s:ctx.data.subjects)for(Topic t:s.topics){total+=t.strength*20;n++;}return n==0?0:(int)Math.round(total/(double)n);}
}
