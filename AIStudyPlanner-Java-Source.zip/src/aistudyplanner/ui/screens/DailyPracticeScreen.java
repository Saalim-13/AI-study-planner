package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

/** Daily MCQ entry page. Questions are sampled from the local bank. */
public final class DailyPracticeScreen {
    private DailyPracticeScreen() { }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("Current Affairs / Daily Practice", "A short daily MCQ session drawn from your available question bank.");
        RoundedPanel card = Ui.card();
        card.setLayout(new BorderLayout(0, 14));
        card.add(Ui.label("10 questions · one focused session", theme.headingFont, theme.text), BorderLayout.NORTH);
        card.add(Ui.label("Your saved question bank currently contains " + ctx.quiz.bankSize()
                + " question(s). Add current-affairs questions through Quiz Center or upload your study materials.",
                theme.bodyFont, theme.muted), BorderLayout.CENTER);
        AccentButton start = AccentButton.primary("Start today’s 10-question practice");
        start.addActionListener(e -> {
            if (java.time.LocalDate.now().equals(ctx.data.profile.dailyPracticeDate)) {
                javax.swing.JOptionPane.showMessageDialog(page,
                        "Today’s 10-question practice is complete. Come back tomorrow for another session.",
                        "Daily practice complete", javax.swing.JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if (ctx.quiz.bankSize() < 10) {
                javax.swing.JOptionPane.showMessageDialog(page,
                        "Add at least 10 questions to your quiz bank before starting the daily session.",
                        "More questions needed", javax.swing.JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            ctx.applet.showScreen("Daily Quiz");
        });
        AccentButton bank = AccentButton.ghost("Open Quiz Center");
        bank.addActionListener(e -> ctx.applet.showScreen("Quiz Center"));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actions.setOpaque(false);
        actions.add(start);
        actions.add(bank);
        card.add(actions, BorderLayout.SOUTH);
        page.add(card, BorderLayout.CENTER);
        return page;
    }
}
