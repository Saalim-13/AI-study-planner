package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.ChatMessage;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.Window;
import java.util.List;

/** Small non-modal assistant window. Messages are saved with the learner's local data. */
public final class MentorChatDialog {
    private static JDialog openDialog;

    private MentorChatDialog() { }

    public static void show(AppContext ctx) {
        if (openDialog != null && openDialog.isDisplayable()) {
            openDialog.setVisible(true);
            openDialog.toFront();
            return;
        }
        Window owner = SwingUtilities.getWindowAncestor(ctx.applet);
        JDialog dialog = new JDialog(owner, "Study-Wise Mentor");
        openDialog = dialog;
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setResizable(true);
        dialog.setMinimumSize(new Dimension(340, 420));
        dialog.setSize(390, 540);
        dialog.getContentPane().setBackground(Theme.get().bg);
        dialog.setLayout(new BorderLayout(0, 8));

        Theme theme = Theme.get();
        JPanel header = new JPanel(new BorderLayout(0, 4));
        header.setBackground(theme.card);
        header.setBorder(BorderFactory.createEmptyBorder(13, 15, 12, 15));
        JLabel title = Ui.label("Your study mentor", theme.headingFont, theme.text);
        JLabel subtitle = Ui.label("Private coaching based on your saved progress", theme.smallFont, theme.muted);
        header.add(title, BorderLayout.NORTH);
        header.add(subtitle, BorderLayout.SOUTH);
        dialog.add(header, BorderLayout.NORTH);

        JPanel messages = new JPanel();
        messages.setOpaque(false);
        messages.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        messages.setLayout(new BoxLayout(messages, BoxLayout.Y_AXIS));
        JScrollPane scroll = Ui.scroll(messages);
        dialog.add(scroll, BorderLayout.CENTER);
        JLabel typing = Ui.label("", theme.smallFont, theme.muted);
        typing.setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));

        JTextField input = new JTextField();
        Ui.styleField(input);
        input.setToolTipText("Ask about your study plan, progress, or notes");
        AccentButton send = AccentButton.primary("Send");
        send.setPreferredSize(new Dimension(76, 38));
        JPanel compose = new JPanel(new BorderLayout(8, 7));
        compose.setOpaque(false);
        compose.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        JPanel fieldRow = new JPanel(new BorderLayout(7, 0));
        fieldRow.setOpaque(false);
        fieldRow.add(input, BorderLayout.CENTER);
        fieldRow.add(send, BorderLayout.EAST);
        compose.add(typing, BorderLayout.NORTH);
        compose.add(fieldRow, BorderLayout.CENTER);
        dialog.add(compose, BorderLayout.SOUTH);

        for (ChatMessage message : ctx.data.mentorChat) addBubble(messages, message);
        if (ctx.data.mentorChat.isEmpty()) {
            addBubble(messages, new ChatMessage("assistant",
                    "Hi! Ask what to study next, how your progress is going, or tell me a topic you want to work on."));
        }

        Runnable submit = () -> {
            String text = input.getText().trim();
            if (text.isEmpty() || !send.isEnabled()) return;
            ChatMessage userMessage = new ChatMessage("user", text);
            remember(ctx, userMessage);
            addBubble(messages, userMessage);
            input.setText("");
            send.setEnabled(false);
            typing.setText("Mentor is thinking…");
            messages.revalidate();
            SwingUtilities.invokeLater(() -> scroll.getVerticalScrollBar().setValue(scroll.getVerticalScrollBar().getMaximum()));

            new SwingWorker<String, Void>() {
                @Override protected String doInBackground() {
                    return ctx.mentor.replyWithMaterial(ctx, text, ctx.data.activeMaterialText);
                }
                @Override protected void done() {
                    String response;
                    try { response = get(); }
                    catch (Exception ex) { response = "I couldn't prepare a reply just now. Please try again."; }
                    ChatMessage reply = new ChatMessage("assistant", response);
                    remember(ctx, reply);
                    addBubble(messages, reply);
                    typing.setText(" ");
                    send.setEnabled(true);
                    messages.revalidate();
                    SwingUtilities.invokeLater(() -> scroll.getVerticalScrollBar().setValue(scroll.getVerticalScrollBar().getMaximum()));
                    input.requestFocusInWindow();
                }
            }.execute();
        };
        send.addActionListener(e -> submit.run());
        input.addActionListener(e -> submit.run());

        JPanel suggestions = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        suggestions.setOpaque(false);
        for (String prompt : new String[]{"What next?", "Explain my progress"}) {
            AccentButton quick = AccentButton.ghost(prompt);
            quick.setPreferredSize(new Dimension(136, 30));
            quick.addActionListener(e -> { input.setText(prompt); submit.run(); });
            suggestions.add(quick);
        }
        compose.add(suggestions, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
        if (owner != null) {
            Point location = owner.getLocationOnScreen();
            dialog.setLocation(location.x + owner.getWidth() - dialog.getWidth() - 24,
                    location.y + owner.getHeight() - dialog.getHeight() - 42);
        }
    }

    private static void remember(AppContext ctx, ChatMessage message) {
        ctx.data.mentorChat.add(message);
        while (ctx.data.mentorChat.size() > 100) ctx.data.mentorChat.remove(0);
        ctx.saveQuietly();
    }

    private static void addBubble(JPanel messages, ChatMessage message) {
        Theme theme = Theme.get();
        boolean user = "user".equalsIgnoreCase(message.role);
        RoundedPanel bubble = new RoundedPanel(new BorderLayout());
        bubble.setFillColor(user ? theme.accentSoft : theme.card);
        bubble.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        JLabel body = Ui.label("<html><div style='width:260px'>" + escape(message.text) + "</div></html>", theme.bodyFont, theme.text);
        bubble.add(body, BorderLayout.CENTER);
        bubble.setAlignmentX(user ? Component.RIGHT_ALIGNMENT : Component.LEFT_ALIGNMENT);
        bubble.setMaximumSize(new Dimension(310, Integer.MAX_VALUE));
        messages.add(bubble);
        messages.add(Box.createVerticalStrut(7));
    }

    private static String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>");
    }
}
