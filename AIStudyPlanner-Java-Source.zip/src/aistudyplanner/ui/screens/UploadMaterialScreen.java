package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.logic.MaterialAnalyzer;
import aistudyplanner.storage.MaterialExtractor;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.nio.file.Path;

/** Material intake page with progress, analysis and safe, explainable error handling. */
public final class UploadMaterialScreen {
    private UploadMaterialScreen() { }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("Upload Material", "Study notes, documents, or a source link become a grounded revision resource.");
        JPanel body = new JPanel(new BorderLayout(0, 14));
        body.setOpaque(false);
        RoundedPanel intake = Ui.card();
        intake.setLayout(new BorderLayout(0, 10));
        intake.add(Ui.label("Add material for your learning coach", theme.headingFont, theme.text), BorderLayout.NORTH);
        intake.add(Ui.label("Supported: PDF, DOCX, PPTX, TXT, Markdown, HTML, PNG, JPG and BMP. Images use local Tesseract OCR when installed. Pasted text and HTTP/HTTPS pages are also supported.", theme.bodyFont, theme.muted), BorderLayout.CENTER);

        JLabel status = Ui.label("", theme.smallFont, theme.muted);
        AccentButton file = AccentButton.primary("Choose a file");
        AccentButton paste = AccentButton.ghost("Paste text");
        AccentButton link = AccentButton.ghost("Analyze web link");
        AccentButton quiz = AccentButton.ghost("Create quiz from this material");
        AccentButton clear = AccentButton.ghost("Clear loaded material");
        file.addActionListener(e -> chooseFile(ctx, page, status, file, paste, link));
        paste.addActionListener(e -> pasteText(ctx, page, status, file, paste, link));
        link.addActionListener(e -> enterLink(ctx, page, status, file, paste, link));
        quiz.addActionListener(e -> ctx.applet.showScreen("Quiz Center"));
        clear.addActionListener(e -> {
            ctx.data.activeMaterialName = "";
            ctx.data.activeMaterialText = "";
            ctx.data.activeMaterialAnalysis = "";
            ctx.saveQuietly();
            ctx.applet.showScreen("Upload Material");
        });
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        controls.setOpaque(false);
        controls.add(file); controls.add(paste); controls.add(link);
        intake.add(controls, BorderLayout.SOUTH);

        JPanel result = new JPanel(new BorderLayout(0, 8));
        result.setOpaque(false);
        if (ctx.data.activeMaterialText.isBlank()) {
            RoundedPanel empty = Ui.card();
            empty.add(Ui.label("No material loaded yet", theme.headingFont, theme.text), BorderLayout.NORTH);
            empty.add(Ui.label("Add material above. Its extracted text and study brief will be stored locally for follow-up questions.",
                    theme.bodyFont, theme.muted), BorderLayout.CENTER);
            result.add(empty, BorderLayout.CENTER);
        } else {
            RoundedPanel preview = Ui.card();
            preview.setLayout(new BorderLayout(0, 9));
            JPanel title = new JPanel(new BorderLayout());
            title.setOpaque(false);
            title.add(Ui.label(ctx.data.activeMaterialName, theme.headingFont, theme.text), BorderLayout.CENTER);
            title.add(clear, BorderLayout.EAST);
            preview.add(title, BorderLayout.NORTH);
            JTextArea analysis = new JTextArea(ctx.data.activeMaterialAnalysis.isBlank()
                    ? new MaterialAnalyzer().analyze(ctx.data.activeMaterialText, ctx.data.profile.examType)
                    : ctx.data.activeMaterialAnalysis);
            analysis.setEditable(false);
            analysis.setLineWrap(true);
            analysis.setWrapStyleWord(true);
            analysis.setFont(theme.bodyFont);
            analysis.setForeground(theme.text);
            analysis.setBackground(theme.cardAlt);
            analysis.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
            preview.add(Ui.scroll(analysis), BorderLayout.CENTER);
            JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            actions.setOpaque(false);
            actions.add(quiz);
            AccentButton ask = AccentButton.ghost("Ask mentor about this material");
            ask.addActionListener(e -> MentorChatDialog.show(ctx));
            actions.add(ask);
            preview.add(actions, BorderLayout.SOUTH);
            result.add(preview, BorderLayout.CENTER);
        }
        result.add(status, BorderLayout.SOUTH);
        body.add(intake, BorderLayout.NORTH);
        body.add(result, BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private static void chooseFile(AppContext ctx, JPanel parent, JLabel status,
                                   AccentButton... controls) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose study material");
        if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
            Path path = chooser.getSelectedFile().toPath();
            analyze(ctx, path.getFileName().toString(), () -> new MaterialExtractor().read(path), parent, status, controls);
        }
    }

    private static void pasteText(AppContext ctx, JPanel parent, JLabel status,
                                  AccentButton... controls) {
        JTextArea area = new JTextArea(14, 54);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(Theme.get().bodyFont);
        JTextField title = new JTextField("Pasted study notes");
        JPanel form = new JPanel(new BorderLayout(0, 8));
        form.add(title, BorderLayout.NORTH);
        form.add(new JScrollPane(area), BorderLayout.CENTER);
        if (JOptionPane.showConfirmDialog(parent, form, "Paste material", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
            String text = area.getText().trim();
            if (text.isBlank()) {
                JOptionPane.showMessageDialog(parent, "Paste some study text first.");
                return;
            }
            analyze(ctx, title.getText().isBlank() ? "Pasted material" : title.getText().trim(),
                    () -> text, parent, status, controls);
        }
    }

    private static void enterLink(AppContext ctx, JPanel parent, JLabel status,
                                  AccentButton... controls) {
        String url = JOptionPane.showInputDialog(parent, "HTTP/HTTPS page address:", "Analyze web page", JOptionPane.QUESTION_MESSAGE);
        if (url == null || url.isBlank()) return;
        analyze(ctx, url.trim(), () -> new MaterialExtractor().readWebLink(url), parent, status, controls);
    }

    private static void analyze(AppContext ctx, String label, TextLoader loader, JPanel parent,
                               JLabel status, AccentButton... controls) {
        for (AccentButton control : controls) control.setEnabled(false);
        status.setText("Loading and analyzing material…");
        status.setForeground(Theme.get().accent);
        new SwingWorker<String[], Void>() {
            @Override protected String[] doInBackground() throws Exception {
                String text = loader.read();
                if (text == null || text.isBlank()) throw new IllegalArgumentException("No readable text was extracted.");
                if (text.length() > 500_000) text = text.substring(0, 500_000);
                String report = ctx.mentor.analyzeMaterial(ctx, text);
                return new String[]{text, report};
            }
            @Override protected void done() {
                for (AccentButton control : controls) control.setEnabled(true);
                try {
                    String[] result = get();
                    ctx.data.activeMaterialName = label;
                    ctx.data.activeMaterialText = result[0];
                    ctx.data.activeMaterialAnalysis = result[1];
                    ctx.saveQuietly();
                    status.setText("Material saved locally · " + result[0].split("\\s+").length + " words analyzed.");
                    ctx.applet.showScreen("Upload Material");
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    status.setText(" ");
                    JOptionPane.showMessageDialog(parent, cause.getMessage() == null ? "Could not read this material." : cause.getMessage(),
                            "Material could not be analyzed", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    @FunctionalInterface private interface TextLoader { String read() throws Exception; }
}
