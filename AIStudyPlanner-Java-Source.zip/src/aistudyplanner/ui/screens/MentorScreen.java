package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import javax.swing.*;
import java.awt.*;

/** Local chat-style learning coach. */
public final class MentorScreen {
    private MentorScreen() { }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("AI Mentor", "A private, rule-based coach that reads your saved study data locally.");
        JPanel messages = new JPanel();
        messages.setOpaque(false);
        messages.setLayout(new BoxLayout(messages, BoxLayout.Y_AXIS));
        addMessage(messages, "Mentor", "Hi " + ctx.data.profile.name + "! Ask what to study, how a topic is going, or how to make your week lighter.", false);
        JScrollPane scroll = Ui.scroll(messages);
        JPanel compose = new JPanel(new BorderLayout(8, 0));
        compose.setOpaque(false);
        JTextField input = new JTextField();
        Ui.styleField(input);
        input.setToolTipText("Ask about your plan, progress, or a topic");
        AccentButton send = AccentButton.primary("Send");
        compose.add(input, BorderLayout.CENTER);
        compose.add(send, BorderLayout.EAST);
        JPanel suggestions = new JPanel(new FlowLayout(FlowLayout.LEFT, 7, 0));
        suggestions.setOpaque(false);
        String[] prompts = {"What should I study now?", "Explain my progress", "I'm weak in Polity", "Make my plan lighter this week"};
        for (String prompt : prompts) {
            AccentButton quick = AccentButton.ghost(prompt);
            quick.setToolTipText("Ask the mentor: " + prompt);
            quick.addActionListener(e -> { input.setText(prompt); send.doClick(); });
            suggestions.add(quick);
        }
        send.setToolTipText("Send your question to the local rule-based mentor");
        Runnable submit = () -> {
            String question = input.getText().trim();
            if (question.isEmpty()) return;
            addMessage(messages, "You", question, true);
            String response = ctx.mentor.reply(ctx, question);
            addMessage(messages, "Mentor", response, false);
            input.setText("");
            messages.revalidate();
            SwingUtilities.invokeLater(() -> scroll.getVerticalScrollBar().setValue(scroll.getVerticalScrollBar().getMaximum()));
        };
        send.addActionListener(e -> submit.run());
        input.addActionListener(e -> submit.run());
        JPanel lower = new JPanel(new BorderLayout(0, 9));
        lower.setOpaque(false);
        lower.add(suggestions, BorderLayout.NORTH);
        lower.add(compose, BorderLayout.SOUTH);
        page.add(scroll, BorderLayout.CENTER);
        page.add(lower, BorderLayout.SOUTH);
        return page;
    }

    private static void addMessage(JPanel list, String speaker, String text, boolean user) {
        Theme theme = Theme.get();
        RoundedPanel bubble = new RoundedPanel(new BorderLayout(0, 5));
        bubble.setBorder(BorderFactory.createEmptyBorder(11, 14, 11, 14));
        JLabel name = Ui.label(speaker, theme.smallFont, user ? theme.accent : theme.success);
        JLabel body = Ui.label("<html><div style='width:560px'>" + escape(text) + "</div></html>", theme.bodyFont, theme.text);
        bubble.add(name, BorderLayout.NORTH);
        bubble.add(body, BorderLayout.CENTER);
        bubble.setAlignmentX(user ? Component.RIGHT_ALIGNMENT : Component.LEFT_ALIGNMENT);
        bubble.setMaximumSize(new Dimension(720, bubble.getPreferredSize().height + 28));
        list.add(bubble);
        list.add(Box.createVerticalStrut(10));
    }

    private static String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>");
    }
}
