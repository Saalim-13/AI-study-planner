package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.logic.GamificationService;
import aistudyplanner.model.QuizQuestion;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Full-length local timed test with navigation palette and +4/-1 scoring. */
final class MockTestDialog {
    private MockTestDialog() { }
    static void show(AppContext ctx) {
        List<QuizQuestion> questions=ctx.quiz.startQuiz(null,20);
        if(questions.isEmpty()){JOptionPane.showMessageDialog(ctx.applet,"Add questions or upload notes before starting a mock test.");return;}
        new Test(ctx,questions).run();
    }
    private static final class Test {
        final AppContext ctx;final List<QuizQuestion> qs;final int[] answers;final boolean[] marked;final boolean[] skipped;
        int index;int remaining;long started;JDialog dialog;JLabel clock=new JLabel();JLabel question=new JLabel();JRadioButton[] choices=new JRadioButton[4];ButtonGroup group=new ButtonGroup();JButton[] palette;
        Test(AppContext c,List<QuizQuestion> q){ctx=c;qs=q;answers=new int[q.size()];java.util.Arrays.fill(answers,-1);marked=new boolean[q.size()];skipped=new boolean[q.size()];remaining=q.size()*Math.max(10,c.data.profile.quizSeconds);}
        void run(){
            dialog=new JDialog(SwingUtilities.getWindowAncestor(ctx.applet),"Mock Test · "+qs.size()+" questions · +4 / −1",Dialog.ModalityType.APPLICATION_MODAL);
            dialog.setSize(950,640);dialog.setLocationRelativeTo(ctx.applet);dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            JPanel root=new JPanel(new BorderLayout(14,12));root.setBorder(BorderFactory.createEmptyBorder(16,18,16,18));root.setBackground(Theme.get().bg);
            JPanel header=new JPanel(new BorderLayout());header.setOpaque(false);header.add(new JLabel("Timed Mock Test"),BorderLayout.WEST);clock.setFont(Theme.get().titleFont);clock.setForeground(Theme.get().accent);header.add(clock,BorderLayout.EAST);root.add(header,BorderLayout.NORTH);
            JPanel center=new JPanel(new BorderLayout(12,10));center.setOpaque(false);question.setFont(Theme.get().headingFont);question.setForeground(Theme.get().text);center.add(question,BorderLayout.NORTH);
            JPanel options=new JPanel(new GridLayout(0,1,8,8));options.setOpaque(false);for(int i=0;i<4;i++){choices[i]=new JRadioButton();choices[i].setOpaque(false);choices[i].setForeground(Theme.get().text);choices[i].setFont(Theme.get().bodyFont);choices[i].setToolTipText("Select this answer option");group.add(choices[i]);final int choice=i;choices[i].addActionListener(e->{answers[index]=choice;skipped[index]=false;refreshPalette();});options.add(choices[i]);}center.add(options,BorderLayout.CENTER);
            JPanel palette=new JPanel(new GridLayout(0,5,5,5));palette.setPreferredSize(new Dimension(210,1));palette.setBackground(Theme.get().card);palette.setBorder(BorderFactory.createTitledBorder("Question palette"));this.palette=new JButton[qs.size()];for(int i=0;i<qs.size();i++){final int n=i;this.palette[i]=new JButton(""+(i+1));Ui.retroButton(this.palette[i]);this.palette[i].addActionListener(e->{storeCurrent();index=n;showQuestion();});palette.add(this.palette[i]);}root.add(palette,BorderLayout.EAST);
            JPanel controls=new JPanel(new FlowLayout(FlowLayout.LEFT));controls.setOpaque(false);JButton prev=new JButton("Previous"),skip=new JButton("Skip"),mark=new JButton("Mark for review"),next=new JButton("Next"),submit=new JButton("Submit test");for(JButton b:new JButton[]{prev,skip,mark,next,submit})Ui.retroButton(b);prev.setToolTipText("Go to the previous question");skip.setToolTipText("Leave this question unanswered");mark.setToolTipText("Flag this question to revisit");next.setToolTipText("Go to the next question");submit.setToolTipText("Submit answers and view the detailed score");prev.addActionListener(e->{storeCurrent();if(index>0){index--;showQuestion();}});next.addActionListener(e->{storeCurrent();if(index<qs.size()-1){index++;showQuestion();}});skip.addActionListener(e->{answers[index]=-1;skipped[index]=true;group.clearSelection();refreshPalette();if(index<qs.size()-1){index++;showQuestion();}});mark.addActionListener(e->{marked[index]=!marked[index];refreshPalette();});submit.addActionListener(e->finish());for(JButton b:new JButton[]{prev,skip,mark,next,submit})controls.add(b);root.add(center,BorderLayout.CENTER);root.add(controls,BorderLayout.SOUTH);dialog.setContentPane(root);showQuestion();started=System.currentTimeMillis();javax.swing.Timer tick=new javax.swing.Timer(500,e->{remaining=Math.max(0,qs.size()*Math.max(10,ctx.data.profile.quizSeconds)-(int)((System.currentTimeMillis()-started)/1000));clock.setText("Remaining  "+fmt(remaining));if(remaining==0){((javax.swing.Timer)e.getSource()).stop();finish();}});tick.start();dialog.setVisible(true);tick.stop();
        }
        void storeCurrent(){for(int i=0;i<4;i++)if(choices[i].isSelected())answers[index]=i;}
        void showQuestion(){QuizQuestion q=qs.get(index);question.setText("<html>"+(index+1)+" / "+qs.size()+"  ·  "+escape(q.subject+" / "+q.topic)+"<br><br>"+escape(q.prompt)+"</html>");group.clearSelection();for(int i=0;i<4;i++){choices[i].setText((char)('A'+i)+"  "+q.choices[i]);choices[i].setSelected(answers[index]==i);}refreshPalette();}
        void refreshPalette(){if(palette==null)return;for(int i=0;i<palette.length;i++){palette[i].setBackground(i==index?new Color(145,108,240):answers[i]>=0?new Color(95,194,155):marked[i]?new Color(237,171,73):skipped[i]?new Color(91,137,180):Theme.get().cardAlt);palette[i].setForeground(Color.WHITE);palette[i].setToolTipText(answers[i]>=0?(marked[i]?"Answered · marked for review":"Answered"):marked[i]?"Marked for review":skipped[i]?"Skipped":"Not answered");}}
        void finish(){
            if(!dialog.isShowing())return;
            storeCurrent();
            if(JOptionPane.showConfirmDialog(dialog,"Submit this test now? Unanswered questions score zero.","Submit mock test",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION&&remaining>0)return;
            int right=0,wrong=0,skip=0,score=0;
            int elapsed=(int)Math.max(0,(System.currentTimeMillis()-started)/1000);
            String session=java.util.UUID.randomUUID().toString();
            java.util.List<aistudyplanner.model.QuizAttempt> saved=new java.util.ArrayList<>();
            StringBuilder report=new StringBuilder("MOCK TEST RESULT\n\n");
            java.util.Map<String,int[]> topicScores=new java.util.HashMap<>();
            for(int i=0;i<qs.size();i++){
                QuizQuestion q=qs.get(i);int a=answers[i];
                if(a<0){skip++;ctx.quiz.record(ctx.data,q,-1,0);saved.add(ctx.data.quizAttempts.get(ctx.data.quizAttempts.size()-1));report.append(i+1).append(". SKIPPED — ").append(q.subject).append(" / ").append(q.topic).append("\n");continue;}
                boolean correct=a==q.correctIndex;
                if(correct){right++;score+=4;}else{wrong++;score--;}
                int[] ts=topicScores.computeIfAbsent(q.subject+"\n"+q.topic,k->new int[2]);ts[1]++;if(correct)ts[0]++;
                ctx.quiz.record(ctx.data,q,a,0);
                saved.add(ctx.data.quizAttempts.get(ctx.data.quizAttempts.size()-1));
                report.append(i+1).append(correct?". CORRECT — ":". INCORRECT — ").append(q.subject).append(" / ").append(q.topic)
                        .append("\n   Your answer: ").append(q.choices[a]).append(" | Correct: ").append(q.choices[q.correctIndex])
                        .append("\n   ").append(q.explanation).append("\n");
            }
            for(aistudyplanner.model.QuizAttempt attempt:saved){attempt.quizSessionId=session;attempt.quizSessionSize=qs.size();attempt.quizSessionScore=right;attempt.quizSessionSeconds=elapsed;}
            for(java.util.Map.Entry<String,int[]>e:topicScores.entrySet()){String[] key=e.getKey().split("\n",2);int[] v=e.getValue();ctx.knowledge.recordQuiz(ctx.data,key[0],key[1],v[0]/(double)v[1],java.time.LocalDate.now());}
            GamificationService.Award award=new GamificationService().awardQuiz(ctx,right,qs.size()-skip);
            QuizScreen.rebalancePlan(ctx);
            report.insert(0,"Score: "+score+" points (+4/−1)  •  Correct: "+right+"  •  Wrong: "+wrong+"  •  Skipped: "+skip
                    +"  •  Time: "+String.format("%d min %02d sec",elapsed/60,elapsed%60)+"  •  XP: +"+award.gained+"\n\n");
            ctx.saveQuietly();dialog.dispose();JTextArea area=new JTextArea(report.toString(),24,72);area.setEditable(false);area.setLineWrap(true);area.setWrapStyleWord(true);area.setFont(Theme.get().bodyFont);
            JOptionPane.showMessageDialog(ctx.applet,new JScrollPane(area),"Detailed mock-test report",JOptionPane.INFORMATION_MESSAGE);
            if(award.newLevel>award.oldLevel)LevelUpDialog.show(ctx.applet,award);
        }
        String fmt(int sec){return String.format("%02d:%02d",sec/60,sec%60);}String escape(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}
    }
}
