package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.StudyTask;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.AnimatedBar;
import aistudyplanner.ui.CoachArtwork;
import aistudyplanner.ui.GamificationStrip;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import aistudyplanner.util.TimeFmt;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Component;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Reference-inspired daily home: calm spacing, clear tasks and a single next action. */
public final class DashboardScreen {
    private DashboardScreen() { }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = new JPanel(new BorderLayout());
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(22, 28, 24, 28));

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.add(greeting(ctx));
        content.add(Box.createVerticalStrut(22));

        List<StudyTask> today = new ArrayList<>();
        for (StudyTask task : ctx.data.tasks) if (LocalDate.now().equals(task.day)) today.add(task);
        today.sort(Comparator.comparing((StudyTask task) -> task.done)
                .thenComparing(Comparator.comparingInt((StudyTask task) -> task.priority).reversed()));
        JPanel progress = progressCard(ctx, today);
        progress.setAlignmentX(Component.LEFT_ALIGNMENT);
        Runnable updateProgress = (Runnable) progress.getClientProperty("refreshProgress");
        content.add(taskCard(ctx, today, updateProgress));
        content.add(Box.createVerticalStrut(20));
        content.add(progress);
        content.add(Box.createVerticalStrut(20));
        content.add(tipCard(theme));
        content.add(Box.createVerticalStrut(16));

        JPanel xp = Ui.card();
        xp.setAlignmentX(Component.LEFT_ALIGNMENT);
        xp.setMaximumSize(new Dimension(Integer.MAX_VALUE, 76));
        xp.add(new GamificationStrip(ctx.data), BorderLayout.CENTER);
        content.add(xp);

        page.add(Ui.scroll(content), BorderLayout.CENTER);
        return page;
    }

    private static JPanel greeting(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel header = new JPanel(new BorderLayout(22, 0));
        header.setOpaque(false);
        JPanel text = new JPanel(new BorderLayout(0, 5));
        text.setOpaque(false);
        text.add(Ui.label(LocalDate.now().format(TimeFmt.LONG), theme.bodyFont.deriveFont(15f), theme.accent), BorderLayout.NORTH);
        String name = ctx.data.profile.name == null || ctx.data.profile.name.isBlank() ? "there" : ctx.data.profile.name;
        text.add(Ui.label("Good " + timeOfDay() + ", " + name, theme.titleFont.deriveFont(29f), theme.text), BorderLayout.CENTER);
        text.add(Ui.label("Here’s a clear view of your study day.", theme.bodyFont, theme.muted), BorderLayout.SOUTH);
        header.add(text, BorderLayout.CENTER);

        JPanel action = new JPanel(new BorderLayout());
        action.setOpaque(false);
        AccentButton create = AccentButton.primary("▣  Create study plan");
        create.setFont(theme.headingFont.deriveFont(java.awt.Font.BOLD, 14f));
        create.setPreferredSize(new Dimension(210, 48));
        create.setToolTipText("Choose your subjects and build a personalized schedule");
        create.addActionListener(e -> ctx.applet.showScreen(ctx.data.subjects.isEmpty() ? "Subjects" : "Planner"));
        action.add(create, BorderLayout.CENTER);
        header.add(action, BorderLayout.EAST);
        header.setPreferredSize(new Dimension(700, 76));
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 84));
        header.setAlignmentX(Component.LEFT_ALIGNMENT);
        return header;
    }

    private static String timeOfDay() {
        int hour = LocalTime.now().getHour();
        return hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
    }

    private static JPanel taskCard(AppContext ctx, List<StudyTask> today, Runnable updateProgress) {
        Theme theme = Theme.get();
        RoundedPanel card = Ui.card();
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setLayout(new BorderLayout(0, 13));
        card.setBorder(BorderFactory.createEmptyBorder(20, 22, 18, 22));

        JPanel title = new JPanel(new BorderLayout());
        title.setOpaque(false);
        JPanel labels = new JPanel();
        labels.setOpaque(false);
        labels.setLayout(new BoxLayout(labels, BoxLayout.Y_AXIS));
        labels.add(Ui.label("Today’s tasks", theme.headingFont.deriveFont(java.awt.Font.BOLD, 21f), theme.text));
        JLabel countLabel = Ui.label("", theme.smallFont.deriveFont(java.awt.Font.BOLD), theme.muted);
        labels.add(countLabel);
        Runnable refresh = () -> {
            int complete = (int) today.stream().filter(task -> task.done).count();
            countLabel.setText(complete + " of " + today.size() + " completed");
            updateProgress.run();
        };
        refresh.run();
        title.add(labels, BorderLayout.WEST);
        title.add(Ui.label("▦", theme.headingFont, theme.muted), BorderLayout.EAST);
        card.add(title, BorderLayout.NORTH);

        JPanel rows = new JPanel();
        rows.setOpaque(false);
        rows.setLayout(new BoxLayout(rows, BoxLayout.Y_AXIS));
        if (today.isEmpty()) {
            JLabel empty = Ui.label("No tasks planned for today. Create a study plan to get started.", theme.bodyFont, theme.muted);
            empty.setBorder(BorderFactory.createEmptyBorder(12, 4, 15, 4));
            rows.add(empty);
        } else {
            int shown = Math.min(5, today.size());
            for (int i = 0; i < shown; i++) {
                StudyTask task = today.get(i);
                rows.add(taskRow(ctx, task, refresh));
                if (i < shown - 1) rows.add(Box.createVerticalStrut(5));
            }
            if (today.size() > shown) {
                rows.add(Ui.label("+ " + (today.size() - shown) + " more tasks in your study plan", theme.smallFont, theme.muted));
            }
        }
        card.add(rows, BorderLayout.CENTER);
        if (!today.isEmpty()) {
            AccentButton view = AccentButton.ghost("Open study plan  →");
            view.setPreferredSize(new Dimension(180, 34));
            view.addActionListener(e -> ctx.applet.showScreen("Planner"));
            JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
            footer.setOpaque(false);
            footer.add(view);
            card.add(footer, BorderLayout.SOUTH);
        }
        return card;
    }

    private static JPanel taskRow(AppContext ctx, StudyTask task, Runnable updateProgress) {
        Theme theme = Theme.get();
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
        JCheckBox done = new JCheckBox();
        done.setOpaque(false);
        done.setSelected(task.done);
        done.setToolTipText(task.done ? "Mark this task incomplete" : "Mark this study task complete");
        done.addActionListener(e -> {
            task.done = done.isSelected();
            ctx.saveOrWarn();
            updateProgress.run();
        });
        row.add(done, BorderLayout.WEST);

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        JLabel name = Ui.label(escape(task.topic == null || task.topic.isBlank() ? task.label() : task.topic),
                theme.bodyFont.deriveFont(java.awt.Font.BOLD, 15f), task.done ? theme.muted : theme.text);
        info.add(name);
        info.add(Ui.label(escape(task.subject) + " · " + task.minutes + " min · " + shortKind(task.kind), theme.smallFont, theme.muted));
        row.add(info, BorderLayout.CENTER);
        row.add(priorityChip(task.priority), BorderLayout.EAST);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 49));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        return row;
    }

    private static JLabel priorityChip(int priority) {
        String label = priority >= 4 ? "High" : priority <= 2 ? "Low" : "Medium";
        Color background = priority >= 4 ? new Color(255, 239, 241)
                : priority <= 2 ? new Color(238, 244, 248) : new Color(255, 249, 231);
        Color ink = priority >= 4 ? new Color(173, 68, 81)
                : priority <= 2 ? new Color(95, 117, 134) : new Color(162, 119, 45);
        JLabel chip = Ui.label(label, Theme.get().smallFont, ink);
        chip.setHorizontalAlignment(JLabel.CENTER);
        chip.setOpaque(true);
        chip.setBackground(background);
        chip.setBorder(BorderFactory.createEmptyBorder(5, 12, 5, 12));
        return chip;
    }

    private static String shortKind(String kind) {
        if (StudyTask.REVISE.equals(kind)) return "Review";
        if (StudyTask.QUIZ.equals(kind)) return "Practice";
        return "Study";
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static JPanel progressCard(AppContext ctx, List<StudyTask> today) {
        Theme theme = Theme.get();
        RoundedPanel card = Ui.card();
        card.setLayout(new BorderLayout(0, 10));
        card.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(Ui.label("✓  Today’s progress", theme.bodyFont.deriveFont(java.awt.Font.BOLD), theme.text), BorderLayout.WEST);
        JLabel status = Ui.label("Keep going", theme.smallFont, theme.muted);
        top.add(status, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 7));
        center.setOpaque(false);
        JLabel percentage = Ui.label("0%", theme.titleFont.deriveFont(26f), theme.text);
        center.add(percentage, BorderLayout.NORTH);
        AnimatedBar bar = new AnimatedBar();
        bar.setPreferredSize(new Dimension(500, 17));
        center.add(bar, BorderLayout.CENTER);
        card.add(center, BorderLayout.CENTER);
        JLabel note = Ui.label("You’re making steady progress toward this week’s goals.", theme.smallFont, theme.muted);
        card.add(note, BorderLayout.SOUTH);

        Runnable update = () -> {
            int total = today.size();
            int done = (int) today.stream().filter(task -> task.done).count();
            float percent = total == 0
                    ? Math.min(1f, ctx.data.minutesStudiedOn(LocalDate.now()) / (float) Math.max(1, ctx.data.profile.dailyGoalMinutes))
                    : done / (float) total;
            percentage.setText(Math.round(percent * 100) + "%");
            status.setText(percent >= 1 ? "Goal reached" : "Keep going");
            bar.setProgress(percent, "");
        };
        update.run();
        // The task checkbox updates saved data; this listener keeps the card current too.
        card.putClientProperty("refreshProgress", update);
        return card;
    }

    private static JPanel tipCard(Theme theme) {
        RoundedPanel card = Ui.card();
        card.setLayout(new BorderLayout(12, 0));
        card.setBorder(BorderFactory.createEmptyBorder(15, 18, 15, 18));
        card.setFillColor(theme.cardAlt);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 102));
        JPanel body = new JPanel(new BorderLayout(0, 5));
        body.setOpaque(false);
        body.add(Ui.label("AI study tip", theme.smallFont.deriveFont(java.awt.Font.BOLD), theme.accent), BorderLayout.NORTH);
        JLabel tip = Ui.label("<html>Try a 5-minute recall before starting your next topic. It helps your brain connect new ideas to what you already know.</html>", theme.smallFont, theme.muted);
        body.add(tip, BorderLayout.CENTER);
        AccentButton next = AccentButton.ghost("Show another tip  →");
        next.setPreferredSize(new Dimension(154, 31));
        String[] tips = {
                "Try a 5-minute recall before starting your next topic. It helps your brain connect new ideas to what you already know.",
                "After a study block, close your notes and explain the main idea in your own words.",
                "A short review today can make your next revision session easier to remember."
        };
        int[] index = {0};
        next.addActionListener(e -> {
            index[0] = (index[0] + 1) % tips.length;
            tip.setText("<html>" + tips[index[0]] + "</html>");
        });
        JPanel right = new JPanel(new BorderLayout());
        right.setOpaque(false);
        right.add(body, BorderLayout.CENTER);
        right.add(next, BorderLayout.SOUTH);
        CoachArtwork artwork = new CoachArtwork();
        artwork.setPreferredSize(new Dimension(145, 92));
        card.add(artwork, BorderLayout.EAST);
        card.add(right, BorderLayout.CENTER);
        return card;
    }

    static int streak(AppContext ctx) {
        java.util.HashSet<LocalDate> days = new java.util.HashSet<>();
        for (aistudyplanner.model.StudySession session : ctx.data.sessions) {
            for (int offset = 0; offset <= 1; offset++) {
                LocalDate day = session.date.plusDays(offset);
                if (session.minutesOn(day) > 0) days.add(day);
            }
        }
        LocalDate day = days.contains(LocalDate.now()) ? LocalDate.now() : LocalDate.now().minusDays(1);
        int count = 0;
        while (days.contains(day)) { count++; day = day.minusDays(1); }
        return count;
    }
}
