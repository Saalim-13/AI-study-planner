package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.KnowledgeTopic;
import aistudyplanner.model.QuizAttempt;
import aistudyplanner.model.StudySession;
import aistudyplanner.model.StudyTask;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;

/** Weekly evidence-based summary, recommendations, and an activity contribution calendar. */
public final class InsightsScreen {
    private InsightsScreen() { }
    public static JPanel build(AppContext ctx) {
        Theme t=Theme.get(); LocalDate today=LocalDate.now(),start=today.minusDays(6);
        int focused=0,planned=0;int[] hours=new int[24];
        for(LocalDate d=start;!d.isAfter(today);d=d.plusDays(1))focused+=ctx.data.minutesStudiedOn(d);
        for(StudySession s:ctx.data.sessions)if(!s.date.isBefore(start)&&!s.date.isAfter(today)){planned+=s.plannedMinutes;if(s.startedAt!=null){hours[s.startedAt.getHour()]+=s.actualMinutes;}}
        int best=-1;for(int i=0;i<24;i++)if(best<0||hours[i]>hours[best])best=i;
        KnowledgeTopic weakest=ctx.data.knowledge.values().stream().min(Comparator.comparingInt(k->k.mastery)).orElse(null);
        String mostImproved=improvedTopic(ctx.data.quizAttempts);
        StringBuilder report=new StringBuilder("WEEKLY LEARNING REPORT\n"+start+" to "+today+"\n\n");
        report.append("Focused study time: ").append(focused).append(" minutes\nUncompleted planned time: ").append(Math.max(0,planned-focused)).append(" minutes (planned minus recorded focus)\n");
        report.append("Best recorded study time: ").append(best<0||focused==0?"not enough start-time data":String.format("%02d:00–%02d:00",best,(best+1)%24)).append("\n");
        report.append("Most improved topic: ").append(mostImproved).append("\n");
        report.append("Lowest current mastery: ").append(weakest==null?"not enough quiz data":weakest.subject+" / "+weakest.topic+" · "+weakest.mastery+"% · review "+weakest.nextReview).append("\n\n");
        report.append("RECOMMENDED ACTIONS\n");List<String> actions=actions(ctx,weakest);for(int i=0;i<actions.size();i++)report.append(i+1).append(". ").append(actions.get(i)).append("\n");
        JPanel page=Ui.page("Weekly Insights","A short report from your real focus sessions, planner, and quiz history.");
        JTextArea text=new JTextArea(report.toString());text.setEditable(false);text.setLineWrap(true);text.setWrapStyleWord(true);text.setFont(t.bodyFont);text.setForeground(t.text);text.setBackground(t.card);text.setBorder(BorderFactory.createEmptyBorder(14,14,14,14));
        Heatmap heat=new Heatmap(ctx);heat.setPreferredSize(new Dimension(690,125));heat.setToolTipText("");
        AccentButton export=AccentButton.primary("Export weekly report (.txt)");export.setToolTipText("Save this weekly report as a text file");export.addActionListener(e->export(page,report.toString()));
        JComboBox<String> topicFilter=new JComboBox<>();topicFilter.addItem("All topics");for(KnowledgeTopic k:ctx.data.knowledge.values())topicFilter.addItem(k.subject+" / "+k.topic);
        topicFilter.addActionListener(e->heat.setTopic((String)topicFilter.getSelectedItem()));
        JPanel heatTitle=new JPanel(new BorderLayout());heatTitle.setOpaque(false);heatTitle.add(Ui.label("TOPIC ACTIVITY · LAST 12 WEEKS",t.smallFont,t.accent),BorderLayout.WEST);heatTitle.add(topicFilter,BorderLayout.EAST);
        JPanel body=new JPanel(new BorderLayout(0,12));body.setOpaque(false);body.add(heatTitle,BorderLayout.NORTH);body.add(heat,BorderLayout.CENTER);
        JPanel bottom=new JPanel(new BorderLayout(0,10));bottom.setOpaque(false);bottom.add(Ui.scroll(text),BorderLayout.CENTER);bottom.add(export,BorderLayout.SOUTH);
        JPanel content=new JPanel(new GridLayout(2,1,0,14));content.setOpaque(false);content.add(body);content.add(bottom);page.add(content,BorderLayout.CENTER);return page;
    }
    private static String improvedTopic(List<QuizAttempt> attempts){LocalDate today=LocalDate.now();Map<String,int[]> by=new HashMap<>();for(QuizAttempt a:attempts){if(a.when==null)continue;LocalDate d=a.when.toLocalDate();long age=java.time.temporal.ChronoUnit.DAYS.between(d,today);int[] counts=by.computeIfAbsent(a.subject+" / "+a.topic,k->new int[4]);if(age>=0&&age<7){counts[0]++;if(a.correct)counts[1]++;}else if(age>=7&&age<14){counts[2]++;if(a.correct)counts[3]++;}}String best="not enough quiz data across the last two weeks";double gain=0;for(Map.Entry<String,int[]>e:by.entrySet()){int[]c=e.getValue();if(c[0]==0||c[2]==0)continue;double change=c[1]/(double)c[0]-c[3]/(double)c[2];if(change>gain){gain=change;best=e.getKey()+" · +"+Math.round(gain*100)+" accuracy points this week";}}return best;}
    private static List<String> actions(AppContext ctx,KnowledgeTopic weak){List<String>x=new ArrayList<>();List<KnowledgeTopic>due=ctx.knowledge.dueTopics(ctx.data,LocalDate.now());if(!due.isEmpty())x.add("Do a retrieval review for "+due.get(0).subject+" / "+due.get(0).topic+" (due today or overdue).");else if(weak!=null)x.add("Schedule a 15–20 minute review for "+weak.subject+" / "+weak.topic+".");else x.add("Take a short quiz to seed topic mastery estimates and adaptive review dates.");int minutes=ctx.data.minutesStudiedOn(LocalDate.now());x.add(minutes<ctx.data.profile.dailyGoalMinutes?"Choose one manageable focus block toward today's remaining "+Math.max(0,ctx.data.profile.dailyGoalMinutes-minutes)+" minute goal.":"Your study goal is met today; protect time for rest.");long overdue=ctx.data.tasks.stream().filter(t->!t.done&&t.due.isBefore(LocalDate.now())).count();x.add(overdue>0?"Re-plan "+overdue+" overdue task(s) instead of carrying them all forward unchanged.":"Keep tomorrow's plan within the available study-time budget.");return x;}
    private static void export(Component parent,String text){JFileChooser c=new JFileChooser();c.setSelectedFile(new java.io.File("weekly-learning-report.txt"));if(c.showSaveDialog(parent)!=JFileChooser.APPROVE_OPTION)return;try{Files.writeString(c.getSelectedFile().toPath(),text,StandardCharsets.UTF_8);JOptionPane.showMessageDialog(parent,"Weekly report exported.");}catch(IOException e){JOptionPane.showMessageDialog(parent,"Could not export report: "+e.getMessage());}}
    private static final class Heatmap extends JPanel {final AppContext ctx;String topic="All topics";Heatmap(AppContext c){ctx=c;setOpaque(false);}void setTopic(String t){topic=t==null?"All topics":t;repaint();}int minutes(LocalDate day){if("All topics".equals(topic))return ctx.data.minutesStudiedOn(day);int sum=0;for(StudySession s:ctx.data.sessions)if(topic.equals(s.subject+" / "+(s.topic==null?"":s.topic)))sum+=s.minutesOn(day);return sum;}public String getToolTipText(MouseEvent e){int cell=cell(e.getX(),e.getY());if(cell<0||cell>=84)return null;LocalDate day=LocalDate.now().minusDays(83).plusDays(cell);return day+" · "+minutes(day)+" focused minutes · "+topic;}int cell(int x,int y){int size=13,gap=4,col=(x-55)/(size+gap),row=(y-22)/(size+gap);if(x<55||y<22||col<0||col>=12||row<0||row>=7)return -1;return col*7+row;}protected void paintComponent(Graphics g){super.paintComponent(g);Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);LocalDate start=LocalDate.now().minusDays(83);int size=13,gap=4;for(int i=0;i<84;i++){LocalDate d=start.plusDays(i);int m=minutes(d);int col=i/7,row=i%7;Color c=m==0?Theme.get().cardAlt:m<20?new Color(108,78,156):m<45?new Color(145,99,221):m<90?new Color(103,202,173):new Color(76,224,182);x.setColor(c);x.fillRoundRect(55+col*(size+gap),22+row*(size+gap),size,size,4,4);}x.setColor(Theme.get().muted);x.setFont(Theme.get().smallFont);x.drawString("Less",5,70);x.drawString("More",55+12*(size+gap),70);x.drawString("12 weeks ago",55,15);x.drawString("Today",55+11*(size+gap),15);x.dispose();}}
}
