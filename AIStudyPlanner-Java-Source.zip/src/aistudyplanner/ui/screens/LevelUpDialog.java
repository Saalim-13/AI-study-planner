package aistudyplanner.ui.screens;

import aistudyplanner.logic.GamificationService;
import aistudyplanner.ui.Theme;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.Path2D;

/** Small timed Java2D celebration shown when XP crosses a level boundary. */
final class LevelUpDialog {
    private LevelUpDialog() { }
    static void show(Component owner, GamificationService.Award award) {
        Window parent = SwingUtilities.getWindowAncestor(owner);
        JDialog dialog = new JDialog(parent, "Level up!", Dialog.ModalityType.APPLICATION_MODAL);
        JPanel art = new JPanel() {
            long start = System.currentTimeMillis();
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                long elapsed=System.currentTimeMillis()-start;double pulse=1+0.08*Math.sin(elapsed/160.0);
                x.setPaint(new GradientPaint(0,0,new Color(93,50,171),getWidth(),getHeight(),new Color(27,34,74)));
                x.fillRoundRect(0,0,getWidth(),getHeight(),26,26);
                int cx=getWidth()/2,cy=getHeight()/2-8,r=(int)(48*pulse);
                x.setColor(new Color(255,204,92,75));x.fillOval(cx-r-14,cy-r-14,2*r+28,2*r+28);
                x.setColor(new Color(255,208,108));x.fillOval(cx-r,cy-r,2*r,2*r);
                Path2D star=new Path2D.Double();for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;double rr=(i%2==0)?r*.78:r*.36;double px=cx+rr*Math.cos(a),py=cy+rr*Math.sin(a);if(i==0)star.moveTo(px,py);else star.lineTo(px,py);}star.closePath();x.setColor(new Color(111,66,186));x.fill(star);
                x.setFont(Theme.get().titleFont.deriveFont(Font.BOLD,24f));x.setColor(Color.WHITE);String text="LEVEL "+award.newLevel;x.drawString(text,cx-x.getFontMetrics().stringWidth(text)/2,cy+r+38);x.dispose();
            }
        };
        art.setPreferredSize(new Dimension(400,245));
        JLabel sub=new JLabel("You earned "+award.gained+" XP. Keep your learning rhythm going!",JLabel.CENTER);sub.setBorder(BorderFactory.createEmptyBorder(8,12,12,12));
        JPanel content=new JPanel(new BorderLayout());content.setBackground(Theme.get().bg);content.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));content.add(art);content.add(sub,BorderLayout.SOUTH);
        dialog.setContentPane(content);dialog.pack();dialog.setLocationRelativeTo(owner);
        Timer animation=new Timer(40,e->art.repaint());animation.start();
        Timer close=new Timer(2600,e->{animation.stop();dialog.dispose();});close.setRepeats(false);close.start();
        dialog.setVisible(true);
    }
}
