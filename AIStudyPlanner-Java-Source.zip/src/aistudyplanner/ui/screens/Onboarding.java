package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.Subject;
import aistudyplanner.ui.Ui;
import aistudyplanner.ui.Theme;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

/** Three-step first-run wizard kept in Swing for the desktop and legacy applet-style host. */
public final class Onboarding {
    private Onboarding() { }
    public static boolean run(AppContext ctx) {
        if(ctx.data.profile.name!=null&&!ctx.data.profile.name.isBlank())return true;
        JDialog dialog=new JDialog((Frame)null,"Welcome to AI Study Planner",true);dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        CardLayout cards=new CardLayout();JPanel deck=new JPanel(cards);JTextField name=new JTextField(),course=new JTextField(),subjects=new JTextField("Math, Science, English");
        JSpinner hours=new JSpinner(new SpinnerNumberModel(3.0,0.5,12.0,0.5)),weeks=new JSpinner(new SpinnerNumberModel(4,1,24,1));
        JSpinner goal=new JSpinner(new SpinnerNumberModel(90,15,720,15)),focus=new JSpinner(new SpinnerNumberModel(25,5,120,5));
        deck.add(step("1 · About you","A little personalization helps the planner feel like yours.","Your name",name,"Course / class",course),"0");
        deck.add(step("2 · Your studies","Add subjects. You can add detailed topics later.","Subjects (comma separated)",subjects,"Hours available each day",hours,"Weeks until your next exam",weeks),"1");
        deck.add(step("3 · Your rhythm","Set a practical starting goal. You can change these any time.","Daily study goal (minutes)",goal,"Preferred focus block (minutes)",focus),"2");
        JLabel progress=new JLabel("  STEP 1 OF 3");progress.setFont(Theme.get().bodyFont.deriveFont(Font.BOLD,14f));
        JButton back=new JButton("Back"),next=new JButton("Continue"),cancel=new JButton("Cancel");Ui.retroButton(back);Ui.retroButton(next);Ui.retroButton(cancel);back.setToolTipText("Return to the previous onboarding step");next.setToolTipText("Continue to the next onboarding step");cancel.setToolTipText("Close onboarding without saving");
        JPanel buttons=new JPanel(new FlowLayout(FlowLayout.RIGHT));buttons.add(cancel);buttons.add(back);buttons.add(next);
        JPanel root=new JPanel(new BorderLayout(0,12));root.setBorder(BorderFactory.createEmptyBorder(16,16,16,16));root.add(progress,BorderLayout.NORTH);root.add(deck,BorderLayout.CENTER);root.add(buttons,BorderLayout.SOUTH);
        final int[] current={0};final boolean[] saved={false};back.setEnabled(false);
        back.addActionListener(e->{if(current[0]>0){current[0]--;cards.show(deck,""+current[0]);progress.setText("  STEP "+(current[0]+1)+" OF 3");back.setEnabled(current[0]>0);next.setText("Continue");}});
        next.addActionListener(e->{if(current[0]==0&&name.getText().isBlank()){JOptionPane.showMessageDialog(dialog,"Please enter your name to continue.");return;}if(current[0]<2){current[0]++;cards.show(deck,""+current[0]);progress.setText("  STEP "+(current[0]+1)+" OF 3");back.setEnabled(true);if(current[0]==2)next.setText("Finish setup");return;}
            ctx.data.profile.name=name.getText().trim();ctx.data.profile.course=course.getText().trim();ctx.data.profile.availableMinutes=(int)Math.round((Double)hours.getValue()*60);ctx.data.profile.todayAvailableMinutes=ctx.data.profile.availableMinutes;ctx.data.profile.dailyGoalMinutes=(Integer)goal.getValue();ctx.data.profile.focusMinutes=(Integer)focus.getValue();
            LocalDate exam=LocalDate.now().plusWeeks((Integer)weeks.getValue());for(String raw:subjects.getText().split(",")){String s=raw.trim();if(!s.isEmpty()){Subject subject=new Subject(s,exam,3);subject.ensureDefaultTopics();ctx.data.subjects.add(subject);}}
            ctx.saveQuietly();saved[0]=true;dialog.dispose();});
        cancel.addActionListener(e->dialog.dispose());dialog.setContentPane(root);dialog.setSize(520,390);dialog.setLocationRelativeTo(null);dialog.setVisible(true);return saved[0];
    }
    private static JPanel step(String title,String subtitle,Object... fields){JPanel p=new JPanel(new BorderLayout(0,12));JPanel head=new JPanel(new GridLayout(2,1));head.add(new JLabel(title));head.add(new JLabel(subtitle));p.add(head,BorderLayout.NORTH);JPanel form=new JPanel(new GridLayout(0,2,10,10));for(int i=0;i<fields.length;i+=2){JLabel label=new JLabel((String)fields[i]);JComponent control=(JComponent)fields[i+1];label.setToolTipText("Enter "+fields[i]);control.setToolTipText("Your "+((String)fields[i]).toLowerCase());form.add(label);form.add(control);}p.add(form,BorderLayout.CENTER);return p;}
}
