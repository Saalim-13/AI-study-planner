package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.StudyTask;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class PlannerScreen {
    private PlannerScreen() {
    }

    public static void quickAdd(AppContext ctx) {
        editTask(ctx, null, new DefaultListModel<>(), new ArrayList<>());
    }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("Study Planner",
                "Generate a spaced-repetition timetable, then tick blocks off as you go.");

        DefaultListModel<String> model = new DefaultListModel<>();
        List<StudyTask> shown = new ArrayList<>();
        JList<String> list = new JList<>(model);
        list.setFont(theme.bodyFont);
        list.setForeground(theme.text);
        list.setBackground(theme.card);
        fill(ctx, model, shown, "");

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        AccentButton generate = AccentButton.primary("Generate smart plan");
        AccentButton add = AccentButton.ghost("Add task");
        AccentButton search = AccentButton.ghost("Search");
        AccentButton recovery = AccentButton.ghost("Smart recovery");
        top.add(generate);
        top.add(add);
        top.add(search);
        top.add(recovery);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bottom.setOpaque(false);
        AccentButton complete = AccentButton.primary("Mark done");
        AccentButton edit = AccentButton.ghost("Edit");
        AccentButton delete = AccentButton.ghost("Delete");
        bottom.add(complete);
        bottom.add(edit);
        bottom.add(delete);

        generate.addActionListener(e -> {
            if (ctx.data.subjects.isEmpty()) {
                JOptionPane.showMessageDialog(page, "Add subjects first (Subjects tab).");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(page,
                    "Replace unfinished generated blocks with a new plan? Manual tasks are kept.",
                    "Generate plan", JOptionPane.OK_CANCEL_OPTION);
            if (confirm != JOptionPane.OK_OPTION) {
                return;
            }
            ctx.data.tasks.removeIf(t -> !t.done && !StudyTask.MANUAL.equals(t.kind));
            ctx.data.tasks.addAll(ctx.planner.generateSchedule(ctx.data, LocalDate.now()));
            ctx.saveOrWarn();
            fill(ctx, model, shown, "");
        });
        add.addActionListener(e -> editTask(ctx, null, model, shown));
        search.addActionListener(e -> {
            String q = JOptionPane.showInputDialog(page, "Search tasks:");
            fill(ctx, model, shown, q == null ? "" : q);
        });
        recovery.addActionListener(e ->
                JOptionPane.showMessageDialog(page, ctx.planner.recoveryAdvice(ctx.data),
                        "Smart recovery", JOptionPane.INFORMATION_MESSAGE));
        complete.addActionListener(e -> {
            int i = list.getSelectedIndex();
            if (i >= 0) {
                shown.get(i).done = true;
                ctx.saveOrWarn();
                fill(ctx, model, shown, "");
            }
        });
        edit.addActionListener(e -> {
            int i = list.getSelectedIndex();
            if (i >= 0) {
                editTask(ctx, shown.get(i), model, shown);
            }
        });
        delete.addActionListener(e -> {
            int i = list.getSelectedIndex();
            if (i >= 0 && JOptionPane.showConfirmDialog(page, "Delete this task?", "Confirm",
                    JOptionPane.OK_CANCEL_OPTION) == 0) {
                ctx.data.tasks.remove(shown.get(i));
                ctx.saveOrWarn();
                fill(ctx, model, shown, "");
            }
        });

        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setOpaque(false);
        body.add(top, BorderLayout.NORTH);
        body.add(Ui.scroll(list), BorderLayout.CENTER);
        body.add(bottom, BorderLayout.SOUTH);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private static void fill(AppContext ctx, DefaultListModel<String> model,
                             List<StudyTask> shown, String filter) {
        shown.clear();
        model.clear();
        String q = filter.toLowerCase();
        List<StudyTask> copy = new ArrayList<>(ctx.data.tasks);
        copy.sort(Comparator.comparing((StudyTask t) -> t.day).thenComparingInt(t -> -t.priority));
        for (StudyTask task : copy) {
            String row = (task.done ? "✓ " : "○ ") + task.day + "  " + task.label()
                    + "  | " + task.minutes + "m | " + task.kind
                    + (task.due.isBefore(LocalDate.now()) && !task.done ? "  OVERDUE" : "");
            if ((task.subject + " " + task.topic).toLowerCase().contains(q)) {
                shown.add(task);
                model.addElement(row);
            }
        }
    }

    private static void editTask(AppContext ctx, StudyTask old,
                                 DefaultListModel<String> model, List<StudyTask> shown) {
        JTextField subject = new JTextField(old == null ? "" : old.subject);
        JTextField topic = new JTextField(old == null ? "" : old.topic);
        JTextField day = new JTextField(old == null ? LocalDate.now().toString() : old.day.toString());
        JTextField due = new JTextField(old == null ? LocalDate.now().plusDays(1).toString() : old.due.toString());
        JSpinner min = new JSpinner(new SpinnerNumberModel(old == null ? 30 : old.minutes, 5, 600, 5));
        JSpinner pri = new JSpinner(new SpinnerNumberModel(old == null ? 3 : old.priority, 1, 5, 1));
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new javax.swing.JLabel("Subject"));
        form.add(subject);
        form.add(new javax.swing.JLabel("Topic"));
        form.add(topic);
        form.add(new javax.swing.JLabel("Minutes"));
        form.add(min);
        form.add(new javax.swing.JLabel("Priority 1–5"));
        form.add(pri);
        form.add(new javax.swing.JLabel("Plan day YYYY-MM-DD"));
        form.add(day);
        form.add(new javax.swing.JLabel("Deadline YYYY-MM-DD"));
        form.add(due);
        if (JOptionPane.showConfirmDialog(null, form, old == null ? "Add task" : "Edit task",
                JOptionPane.OK_CANCEL_OPTION) != 0) {
            return;
        }
        try {
            if (subject.getText().isBlank() || topic.getText().isBlank()) {
                throw new IllegalArgumentException();
            }
            LocalDate a = LocalDate.parse(day.getText().trim());
            LocalDate b = LocalDate.parse(due.getText().trim());
            if (old == null) {
                ctx.data.tasks.add(new StudyTask(subject.getText().trim(), topic.getText().trim(),
                        (Integer) min.getValue(), (Integer) pri.getValue(), a, b, StudyTask.MANUAL));
            } else {
                old.subject = subject.getText().trim();
                old.topic = topic.getText().trim();
                old.minutes = (Integer) min.getValue();
                old.priority = (Integer) pri.getValue();
                old.day = a;
                old.due = b;
            }
            ctx.saveOrWarn();
            fill(ctx, model, shown, "");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Enter subject, topic, and valid dates (YYYY-MM-DD).");
        }
    }
}
