package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.Flashcard;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Animated local flashcards with a small spaced-repetition schedule. */
final class FlashcardReviewDialog {
    private FlashcardReviewDialog() { }
    static void show(AppContext ctx) {
        List<Flashcard> due=new ArrayList<>();
        for(Flashcard c:ctx.data.flashcards)if(c.nextReview==null||!c.nextReview.isAfter(LocalDate.now()))due.add(c);
        if(due.isEmpty()){
            LocalDate next=ctx.data.flashcards.stream().map(c->c.nextReview).filter(java.util.Objects::nonNull).min(LocalDate::compareTo).orElse(null);
            JOptionPane.showMessageDialog(ctx.applet,ctx.data.flashcards.isEmpty()?"No flashcards yet. They are created automatically from uploaded notes and wrong answers.":"You're caught up. Next flashcard review: "+next);
            return;
        }
        new Review(ctx,due).open();
    }
    private static final class Review {
        final AppContext ctx;final List<Flashcard> cards;int index;JDialog dialog;FlipCard card;JLabel count;
        Review(AppContext c,List<Flashcard> list){ctx=c;cards=list;}
        void open(){dialog=new JDialog(SwingUtilities.getWindowAncestor(ctx.applet),"Flashcard Review",Dialog.ModalityType.APPLICATION_MODAL);dialog.setSize(640,490);dialog.setLocationRelativeTo(ctx.applet);dialog.setLayout(new BorderLayout(12,12));dialog.getContentPane().setBackground(Theme.get().bg);count=new JLabel();count.setForeground(Theme.get().muted);count.setBorder(BorderFactory.createEmptyBorder(14,18,0,18));dialog.add(count,BorderLayout.NORTH);card=new FlipCard();dialog.add(card,BorderLayout.CENTER);JPanel controls=new JPanel(new FlowLayout());controls.setOpaque(false);JButton flip=new JButton("Flip card"),again=new JButton("Again · tomorrow"),got=new JButton("Got it");for(JButton b:new JButton[]{flip,again,got})Ui.retroButton(b);flip.setToolTipText("Reveal the answer with a flip animation");again.setToolTipText("Mark difficult and review tomorrow");got.setToolTipText("Mark recalled and schedule a longer interval");flip.addActionListener(e->card.flip());again.addActionListener(e->rate(false));got.addActionListener(e->rate(true));controls.add(flip);controls.add(again);controls.add(got);dialog.add(controls,BorderLayout.SOUTH);display();dialog.setVisible(true);}
        void display(){if(index>=cards.size()){ctx.saveQuietly();dialog.dispose();JOptionPane.showMessageDialog(ctx.applet,"Flashcard session complete. Your review dates have been updated.");return;}Flashcard c=cards.get(index);count.setText("Card "+(index+1)+" of "+cards.size()+"  •  "+c.subject+" / "+c.topic);card.setContent(c);}
        void rate(boolean recalled){cards.get(index).review(recalled);index++;ctx.saveQuietly();display();}
    }
    private static final class FlipCard extends JPanel {
        Flashcard item;boolean back;float scale=1f;boolean animating;
        FlipCard(){setOpaque(false);setToolTipText("Click Flip card to reveal the answer");}
        void setContent(Flashcard c){item=c;back=false;repaint();}
        void flip(){if(animating)return;animating=true;final boolean old=back;final int[] step={0};Timer t=new Timer(18,e->{step[0]++;scale=step[0]<8?1f-step[0]/8f:(step[0]-8)/8f;if(step[0]==8)back=!old;if(step[0]>=16){scale=1;animating=false;((Timer)e.getSource()).stop();}repaint();});t.start();}
        @Override protected void paintComponent(Graphics g){super.paintComponent(g);if(item==null)return;Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);int w=getWidth(),h=getHeight(),cw=(int)((w-35)*Math.max(.08,scale)),left=(w-cw)/2;x.setPaint(new GradientPaint(left,0,back?new Color(70,63,133):new Color(68,54,118),left+cw,h,new Color(40,86,119)));x.fillRoundRect(left,10,cw,h-20,30,30);x.setColor(new Color(255,255,255,45));x.drawRoundRect(left,10,cw,h-20,30,30);String title=back?"ANSWER":"THINK OF THE ANSWER";x.setFont(Theme.get().smallFont.deriveFont(Font.BOLD));x.setColor(new Color(205,186,255));x.drawString(title,left+24,42);String text=back?item.back+"\n\n"+item.explanation:item.front;drawWrapped(x,text,left+24,68,cw-48,Theme.get().bodyFont.deriveFont(Font.BOLD,17f),Color.WHITE);x.dispose();}
        void drawWrapped(Graphics2D g,String text,int x,int y,int width,Font font,Color color){g.setFont(font);g.setColor(color);FontMetrics fm=g.getFontMetrics();int lineY=y;for(String paragraph:text.split("\\n")){StringBuilder line=new StringBuilder();for(String word:paragraph.split(" ")){String candidate=line.length()==0?word:line+" "+word;if(fm.stringWidth(candidate)>width&&!line.isEmpty()){g.drawString(line.toString(),x,lineY);lineY+=fm.getHeight()+4;line=new StringBuilder(word);}else line=new StringBuilder(candidate);}if(!line.isEmpty()){g.drawString(line.toString(),x,lineY);lineY+=fm.getHeight()+8;}}}
    }
}
