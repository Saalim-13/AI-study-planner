package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.QuizQuestion;
import aistudyplanner.model.StudyTask;
import aistudyplanner.logic.MaterialQuizGenerator;
import aistudyplanner.logic.GamificationService;
import aistudyplanner.logic.QuizService;
import aistudyplanner.storage.QuizBankWriter;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.AnimatedBar;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.time.LocalDate;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

public final class QuizScreen {
    private QuizScreen() {
    }

    public static JPanel build(AppContext ctx) {
        return new QuizPanel(ctx);
    }

    public static JPanel buildDailyPractice(AppContext ctx) {
        return new QuizPanel(ctx, true);
    }

    public static void openMaterialUpload(AppContext ctx) {
        new QuizPanel(ctx).importMaterial();
    }

    private static class QuizPanel extends JPanel {
        final AppContext ctx;
        List<QuizQuestion> items;
        int index;
        int correct;
        int timedOutCount;
        final Set<String> answeredTopics = new LinkedHashSet<>();
        final Set<String> missedTopics = new LinkedHashSet<>();
        final Map<String,int[]> roundScores = new HashMap<>();
        boolean dailyChallenge;
        boolean dailyMode;
        int totalSecondsUsed;
        final List<aistudyplanner.model.QuizAttempt> roundAttempts = new ArrayList<>();
        boolean questionTimedOut;
        int remaining;
        long questionStarted;
        Timer countdown;
        JLabel prompt = new JLabel();
        JLabel clock = new JLabel();
        JRadioButton[] choices = new JRadioButton[4];
        ButtonGroup group = new ButtonGroup();
        JLabel feedback = new JLabel(" ");
        AnimatedBar bar = new AnimatedBar();
        AccentButton submit = AccentButton.primary("Lock in answer");
        JPanel setup;
        JPanel play;

        QuizPanel(AppContext ctx) {
            this(ctx, false);
        }

        QuizPanel(AppContext ctx, boolean dailyMode) {
            super(new BorderLayout(0, 12));
            this.ctx = ctx;
            this.dailyMode = dailyMode;
            setOpaque(false);
            Theme theme = Theme.get();
            JPanel page = Ui.page(dailyMode ? "Daily Practice" : "Quiz Center",
                    ctx.quiz.bankSize() + " questions loaded from data/questions.csv  •  instant feedback, timed");
            add(page, BorderLayout.NORTH);

            setup = new JPanel(new GridLayout(0, 2, 8, 8));
            setup.setOpaque(false);
            List<String> subjects = ctx.quiz.subjects();
            subjects.add(0, "All subjects");
            JComboBox<String> subjectBox = new JComboBox<>(subjects.toArray(new String[0]));
            setup.add(Ui.label("Subject", theme.bodyFont, theme.text));
            setup.add(subjectBox);
            JSpinner questionCount = new JSpinner(new SpinnerNumberModel(5, 1, 50, 1));
            questionCount.setFont(theme.bodyFont);
            setup.add(Ui.label("Questions per round", theme.bodyFont, theme.text));
            setup.add(questionCount);
            AccentButton upload = AccentButton.ghost("＋ Upload notes & create quiz");
            setup.add(upload);
            AccentButton generateMaterial = AccentButton.primary("Generate from loaded material");
            setup.add(generateMaterial);
            AccentButton start = AccentButton.primary("Start quiz");
            setup.add(start);
            AccentButton missed = AccentButton.ghost("Practice missed topics");
            setup.add(missed);
            AccentButton weak = AccentButton.ghost("Practice weak topics");
            setup.add(weak);
            AccentButton bank = AccentButton.ghost("View question bank");
            setup.add(bank);
            AccentButton challenge = AccentButton.primary("Daily challenge · 5 weakest-topic questions");
            setup.add(challenge);
            AccentButton mock = AccentButton.ghost("Start timed mock test");
            setup.add(mock);
            AccentButton notebook = AccentButton.ghost("Mistake notebook");
            setup.add(notebook);
            AccentButton retryMistakes = AccentButton.ghost("Retry missed questions");
            setup.add(retryMistakes);
            AccentButton flashcards = AccentButton.ghost("Review flashcards");
            setup.add(flashcards);
            AccentButton history = AccentButton.ghost("Quiz attempt history");
            setup.add(history);

            play = new JPanel(new BorderLayout(0, 10));
            play.setOpaque(false);
            prompt.setFont(theme.headingFont);
            prompt.setForeground(theme.text);
            clock.setFont(theme.titleFont);
            clock.setForeground(theme.accent);
            JPanel north = new JPanel(new BorderLayout());
            north.setOpaque(false);
            north.add(prompt, BorderLayout.CENTER);
            north.add(clock, BorderLayout.EAST);
            play.add(north, BorderLayout.NORTH);
            JPanel opts = new JPanel(new GridLayout(0, 1, 6, 6));
            opts.setOpaque(false);
            for (int i = 0; i < 4; i++) {
                choices[i] = new JRadioButton();
                choices[i].setOpaque(false);
                choices[i].setForeground(theme.text);
                choices[i].setFont(theme.bodyFont);
                group.add(choices[i]);
                opts.add(choices[i]);
            }
            play.add(opts, BorderLayout.CENTER);
            JPanel south = new JPanel(new BorderLayout(0, 8));
            south.setOpaque(false);
            feedback.setFont(theme.bodyFont);
            feedback.setForeground(theme.muted);
            south.add(feedback, BorderLayout.NORTH);
            south.add(bar, BorderLayout.CENTER);
            south.add(submit, BorderLayout.EAST);
            play.add(south, BorderLayout.SOUTH);
            play.setVisible(false);

            start.addActionListener(e -> {
                String selected = (String) subjectBox.getSelectedItem();
                String filter = "All subjects".equals(selected) ? null : selected;
                begin(ctx.quiz.startQuiz(filter, (int) questionCount.getValue()), setup, play);
            });
            missed.addActionListener(e -> begin(ctx.quiz.startReviewQuiz(ctx.data,
                    (int) questionCount.getValue(), false), setup, play));
            weak.addActionListener(e -> begin(ctx.quiz.startReviewQuiz(ctx.data,
                    (int) questionCount.getValue(), true), setup, play));
            bank.addActionListener(e -> JOptionPane.showMessageDialog(this, ctx.quiz.bankSummary(),
                    "Your question bank", JOptionPane.INFORMATION_MESSAGE));
            challenge.addActionListener(e -> {
                if(LocalDate.now().equals(ctx.data.profile.dailyChallengeDate)){
                    JOptionPane.showMessageDialog(this,"You completed today's challenge already. Come back tomorrow for a fresh weakest-topic set.");
                    return;
                }
                if (ctx.data.knowledge.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Take a quiz first. Your daily challenge is built from your lowest-mastery topics.");
                    return;
                }
                List<QuizQuestion> daily = ctx.quiz.startDailyChallenge(ctx.data);
                if (daily.size() < 5) {
                    JOptionPane.showMessageDialog(this, "This challenge needs five distinct questions from your weakest topics. Upload more study notes or add quiz questions for those topics.");
                    return;
                }
                dailyChallenge = true;
                begin(daily, setup, play);
            });
            mock.addActionListener(e -> MockTestDialog.show(ctx));
            notebook.addActionListener(e -> showMistakes());
            retryMistakes.addActionListener(e -> begin(ctx.quiz.startMistakeQuiz(ctx.data, (int) questionCount.getValue()), setup, play));
            flashcards.addActionListener(e -> FlashcardReviewDialog.show(ctx));
            history.addActionListener(e -> showHistory());
            upload.addActionListener(e -> ctx.applet.showScreen("Upload Material"));
            generateMaterial.addActionListener(e -> generateLoadedMaterialQuiz());
            submit.addActionListener(e -> lockIn());

            JPanel body = new JPanel(new BorderLayout());
            body.setOpaque(false);
            body.add(setup, BorderLayout.NORTH);
            body.add(play, BorderLayout.CENTER);
            add(body, BorderLayout.CENTER);
            if (dailyMode) {
                begin(ctx.quiz.startQuiz(null, 10), setup, play);
            }
        }

        void begin(List<QuizQuestion> chosen, JPanel setup, JPanel play) {
            if (chosen.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "No matching questions yet. Take a quiz first, or upload study notes to build the question bank.",
                        "Nothing to practice", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            items = chosen;
            index = 0;
            correct = 0;
            timedOutCount = 0;
            totalSecondsUsed = 0;
            roundAttempts.clear();
            answeredTopics.clear();
            missedTopics.clear();
            roundScores.clear();
            setup.setVisible(false);
            play.setVisible(true);
            showQuestion();
        }

        void importMaterial() {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Choose study notes (.txt or .md)");
            chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                    "Study notes (TXT, Markdown)", "txt", "md", "markdown"));
            if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
            try {
                Path path = chooser.getSelectedFile().toPath();
                String lower = path.getFileName().toString().toLowerCase();
                if (!lower.endsWith(".txt") && !lower.endsWith(".md") && !lower.endsWith(".markdown")) {
                    JOptionPane.showMessageDialog(this, "Choose a plain text or Markdown file.");
                    return;
                }
                String material = Files.readString(path, StandardCharsets.UTF_8);
                if (material.length() > 1_000_000) {
                    JOptionPane.showMessageDialog(this, "This file is over 1 MB. Please choose a shorter set of notes.");
                    return;
                }
                JTextField subject = new JTextField("My Notes");
                JTextField topic = new JTextField(path.getFileName().toString().replaceFirst("(?i)\\.(txt|md|markdown)$", ""));
                JPanel details = new JPanel(new GridLayout(0, 2, 8, 8));
                details.add(new JLabel("Quiz subject")); details.add(subject);
                details.add(new JLabel("Topic")); details.add(topic);
                if (JOptionPane.showConfirmDialog(this, details, "Label your material", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
                if (subject.getText().isBlank() || topic.getText().isBlank()) {
                    JOptionPane.showMessageDialog(this, "Enter a subject and topic name.");
                    return;
                }
                List<QuizQuestion> generated = MaterialQuizGenerator.generate(material,
                        subject.getText().trim(), "All topics", topic.getText().trim(), 50, "Medium");
                if (generated.isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                            "I couldn't find enough complete sentences and distinct terms to make multiple-choice questions. Add explanatory notes with several full sentences and try again.",
                            "No quiz questions created", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                int confirm = JOptionPane.showConfirmDialog(this,
                        generated.size() + " practice questions were drafted from your notes. They use sentence-completion questions and terms from the same file as answer choices. Add them to your quiz bank?",
                        "Review generated quiz", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
                if (confirm != JOptionPane.OK_OPTION) return;
                Path bank = Paths.get("data", "questions.csv");
                Files.createDirectories(bank.getParent());
                boolean needsHeader = !Files.exists(bank) || Files.size(bank) == 0;
                StringBuilder csv = new StringBuilder();
                if (needsHeader) csv.append("id,subject,topic,question,A,B,C,D,correct,explanation\n");
                for (QuizQuestion q : generated) {
                    csv.append(csv(q.id)).append(',').append(csv(q.subject)).append(',').append(csv(q.topic)).append(',')
                            .append(csv(q.prompt));
                    for (String choice : q.choices) csv.append(',').append(csv(choice));
                    csv.append(',').append((char) ('A' + q.correctIndex)).append(',').append(csv(q.explanation)).append('\n');
                }
                if (Files.exists(bank) && Files.size(bank) > 0) csv.insert(0, "\n");
                Files.writeString(bank, csv, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                for (QuizQuestion q : generated) QuizService.addFlashcard(ctx.data, q);
                ctx.quiz.reload();
                ctx.saveQuietly();
                JOptionPane.showMessageDialog(this,
                        "Added " + generated.size() + " questions. They are saved in data/questions.csv and will be there next time too.",
                        "Quiz bank updated", JOptionPane.INFORMATION_MESSAGE);
                ctx.applet.showScreen("Quiz");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Could not read the notes or update the quiz bank: " + ex.getMessage(),
                        "Material import failed", JOptionPane.ERROR_MESSAGE);
            }
        }

        private static String csv(String value) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }

        void showQuestion() {
            QuizQuestion q = items.get(index);
            prompt.setText("<html>Q" + (index + 1) + "/" + items.size() + "  ·  "
                    + q.subject + " / " + q.topic + "<br>" + q.prompt + "</html>");
            group.clearSelection();
            for (int i = 0; i < 4; i++) {
                choices[i].setText((char) ('A' + i) + "  " + q.choices[i]);
                choices[i].setEnabled(true);
            }
            feedback.setText("Pick an answer before the timer hits zero.");
            submit.setEnabled(true);
            remaining = ctx.data.profile.quizSeconds;
            questionTimedOut = false;
            questionStarted = System.currentTimeMillis();
            clock.setText(remaining + "s");
            bar.setProgress(index / (float) items.size(), "Question " + (index + 1));
            if (countdown != null) {
                countdown.stop();
            }
            countdown = new Timer(1000, e -> {
                remaining--;
                clock.setText(Math.max(0, remaining) + "s");
                if (remaining <= 0) {
                    ((Timer) e.getSource()).stop();
                    questionTimedOut = true;
                    lockIn();
                }
            });
            countdown.start();
        }

        void lockIn() {
            if (items == null || index >= items.size() || !submit.isEnabled()) {
                return;
            }
            if (countdown != null) {
                countdown.stop();
            }
            QuizQuestion q = items.get(index);
            int chosen = -1;
            for (int i = 0; i < 4; i++) {
                if (choices[i].isSelected()) {
                    chosen = i;
                }
                choices[i].setEnabled(false);
            }
            int seconds = (int) Math.max(0, (System.currentTimeMillis() - questionStarted) / 1000);
            ctx.quiz.record(ctx.data, q, chosen, seconds, questionTimedOut);
            roundAttempts.add(ctx.data.quizAttempts.get(ctx.data.quizAttempts.size() - 1));
            totalSecondsUsed += seconds;
            if (questionTimedOut) timedOutCount++;
            // Persist every answer immediately, including an option selected when the clock expires.
            ctx.saveQuietly();
            boolean ok = chosen == q.correctIndex;
            answeredTopics.add(q.subject + " / " + q.topic);
            if (!ok) missedTopics.add(q.subject + " / " + q.topic);
            int[] topicScore=roundScores.computeIfAbsent(q.subject+"\n"+q.topic,k->new int[2]);
            topicScore[1]++;if(ok)topicScore[0]++;
            if (ok) {
                correct++;
            }
            Theme theme = Theme.get();
            feedback.setForeground(ok ? theme.success : theme.danger);
            feedback.setText("<html>" + (questionTimedOut
                    ? (chosen >= 0 ? "Time is up — your selected answer was saved. " : "Time is up — this question was saved as skipped. ")
                    : "") + (ok ? "Correct. " : "Not quite. Answer is "
                    + (char) ('A' + q.correctIndex) + ". ")
                    + q.explanation + "</html>");
            submit.setEnabled(false);
            Timer pause = new Timer(ok ? 900 : 1600, e -> {
                ((Timer) e.getSource()).stop();
                index++;
                if (index >= items.size()) {
                    finish();
                } else {
                    showQuestion();
                }
            });
            pause.setRepeats(false);
            pause.start();
        }

        void finish() {
            bar.setProgress(1f, "Done");
            String sessionId = UUID.randomUUID().toString();
            int wrong = 0;
            for (aistudyplanner.model.QuizAttempt attempt : roundAttempts) {
                attempt.quizSessionId = sessionId;
                attempt.quizSessionSize = items.size();
                attempt.quizSessionScore = correct;
                attempt.quizSessionSeconds = totalSecondsUsed;
                if (!attempt.correct && !"Skipped".equals(attempt.learnerAnswer)) wrong++;
            }
            for(Map.Entry<String,int[]> entry:roundScores.entrySet()){
                String[] key=entry.getKey().split("\n",2);int[] score=entry.getValue();
                ctx.knowledge.recordQuiz(ctx.data,key[0],key[1],score[0]/(double)Math.max(1,score[1]),LocalDate.now());
            }
            GamificationService.Award award = new GamificationService().awardQuiz(ctx, correct, items.size());
            if (dailyChallenge) ctx.data.profile.dailyChallengeDate = LocalDate.now();
            if (dailyMode) ctx.data.profile.dailyPracticeDate = LocalDate.now();
            rebalancePlan(ctx);
            StringBuilder why = new StringBuilder("Why did the plan change?\n\n");
            if (missedTopics.isEmpty()) {
                why.append("You recalled the topics in this round, so their next SM-2 reviews are spaced farther apart. New due dates were added to your planner.");
            } else {
                why.append("A missed answer lowers that topic's mastery and brings its next review forward. The planner rebuilt upcoming generated blocks using your updated quiz results.\n\nReview soon: ");
                why.append(String.join(", ", missedTopics)).append('.');
            }
            StringBuilder result = new StringBuilder("QUIZ RESULT\n\n")
                    .append("Score: ").append(correct).append(" / ").append(items.size())
                    .append("  ·  Correct: ").append(correct).append("  ·  Wrong: ").append(wrong)
                    .append("  ·  Time: ").append(formatDuration(totalSecondsUsed)).append("\n")
                    .append("XP earned: +").append(award.gained).append("\n");
            if (timedOutCount > 0) result.append("Timed-out responses saved: ").append(timedOutCount).append("\n");
            result.append("\nANSWER REVIEW\n");
            for (int i = 0; i < roundAttempts.size(); i++) {
                aistudyplanner.model.QuizAttempt attempt = roundAttempts.get(i);
                result.append(i + 1).append(attempt.correct ? ". CORRECT — " : ". REVIEW — ")
                        .append(attempt.subject).append(" / ").append(attempt.topic).append('\n')
                        .append("Your answer: ").append(attempt.learnerAnswer).append("  ·  Correct: ").append(attempt.correctAnswer).append('\n')
                        .append(attempt.explanation).append("\n\n");
            }
            result.append(why);
            if (!award.newBadges.isEmpty()) result.append("\n\nBadges earned: ").append(String.join(", ", award.newBadges));
            ctx.saveQuietly();
            JTextArea report = new JTextArea(result.toString(), 22, 68);
            report.setEditable(false);
            report.setLineWrap(true);
            report.setWrapStyleWord(true);
            report.setFont(Theme.get().bodyFont);
            JOptionPane.showMessageDialog(this, new javax.swing.JScrollPane(report),
                    "Quiz result · Why did the plan change?", JOptionPane.INFORMATION_MESSAGE);
            if (award.newLevel > award.oldLevel) LevelUpDialog.show(ctx.applet, award);
            ctx.applet.showScreen("Progress");
        }

        void generateLoadedMaterialQuiz() {
            if (ctx.data.activeMaterialText == null || ctx.data.activeMaterialText.isBlank()) {
                JOptionPane.showMessageDialog(this, "Upload and analyze study material first.", "No material loaded", JOptionPane.INFORMATION_MESSAGE);
                ctx.applet.showScreen("Upload Material");
                return;
            }
            List<String> subjects = ctx.quiz.subjects();
            if (!subjects.contains("Uploaded Material")) subjects.add("Uploaded Material");
            JComboBox<String> subject = new JComboBox<>(subjects.toArray(new String[0]));
            subject.setSelectedItem("Uploaded Material");
            List<String> topics = new ArrayList<>();
            topics.add("All topics");
            for (String term : MaterialQuizGenerator.suggestTopics(ctx.data.activeMaterialText)) if (!topics.contains(term)) topics.add(term);
            JComboBox<String> topic = new JComboBox<>(topics.toArray(new String[0]));
            JSpinner count = new JSpinner(new SpinnerNumberModel(10, 1, 50, 1));
            JComboBox<String> difficulty = new JComboBox<>(new String[]{"Easy", "Medium", "Hard"});
            JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
            form.add(new JLabel("Subject")); form.add(subject);
            form.add(new JLabel("Topic focus")); form.add(topic);
            form.add(new JLabel("Number of questions")); form.add(count);
            form.add(new JLabel("Difficulty")); form.add(difficulty);
            if (JOptionPane.showConfirmDialog(this, form, "Build a quiz from your material", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;

            String chosenTopic = String.valueOf(topic.getSelectedItem());
            String labelTopic = "All topics".equals(chosenTopic) ? ctx.data.activeMaterialName : chosenTopic;
            List<QuizQuestion> generated = MaterialQuizGenerator.generate(ctx.data.activeMaterialText,
                    String.valueOf(subject.getSelectedItem()), chosenTopic, labelTopic,
                    (Integer) count.getValue(), String.valueOf(difficulty.getSelectedItem()));
            if (generated.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No complete statements matched this topic and difficulty. Choose All topics or another difficulty.",
                        "No questions generated", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            try {
                new QuizBankWriter().append(Paths.get("data", "questions.csv"), generated);
                for (QuizQuestion q : generated) QuizService.addFlashcard(ctx.data, q);
                ctx.quiz.reload();
                ctx.saveQuietly();
                begin(generated, setup, play);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Generated questions could not be saved: " + ex.getMessage(),
                        "Quiz save failed", JOptionPane.ERROR_MESSAGE);
            }
        }

        void showHistory() {
            StringBuilder text = new StringBuilder("RECENT QUIZ SESSIONS\n\n");
            java.util.Set<String> seen = new java.util.HashSet<>();
            int shown = 0, right = 0, answers = 0;
            for (int i = ctx.data.quizAttempts.size() - 1; i >= 0 && shown < 20; i--) {
                aistudyplanner.model.QuizAttempt attempt = ctx.data.quizAttempts.get(i);
                if (attempt.quizSessionId != null && !attempt.quizSessionId.isBlank()) {
                    if (!seen.add(attempt.quizSessionId)) continue;
                    shown++;
                    right += attempt.quizSessionScore;
                    answers += attempt.quizSessionSize;
                    text.append(attempt.when == null ? "Saved result" : attempt.when.toLocalDate()).append("  ·  ")
                            .append(attempt.quizSessionScore).append(" / ").append(attempt.quizSessionSize).append(" correct  ·  ")
                            .append(formatDuration(attempt.quizSessionSeconds)).append("\n");
                } else {
                    shown++; answers++;
                    if (attempt.correct) right++;
                    text.append(attempt.when == null ? "Saved result" : attempt.when.toLocalDate()).append("  ·  ")
                            .append(attempt.subject).append(" / ").append(attempt.topic).append("  ·  ")
                            .append(attempt.correct ? "Correct" : "Review");
                    if (attempt.timedOut) text.append("  ·  Timed out and saved");
                    text.append('\n');
                }
            }
            if (shown == 0) text.append("Complete a quiz and your saved attempts will appear here.");
            else text.insert("RECENT QUIZ SESSIONS\n\n".length(), "Recent accuracy: " + right + " / " + answers + " answers\n\n");
            JTextArea area = new JTextArea(text.toString(), 18, 62);
            area.setEditable(false); area.setLineWrap(true); area.setWrapStyleWord(true);
            JOptionPane.showMessageDialog(this, new javax.swing.JScrollPane(area), "Quiz attempt history", JOptionPane.INFORMATION_MESSAGE);
        }

        private String formatDuration(int seconds) {
            return String.format("%d min %02d sec", seconds / 60, seconds % 60);
        }

        void showMistakes() {
            StringBuilder text = new StringBuilder("MISTAKE NOTEBOOK\n\n");
            int count=0;
            for (int i=ctx.data.quizAttempts.size()-1;i>=0;i--) {
                aistudyplanner.model.QuizAttempt a=ctx.data.quizAttempts.get(i);
                if(a.correct)continue;
                count++;
                text.append(a.subject).append(" / ").append(a.topic).append("\n")
                        .append(a.prompt).append("\nYour answer: ").append(a.learnerAnswer)
                        .append(" | Correct: ").append(a.correctAnswer).append("\n")
                        .append(a.explanation).append("\n\n");
                if(count>=30)break;
            }
            if(count==0)text.append("No mistakes saved yet. Wrong quiz answers will appear here with their explanations.");
            JTextArea area=new JTextArea(text.toString(),20,65);area.setEditable(false);area.setLineWrap(true);area.setWrapStyleWord(true);
            JOptionPane.showMessageDialog(this,new javax.swing.JScrollPane(area),"Mistake notebook",JOptionPane.INFORMATION_MESSAGE);
        }
    }

    static void rebalancePlan(AppContext ctx) {
        LocalDate today=LocalDate.now();
        ctx.data.tasks.removeIf(task -> !task.done && !StudyTask.MANUAL.equals(task.kind) && !task.day.isBefore(today));
        ctx.data.tasks.addAll(ctx.planner.generateSchedule(ctx.data,today));
        ctx.saveQuietly();
    }
}

