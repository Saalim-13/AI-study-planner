package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.Flashcard;
import aistudyplanner.model.KnowledgeTopic;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Saved retrieval-practice cards and topic review dates. */
public final class RevisionNotesScreen {
    private RevisionNotesScreen() { }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("Revision Notes", "Review questions, explanations, and topics due for another pass.");
        JPanel stack = new JPanel();
        stack.setOpaque(false);
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));

        if (ctx.data.activeMaterialAnalysis != null && !ctx.data.activeMaterialAnalysis.isBlank()) {
            RoundedPanel notes = Ui.card();
            notes.setAlignmentX(Component.LEFT_ALIGNMENT);
            notes.setLayout(new BorderLayout(0, 9));
            notes.add(Ui.label("Material study brief", theme.headingFont, theme.text), BorderLayout.NORTH);
            javax.swing.JTextArea brief = new javax.swing.JTextArea(ctx.data.activeMaterialAnalysis, 9, 60);
            brief.setEditable(false);
            brief.setLineWrap(true);
            brief.setWrapStyleWord(true);
            brief.setFont(theme.bodyFont);
            brief.setForeground(theme.text);
            brief.setBackground(theme.cardAlt);
            brief.setBorder(javax.swing.BorderFactory.createEmptyBorder(9, 10, 9, 10));
            notes.add(Ui.scroll(brief), BorderLayout.CENTER);
            AccentButton openMaterial = AccentButton.ghost("Manage study material");
            openMaterial.addActionListener(e -> ctx.applet.showScreen("Upload Material"));
            notes.add(openMaterial, BorderLayout.SOUTH);
            stack.add(notes);
            stack.add(Box.createVerticalStrut(14));
        }

        RoundedPanel cards = Ui.card();
        cards.setAlignmentX(Component.LEFT_ALIGNMENT);
        cards.add(Ui.label("Flashcards", theme.headingFont, theme.text), BorderLayout.NORTH);
        cards.add(Ui.label(ctx.data.flashcards.isEmpty()
                ? "Cards are created automatically from missed answers and imported notes."
                : ctx.data.flashcards.size() + " saved card(s) · " + dueCards(ctx.data.flashcards) + " due today.",
                theme.bodyFont, theme.muted), BorderLayout.CENTER);
        AccentButton review = AccentButton.primary("Review due flashcards");
        review.setToolTipText("Practice cards scheduled for today with spaced repetition");
        review.addActionListener(e -> FlashcardReviewDialog.show(ctx));
        cards.add(review, BorderLayout.SOUTH);
        stack.add(cards);
        stack.add(Box.createVerticalStrut(14));

        RoundedPanel topics = Ui.card();
        topics.setAlignmentX(Component.LEFT_ALIGNMENT);
        topics.setLayout(new BorderLayout(0, 9));
        topics.add(Ui.label("Topic review queue", theme.headingFont, theme.text), BorderLayout.NORTH);
        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        List<KnowledgeTopic> ordered = new ArrayList<>(ctx.data.knowledge.values());
        ordered.sort(Comparator.comparing((KnowledgeTopic t) -> t.nextReview == null ? LocalDate.MIN : t.nextReview)
                .thenComparingInt(t -> t.mastery));
        if (ordered.isEmpty()) {
            list.add(Ui.label("Take a quiz to start tracking topic mastery and review dates.", theme.bodyFont, theme.muted));
        } else {
            for (KnowledgeTopic topic : ordered) {
                String due = topic.nextReview == null || !topic.nextReview.isAfter(LocalDate.now())
                        ? "Due now" : "Review " + topic.nextReview;
                JLabel label = Ui.label(topic.subject + "  ·  " + topic.topic + "  ·  " + topic.mastery + "%  ·  " + due,
                        theme.bodyFont, theme.text);
                label.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 2, 5, 2));
                list.add(label);
            }
        }
        topics.add(Ui.scroll(list), BorderLayout.CENTER);
        stack.add(topics);
        page.add(Ui.scroll(stack), BorderLayout.CENTER);
        return page;
    }

    private static long dueCards(List<Flashcard> cards) {
        return cards.stream().filter(c -> c.nextReview == null || !c.nextReview.isAfter(LocalDate.now())).count();
    }
}
