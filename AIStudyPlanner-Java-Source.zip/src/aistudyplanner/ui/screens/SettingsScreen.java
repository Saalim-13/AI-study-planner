package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import aistudyplanner.logic.DailyCheckIn;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.nio.file.Files;

public final class SettingsScreen {
    private SettingsScreen() {
    }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("Settings", "Profile, timers, theme, and local backups.");

        JTextField name = new JTextField(ctx.data.profile.name);
        JTextField course = new JTextField(ctx.data.profile.course);
        JSpinner avail = new JSpinner(new SpinnerNumberModel(ctx.data.profile.availableMinutes, 15, 960, 15));
        JSpinner goal = new JSpinner(new SpinnerNumberModel(ctx.data.profile.dailyGoalMinutes, 15, 960, 15));
        JSpinner focus = new JSpinner(new SpinnerNumberModel(ctx.data.profile.focusMinutes, 5, 180, 5));
        JSpinner quiz = new JSpinner(new SpinnerNumberModel(ctx.data.profile.quizSeconds, 10, 120, 5));
        JSpinner weak = new JSpinner(new SpinnerNumberModel(ctx.data.profile.weakThreshold, 30, 90, 5));
        JSpinner fontSize = new JSpinner(new SpinnerNumberModel(ctx.data.profile.fontSizePercent, 85, 130, 5));
        JComboBox<String> examType = new JComboBox<>(new String[]{"UPSC", "TNPSC"});
        examType.setSelectedItem(ctx.data.profile.examType);
        JCheckBox auto = new JCheckBox("Auto-start a break after a completed pomodoro", ctx.data.profile.autoBreak);
        JCheckBox sound = new JCheckBox("Play a gentle sound for reminders and focus completion", ctx.data.profile.soundEnabled);
        JCheckBox onlineAi = new JCheckBox("Enable optional OpenAI mentor (sends chat and extracted material text)", ctx.data.profile.onlineAiEnabled);
        JTextField reminder = new JTextField(ctx.data.profile.reminderTime == null ? "19:00" : ctx.data.profile.reminderTime);
        AccentButton accent = AccentButton.ghost("Choose accent colour");
        try { accent.setBackground(Color.decode(ctx.data.profile.accentHex)); } catch (Exception ignored) { }
        auto.setOpaque(false);
        auto.setForeground(theme.text);
        onlineAi.setOpaque(false);
        onlineAi.setForeground(theme.text);
        onlineAi.setToolTipText("Only when selected and OPENAI_API_KEY is configured, Study-Wise sends your message and loaded material text to OpenAI for a reply.");
        Ui.styleField(name);
        Ui.styleField(course);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setOpaque(false);
        form.add(Ui.label("Name", theme.bodyFont, theme.text));
        form.add(name);
        form.add(Ui.label("Course", theme.bodyFont, theme.text));
        form.add(course);
        form.add(Ui.label("Available minutes / day", theme.bodyFont, theme.text));
        form.add(avail);
        form.add(Ui.label("Daily goal minutes", theme.bodyFont, theme.text));
        form.add(goal);
        form.add(Ui.label("Focus block minutes", theme.bodyFont, theme.text));
        form.add(focus);
        form.add(Ui.label("Quiz seconds / question", theme.bodyFont, theme.text));
        form.add(quiz);
        form.add(Ui.label("Weak-topic threshold %", theme.bodyFont, theme.text));
        form.add(weak);
        form.add(Ui.label("Interface font size (%)", theme.bodyFont, theme.text));
        form.add(fontSize);
        form.add(Ui.label("Exam focus", theme.bodyFont, theme.text));
        form.add(examType);
        form.add(Ui.label("Breaks", theme.bodyFont, theme.text));
        form.add(auto);
        form.add(Ui.label("Daily reminder time (24-hour HH:mm)", theme.bodyFont, theme.text));
        form.add(reminder);
        form.add(Ui.label("Notifications", theme.bodyFont, theme.text));
        form.add(sound);
        form.add(Ui.label("Online AI & privacy", theme.bodyFont, theme.text));
        form.add(onlineAi);
        form.add(Ui.label("Accent colour", theme.bodyFont, theme.text));
        form.add(accent);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        actions.setOpaque(false);
        AccentButton save = AccentButton.primary("Save");
        AccentButton backup = AccentButton.ghost("Create backup");
        AccentButton restore = AccentButton.ghost("Restore backup");
        AccentButton reset = AccentButton.ghost("Reset all data");
        AccentButton themeBtn = AccentButton.ghost(theme.dark ? "Use light theme" : "Use dark theme");
        actions.add(save);
        actions.add(backup);
        actions.add(restore);
        actions.add(reset);
        actions.add(themeBtn);
        accent.addActionListener(e -> {
            Color chosen=JColorChooser.showDialog(page,"Choose accent colour",Theme.get().accent);
            if(chosen!=null){Theme.get().setAccent(chosen);ctx.data.profile.accentHex=String.format("#%02X%02X%02X",chosen.getRed(),chosen.getGreen(),chosen.getBlue());accent.repaint();ctx.applet.refreshTheme();}
        });

        save.addActionListener(e -> {
            LocalTime reminderValue;
            try { reminderValue=LocalTime.parse(reminder.getText().trim(),DateTimeFormatter.ofPattern("HH:mm")); }
            catch(Exception ex){JOptionPane.showMessageDialog(page,"Enter reminder time as 24-hour HH:mm, for example 19:30.");return;}
            ctx.data.profile.name = name.getText().trim();
            ctx.data.profile.course = course.getText().trim();
            ctx.data.profile.availableMinutes = (Integer) avail.getValue();
            ctx.data.profile.dailyGoalMinutes = (Integer) goal.getValue();
            ctx.data.profile.focusMinutes = (Integer) focus.getValue();
            ctx.data.profile.quizSeconds = (Integer) quiz.getValue();
            ctx.data.profile.weakThreshold = (Integer) weak.getValue();
            ctx.data.profile.fontSizePercent = (Integer) fontSize.getValue();
            ctx.data.profile.examType = String.valueOf(examType.getSelectedItem());
            ctx.data.profile.autoBreak = auto.isSelected();
            ctx.data.profile.soundEnabled=sound.isSelected();
            ctx.data.profile.onlineAiEnabled=onlineAi.isSelected();
            ctx.data.profile.reminderTime=reminderValue.format(DateTimeFormatter.ofPattern("HH:mm"));
            ctx.data.profile.accentHex=String.format("#%02X%02X%02X",Theme.get().accent.getRed(),Theme.get().accent.getGreen(),Theme.get().accent.getBlue());
            ctx.data.profile.darkTheme = Theme.get().dark;
            Theme.get().setFontSizePercent(ctx.data.profile.fontSizePercent);
            ctx.saveOrWarn();
            ctx.applet.refreshTheme();
            ctx.applet.showScreen("Dashboard");
        });
        backup.addActionListener(e -> {
            ctx.saveOrWarn();
            JOptionPane.showMessageDialog(page, "Backup stored at " + ctx.store.backupPath());
        });
        restore.addActionListener(e -> {
            if (!Files.exists(ctx.store.backupPath())) {
                JOptionPane.showMessageDialog(page, "No backup exists yet.");
                return;
            }
            if (JOptionPane.showConfirmDialog(page, "Replace current data with backup?", "Confirm",
                    JOptionPane.OK_CANCEL_OPTION) != 0) {
                return;
            }
            try {
                ctx.store.restoreBackup();
                ctx.data.replaceWith(ctx.store.load());
                Theme.get().setDark(ctx.data.profile.darkTheme);
            try { Theme.get().setAccent(Color.decode(ctx.data.profile.accentHex)); } catch(Exception ignored) { }
                ctx.applet.showScreen("Dashboard");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(page, ex.getMessage());
            }
        });
        reset.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(page, "Delete saved profile and all data?", "Confirm reset",
                    JOptionPane.OK_CANCEL_OPTION) != 0) {
                return;
            }
            ctx.data.profile = new aistudyplanner.model.Profile();
            ctx.data.subjects.clear();
            ctx.data.tasks.clear();
            ctx.data.sessions.clear();
            ctx.data.quizAttempts.clear();
            ctx.data.favorites.clear();
            ctx.data.distractions.clear();
            ctx.data.reflections.clear();
            ctx.data.knowledge.clear();
            ctx.data.badges.clear();
            ctx.data.flashcards.clear();
            ctx.data.xp=0;
            ctx.saveOrWarn();
            if (Onboarding.run(ctx)) {
                DailyCheckIn.run(ctx);
                ctx.applet.showScreen("Dashboard");
            }
        });
        themeBtn.addActionListener(e -> ctx.applet.toggleTheme());

        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setOpaque(false);
        body.add(form, BorderLayout.NORTH);
        body.add(actions, BorderLayout.SOUTH);
        page.add(body, BorderLayout.CENTER);
        return page;
    }
}
