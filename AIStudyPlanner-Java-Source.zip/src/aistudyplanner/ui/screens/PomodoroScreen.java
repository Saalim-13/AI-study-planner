package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.StudyTask;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;
import aistudyplanner.util.TimeFmt;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public final class PomodoroScreen {
    private PomodoroScreen() {
    }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        String title = ctx.applet.breakMode ? "Break" : "Pomodoro";
        JPanel page = Ui.page(title,
                "Energy " + ctx.data.profile.energy + "/5  •  Space starts or pauses  •  "
                        + ctx.applet.focusSubject);

        Dial dial = new Dial(ctx);
        dial.setPreferredSize(new Dimension(280, 280));
        JLabel clock = new JLabel(TimeFmt.clock(ctx.applet.remaining), JLabel.CENTER);
        clock.setFont(theme.titleFont.deriveFont(Font.BOLD, 48f));
        clock.setForeground(theme.text);
        ctx.applet.clockLabel = clock;

        JComboBox<Integer> duration = new JComboBox<>(new Integer[]{15, 25, 45, 60});
        int suggestedFocus = ctx.data.profile.checkInDate != null
                && ctx.data.profile.checkInDate.equals(java.time.LocalDate.now()) && ctx.data.profile.energy <= 2
                ? 15 : ctx.data.profile.focusMinutes;
        duration.setSelectedItem(Math.min(60, Math.max(15, suggestedFocus)));
        JComboBox<Integer> energy = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
        energy.setSelectedItem(ctx.data.profile.energy);
        energy.addActionListener(e -> {
            ctx.data.profile.energy = (Integer) energy.getSelectedItem();
            ctx.saveQuietly();
        });

        AccentButton toggle = AccentButton.primary(ctx.applet.running ? "Pause" : "Start");
        AccentButton reset = AccentButton.ghost("Reset");
        AccentButton skip = AccentButton.ghost("Skip");
        AccentButton brk = AccentButton.ghost("Start break");
        AccentButton park = AccentButton.ghost("Park distraction");

        toggle.addActionListener(e -> {
            if (ctx.applet.running) {
                ctx.applet.pauseTimer();
            } else {
                if (ctx.applet.remaining <= 0) {
                    ctx.applet.remaining = (Integer) duration.getSelectedItem() * 60;
                    ctx.applet.planned = ctx.applet.remaining;
                    ctx.applet.breakMode = false;
                    StudyTask next = ctx.planner.nextTask(ctx.data);
                    ctx.applet.focusSubject = next == null ? "General" : next.subject;
                    ctx.applet.focusTopic = next == null ? "" : next.topic;
                }
                ctx.applet.startTimer();
            }
            toggle.setText(ctx.applet.running ? "Pause" : "Resume");
            clock.setText(TimeFmt.clock(ctx.applet.remaining));
        });
        reset.addActionListener(e -> {
            ctx.applet.resetTimer();
            clock.setText("00:00");
            toggle.setText("Start");
            dial.repaint();
        });
        skip.addActionListener(e -> {
            ctx.applet.skipBlock();
            clock.setText("00:00");
            toggle.setText("Start");
        });
        brk.addActionListener(e -> {
            ctx.applet.startBreak();
            ctx.applet.showScreen("Pomodoro");
        });
        park.addActionListener(e -> {
            String note = JOptionPane.showInputDialog(page, "Park the thought, then return to focus:");
            if (note != null && !note.isBlank()) {
                ctx.data.distractions.add(java.time.LocalTime.now() + " — " + note.trim());
                ctx.saveOrWarn();
            }
        });

        JPanel controls = new JPanel(new FlowLayout());
        controls.setOpaque(false);
        controls.add(duration);
        controls.add(energy);
        controls.add(toggle);
        controls.add(reset);
        controls.add(skip);
        controls.add(brk);
        controls.add(park);

        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        JPanel dialWrap = new JPanel(new BorderLayout());
        dialWrap.setOpaque(false);
        dialWrap.add(dial, BorderLayout.CENTER);
        dialWrap.add(clock, BorderLayout.SOUTH);
        center.add(dialWrap, BorderLayout.CENTER);
        center.add(controls, BorderLayout.SOUTH);
        page.add(center, BorderLayout.CENTER);
        page.add(Ui.label("Distractions parked: " + ctx.data.distractions.size()
                + "  •  completed pomodoros: " + ctx.applet.completedPomodoros, theme.smallFont, theme.muted),
                BorderLayout.SOUTH);
        return page;
    }

    private static class Dial extends JPanel {
        final AppContext ctx;

        Dial(AppContext ctx) {
            this.ctx = ctx;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Theme theme = Theme.get();
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int size = Math.min(getWidth(), getHeight()) - 20;
            int x = (getWidth() - size) / 2;
            int y = (getHeight() - size) / 2;
            float pct = ctx.applet.planned == 0 ? 0f
                    : (ctx.applet.planned - ctx.applet.remaining) / (float) ctx.applet.planned;
            g2.setStroke(new java.awt.BasicStroke(14f, java.awt.BasicStroke.CAP_ROUND, java.awt.BasicStroke.JOIN_ROUND));
            g2.setColor(theme.cardAlt);
            g2.drawArc(x, y, size, size, 90, -360);
            g2.setColor(ctx.applet.breakMode ? theme.muted : theme.accent);
            g2.drawArc(x, y, size, size, 90, (int) (-360 * pct));
            g2.dispose();
        }
    }
}
