package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.logic.CompetencyAnalyzer;
import aistudyplanner.model.StudySession;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.File;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

public final class ProgressScreen {
    private ProgressScreen() {
    }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("Progress",
                "Study minutes, quiz gaps, and a weekly chart painted with Java2D.");

        int[] minutes = new int[7];
        String[] labels = new String[7];
        int week = 0;
        for (int i = 6; i >= 0; i--) {
            LocalDate day = LocalDate.now().minusDays(i);
            int m = ctx.data.minutesStudiedOn(day);
            minutes[6 - i] = m;
            labels[6 - i] = day.getDayOfWeek().toString().substring(0, 3);
            week += m;
        }

        WeekChart chart = new WeekChart(minutes, labels);
        chart.setPreferredSize(new Dimension(400, 180));

        StringBuilder gaps = new StringBuilder("Competency by topic\n");
        List<CompetencyAnalyzer.TopicScore> scores = ctx.competency.scores(ctx.data);
        if (scores.isEmpty()) {
            gaps.append("Take a quiz to unlock topic scores.\n");
        }
        for (CompetencyAnalyzer.TopicScore score : scores) {
            gaps.append(score.weak ? "! " : "  ")
                    .append(score.subject).append(" / ").append(score.topic)
                    .append("  ").append(score.percent).append("%  (")
                    .append(score.correct).append("/").append(score.attempts).append(")")
                    .append(score.weak ? "  WEAK — extra plan time" : "")
                    .append("\n");
        }
        gaps.append("\nAdaptive Knowledge Model\n");
        if (ctx.data.knowledge.isEmpty()) gaps.append("Take a quiz or focus on a planned topic to start tracking mastery and retention.\n");
        for (aistudyplanner.model.KnowledgeTopic state : ctx.data.knowledge.values()) {
            gaps.append("  ").append(state.subject).append(" / ").append(state.topic)
                    .append("  mastery ").append(state.mastery).append("%  confidence ")
                    .append(Math.round(state.confidence*100)).append("%  retained ")
                    .append(Math.round(state.estimatedRetention(LocalDate.now())*100)).append("%\n")
                    .append("    last studied: ").append(state.lastStudied==null?"not yet":state.lastStudied)
                    .append("  •  next review: ").append(state.nextReview).append("\n");
        }
        JTextArea area = new JTextArea(gaps.toString());
        area.setEditable(false);
        area.setFont(Theme.get().bodyFont);
        area.setForeground(theme.text);
        area.setBackground(theme.card);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        actions.setOpaque(false);
        AccentButton export = AccentButton.ghost("Export CSV");
        AccentButton reflect = AccentButton.ghost("Daily reflection");
        export.addActionListener(e -> csv(ctx, page));
        reflect.addActionListener(e -> reflection(ctx, page));
        actions.add(export);
        actions.add(reflect);

        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setOpaque(false);
        body.add(Ui.label("This week: " + week + " min  •  today: "
                + ctx.data.minutesStudiedOn(LocalDate.now()) + " min  •  streak: "
                + DashboardScreen.streak(ctx) + " days", theme.bodyFont, theme.muted), BorderLayout.NORTH);
        body.add(chart, BorderLayout.CENTER);
        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.setOpaque(false);
        south.add(Ui.scroll(area), BorderLayout.CENTER);
        south.add(actions, BorderLayout.SOUTH);
        body.add(south, BorderLayout.SOUTH);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private static void csv(AppContext ctx, JPanel page) {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("study-report.csv"));
        if (chooser.showSaveDialog(page) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try (PrintWriter writer = new PrintWriter(chooser.getSelectedFile(), java.nio.charset.StandardCharsets.UTF_8)) {
            writer.println("date,subject,planned_minutes,actual_minutes,complete");
            for (StudySession session : ctx.data.sessions) {
                writer.printf("%s,\"%s\",%d,%d,%s%n",
                        session.date,
                        session.subject.replace("\"", "\"\""),
                        session.plannedMinutes,
                        session.actualMinutes,
                        session.complete);
            }
            JOptionPane.showMessageDialog(page, "CSV exported.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(page, "CSV export failed: " + ex.getMessage());
        }
    }

    private static void reflection(AppContext ctx, JPanel page) {
        String key = LocalDate.now().toString();
        JTextArea area = new JTextArea(ctx.data.reflections.getOrDefault(key, ""), 8, 40);
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.add(new javax.swing.JLabel("What did I learn? What was hard? What is next?"), BorderLayout.NORTH);
        wrap.add(new javax.swing.JScrollPane(area));
        if (JOptionPane.showConfirmDialog(page, wrap, "Daily reflection",
                JOptionPane.OK_CANCEL_OPTION) == 0) {
            ctx.data.reflections.put(key, area.getText());
            ctx.saveOrWarn();
        }
    }

    private static class WeekChart extends JPanel {
        final int[] minutes;
        final String[] labels;

        WeekChart(int[] minutes, String[] labels) {
            this.minutes = minutes;
            this.labels = labels;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Theme theme = Theme.get();
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int max = 1;
            for (int m : minutes) {
                max = Math.max(max, m);
            }
            int w = getWidth();
            int h = getHeight();
            int barW = Math.max(18, (w - 40) / minutes.length - 12);
            for (int i = 0; i < minutes.length; i++) {
                int bh = (int) ((h - 40) * (minutes[i] / (double) max));
                int x = 20 + i * (w - 30) / minutes.length;
                int y = h - 24 - bh;
                g2.setColor(theme.accent);
                g2.fillRoundRect(x, y, barW, Math.max(6, bh), 8, 8);
                g2.setColor(theme.muted);
                g2.setFont(theme.smallFont);
                g2.drawString(labels[i], x, h - 8);
            }
            g2.dispose();
        }
    }
}
