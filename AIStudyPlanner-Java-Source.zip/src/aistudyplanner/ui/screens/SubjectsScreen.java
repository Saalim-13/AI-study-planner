package aistudyplanner.ui.screens;

import aistudyplanner.AppContext;
import aistudyplanner.model.Subject;
import aistudyplanner.model.Topic;
import aistudyplanner.ui.AccentButton;
import aistudyplanner.ui.RoundedPanel;
import aistudyplanner.ui.Theme;
import aistudyplanner.ui.Ui;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.time.LocalDate;

public final class SubjectsScreen {
    private SubjectsScreen() {
    }

    public static JPanel build(AppContext ctx) {
        Theme theme = Theme.get();
        JPanel page = Ui.page("Subjects",
                "Strength 1 is weakest — the planner gives those topics more time.");

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        if (ctx.data.subjects.isEmpty()) {
            list.add(Ui.label("No subjects yet. Add one to unlock the smart plan.", theme.bodyFont, theme.muted));
        }
        for (Subject subject : ctx.data.subjects) {
            list.add(card(ctx, subject));
            list.add(Box.createVerticalStrut(10));
        }

        AccentButton add = AccentButton.primary("Add subject");
        add.addActionListener(e -> edit(ctx, null));

        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setOpaque(false);
        body.add(Ui.scroll(list), BorderLayout.CENTER);
        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        south.add(add, BorderLayout.WEST);
        body.add(south, BorderLayout.SOUTH);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private static JPanel card(AppContext ctx, Subject subject) {
        Theme theme = Theme.get();
        RoundedPanel card = Ui.card();
        String topics = "";
        for (Topic topic : subject.topics) {
            if (!topics.isEmpty()) {
                topics += ", ";
            }
            topics += topic.name + " (s" + topic.strength + ")";
        }
        card.add(Ui.label(subject.name, theme.headingFont, theme.text), BorderLayout.NORTH);
        card.add(Ui.label("<html>Exam " + subject.examDate + "  •  overall strength " + subject.strength + "/5<br>"
                + topics + "</html>", theme.smallFont, theme.muted), BorderLayout.CENTER);
        JPanel actions = new JPanel(new GridLayout(1, 2, 8, 0));
        actions.setOpaque(false);
        AccentButton edit = AccentButton.ghost("Edit");
        AccentButton del = AccentButton.ghost("Remove");
        edit.addActionListener(e -> edit(ctx, subject));
        del.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(card, "Remove " + subject.name + "?", "Confirm",
                    JOptionPane.OK_CANCEL_OPTION) == 0) {
                ctx.data.subjects.remove(subject);
                ctx.saveOrWarn();
                ctx.applet.showScreen("Subjects");
            }
        });
        actions.add(edit);
        actions.add(del);
        card.add(actions, BorderLayout.SOUTH);
        return card;
    }

    private static void edit(AppContext ctx, Subject old) {
        JTextField name = new JTextField(old == null ? "" : old.name);
        JTextField exam = new JTextField(old == null ? LocalDate.now().plusWeeks(4).toString() : old.examDate.toString());
        JSlider strength = new JSlider(1, 5, old == null ? 3 : old.strength);
        strength.setMajorTickSpacing(1);
        strength.setPaintTicks(true);
        strength.setPaintLabels(true);
        JTextField topics = new JTextField();
        if (old != null) {
            StringBuilder sb = new StringBuilder();
            for (Topic topic : old.topics) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(topic.name).append(":").append(topic.strength);
            }
            topics.setText(sb.toString());
        } else {
            topics.setText("Core ideas:3, Practice:3, Exam review:3");
        }
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new javax.swing.JLabel("Name"));
        form.add(name);
        form.add(new javax.swing.JLabel("Exam date YYYY-MM-DD"));
        form.add(exam);
        form.add(new javax.swing.JLabel("Overall strength"));
        form.add(strength);
        form.add(new javax.swing.JLabel("Topics name:strength"));
        form.add(topics);
        if (JOptionPane.showConfirmDialog(null, form, old == null ? "Add subject" : "Edit subject",
                JOptionPane.OK_CANCEL_OPTION) != 0) {
            return;
        }
        try {
            if (name.getText().isBlank()) {
                throw new IllegalArgumentException();
            }
            Subject subject = old == null ? new Subject() : old;
            subject.name = name.getText().trim();
            subject.examDate = LocalDate.parse(exam.getText().trim());
            subject.strength = strength.getValue();
            subject.topics.clear();
            for (String part : topics.getText().split(",")) {
                String bit = part.trim();
                if (bit.isEmpty()) {
                    continue;
                }
                String[] pair = bit.split(":");
                int s = pair.length > 1 ? Integer.parseInt(pair[1].trim()) : 3;
                subject.topics.add(new Topic(pair[0].trim(), s));
            }
            subject.ensureDefaultTopics();
            if (old == null) {
                ctx.data.subjects.add(subject);
            }
            ctx.saveOrWarn();
            ctx.applet.showScreen("Subjects");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Check the name, exam date, and topic list (Algebra:2, Geometry:4).");
        }
    }
}
