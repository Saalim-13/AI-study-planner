package aistudyplanner.ui;

import aistudyplanner.AppContext;
import aistudyplanner.model.StudySession;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/** Persistent white navigation rail inspired by the clean Study-Wise reference. */
public class Sidebar extends JPanel {
    public static final String[] ITEMS = {
            "Dashboard", "Study Planner", "Upload Material", "AI Mentor", "Quiz Center",
            "Progress & Weak Areas", "Revision Notes", "Current Affairs / Daily Practice", "Timer", "Settings",
            "Weekly Insights", "Goals & Readiness", "Subjects"
    };
    private static final IconPainter.Kind[] ICONS = {
            IconPainter.Kind.DASHBOARD, IconPainter.Kind.PLANNER, IconPainter.Kind.SUBJECTS,
            IconPainter.Kind.MENTOR, IconPainter.Kind.QUIZ, IconPainter.Kind.PROGRESS,
            IconPainter.Kind.INSIGHTS, IconPainter.Kind.QUIZ, IconPainter.Kind.GOAL, IconPainter.Kind.SETTINGS,
            IconPainter.Kind.INSIGHTS, IconPainter.Kind.GOAL, IconPainter.Kind.SUBJECTS
    };
    private final Map<String, NavBtn> buttons = new LinkedHashMap<>();
    private final ThemeToggle toggle;
    private final JLabel brandName = new JLabel("Study-Wise");
    private final RoundedPanel streakPanel = new RoundedPanel(new BorderLayout(0, 5));
    private final JLabel streakTitle = new JLabel("Study streak");
    private final JLabel streakCount = new JLabel();
    private final JLabel streakNote = new JLabel("A little each day adds up.");
    private String active = "Dashboard";

    public Sidebar(AppContext context, Consumer<String> onNavigate, Runnable onThemeToggle) {
        super(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(20, 16, 16, 16));
        setPreferredSize(new Dimension(258, 100));

        JPanel brand = new JPanel(new BorderLayout(11, 0));
        brand.setOpaque(false);
        BrandMark mark = new BrandMark();
        brand.add(mark, BorderLayout.WEST);
        brandName.setFont(Theme.get().headingFont.deriveFont(17f));
        brandName.setForeground(Theme.get().text);
        brand.add(brandName, BorderLayout.CENTER);
        brand.setBorder(BorderFactory.createEmptyBorder(3, 5, 24, 4));
        add(brand, BorderLayout.NORTH);

        JPanel nav = new JPanel();
        nav.setOpaque(false);
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS));
        for (int i = 0; i < ITEMS.length; i++) {
            String key = ITEMS[i];
            NavBtn button = new NavBtn(key, displayName(key), ICONS[i]);
            button.addActionListener(e -> onNavigate.accept(key));
            button.setAlignmentX(LEFT_ALIGNMENT);
            buttons.put(key, button);
            nav.add(button);
            nav.add(Box.createVerticalStrut(5));
        }
        JScrollPane navScroll = new JScrollPane(nav);
        navScroll.setBorder(BorderFactory.createEmptyBorder());
        navScroll.setOpaque(false);
        navScroll.getViewport().setOpaque(false);
        navScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        navScroll.getVerticalScrollBar().setUnitIncrement(18);
        navScroll.getVerticalScrollBar().setPreferredSize(new Dimension(0, 0));
        add(navScroll, BorderLayout.CENTER);

        JPanel footer = new JPanel();
        footer.setOpaque(false);
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        footer.add(streakCard(context));
        footer.add(Box.createVerticalStrut(10));
        toggle = new ThemeToggle(onThemeToggle);
        toggle.setAlignmentX(LEFT_ALIGNMENT);
        footer.add(toggle);
        add(footer, BorderLayout.SOUTH);
        refreshTheme();
    }

    private static String displayName(String key) { return key; }

    private JPanel streakCard(AppContext context) {
        Theme theme = Theme.get();
        int streak = currentStreak(context);
        streakPanel.setFillColor(theme.cardAlt);
        streakPanel.setBorder(BorderFactory.createEmptyBorder(13, 14, 13, 10));
        streakPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));
        streakTitle.setFont(theme.bodyFont.deriveFont(java.awt.Font.BOLD));
        streakCount.setText(streak + (streak == 1 ? " day in a row" : " days in a row"));
        streakCount.setFont(theme.bodyFont.deriveFont(java.awt.Font.BOLD));
        streakNote.setFont(theme.smallFont);
        streakPanel.add(streakTitle, BorderLayout.NORTH);
        streakPanel.add(streakCount, BorderLayout.CENTER);
        streakPanel.add(streakNote, BorderLayout.SOUTH);
        return streakPanel;
    }

    private static int currentStreak(AppContext context) {
        java.util.Set<LocalDate> days = new java.util.HashSet<>();
        for (StudySession session : context.data.sessions) {
            for (int offset = 0; offset <= 1; offset++) {
                LocalDate day = session.date.plusDays(offset);
                if (session.minutesOn(day) > 0) days.add(day);
            }
        }
        LocalDate day = days.contains(LocalDate.now()) ? LocalDate.now() : LocalDate.now().minusDays(1);
        int count = 0;
        while (days.contains(day)) { count++; day = day.minusDays(1); }
        return count;
    }

    public void setActive(String name) {
        active = name;
        if ("Daily Quiz".equals(name)) active = "Current Affairs / Daily Practice";
        if ("Planner".equals(name)) active = "Study Planner";
        if ("Quiz".equals(name)) active = "Quiz Center";
        if ("Progress".equals(name)) active = "Progress & Weak Areas";
        if ("Pomodoro".equals(name)) active = "Timer";
        if ("Mentor".equals(name)) active = "AI Mentor";
        for (Map.Entry<String, NavBtn> item : buttons.entrySet()) {
            item.getValue().selected = item.getKey().equals(active);
            item.getValue().repaint();
        }
    }

    public void refreshTheme() {
        Theme theme = Theme.get();
        brandName.setForeground(theme.text);
        brandName.setFont(theme.headingFont.deriveFont(17f));
        streakPanel.setFillColor(theme.cardAlt);
        streakTitle.setForeground(theme.accent);
        streakTitle.setFont(theme.bodyFont.deriveFont(java.awt.Font.BOLD));
        streakCount.setForeground(theme.text);
        streakCount.setFont(theme.bodyFont.deriveFont(java.awt.Font.BOLD));
        streakNote.setForeground(theme.muted);
        streakNote.setFont(theme.smallFont);
        for (NavBtn button : buttons.values()) button.setFont(theme.bodyFont);
        toggle.refresh();
        setActive(active);
        repaint();
    }

    @Override protected void paintComponent(Graphics graphics) {
        Graphics2D g = (Graphics2D) graphics.create();
        g.setColor(Theme.get().sidebar);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(new Color(222, 228, 233));
        g.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
        g.dispose();
        super.paintComponent(graphics);
    }

    private static final class BrandMark extends JPanel {
        BrandMark() { setOpaque(false); setPreferredSize(new Dimension(38, 38)); }
        @Override protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(Theme.get().accent);
            g.fillOval(1, 1, 36, 36);
            g.setColor(Color.WHITE);
            g.setStroke(new java.awt.BasicStroke(2f, java.awt.BasicStroke.CAP_ROUND, java.awt.BasicStroke.JOIN_ROUND));
            g.drawRoundRect(10, 10, 18, 17, 3, 3);
            g.drawLine(19, 11, 19, 26);
            g.drawLine(12, 14, 16, 14);
            g.drawLine(22, 14, 26, 14);
            g.drawLine(12, 18, 16, 18);
            g.drawLine(22, 18, 26, 18);
            g.dispose();
        }
    }

    private static final class NavBtn extends JButton {
        final IconPainter.Kind icon;
        boolean selected;
        boolean hover;
        NavBtn(String key, String label, IconPainter.Kind icon) {
            super(label);
            this.icon = icon;
            setName(key);
            setToolTipText("Open the " + label + " screen");
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setHorizontalAlignment(LEFT);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            setPreferredSize(new Dimension(224, 38));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }
        @Override protected void paintComponent(Graphics graphics) {
            Theme theme = Theme.get();
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (selected || hover) {
                g.setColor(selected ? theme.accentSoft : theme.cardAlt);
                g.fillRoundRect(0, 0, getWidth() - 2, getHeight(), 12, 12);
            }
            Color ink = selected ? theme.accent : theme.text;
            IconPainter.paint(g, icon, 12, 11, 17, selected ? theme.accent : theme.muted);
            g.setFont(selected ? theme.bodyFont.deriveFont(java.awt.Font.BOLD) : theme.bodyFont);
            g.setColor(ink);
            g.drawString(getText(), 40, 25);
            g.dispose();
        }
    }

    private static final class ThemeToggle extends JButton {
        ThemeToggle(Runnable action) {
            setFocusPainted(false); setBorderPainted(false); setContentAreaFilled(false); setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText("Switch between the light and dark themes");
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            addActionListener(e -> action.run());
            refresh();
        }
        void refresh() { setText(Theme.get().dark ? "  Light appearance" : "  Dark appearance"); repaint(); }
        @Override protected void paintComponent(Graphics graphics) {
            Theme theme = Theme.get();
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(theme.card);
            g.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 1, 12, 12);
            IconPainter.paint(g, theme.dark ? IconPainter.Kind.SUN : IconPainter.Kind.MOON, 12, 10, 17, theme.accent);
            g.setFont(theme.smallFont);
            g.setColor(theme.text);
            g.drawString(getText().trim(), 40, 24);
            g.dispose();
        }
    }
}
