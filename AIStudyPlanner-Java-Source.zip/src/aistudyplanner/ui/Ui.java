package aistudyplanner.ui;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

/** Tiny factory methods so screens stay short. */
public final class Ui {
    private Ui() {
    }

    public static JLabel label(String text, Font font, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        return label;
    }

    public static JPanel page(String title, String subtitle) {
        Theme theme = Theme.get();
        JPanel page = new JPanel(new BorderLayout(0, 16));
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(20, 26, 22, 26));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(label(title, theme.titleFont, theme.text), BorderLayout.NORTH);
        header.add(label(subtitle, theme.smallFont, theme.muted), BorderLayout.SOUTH);
        page.add(header, BorderLayout.NORTH);
        return page;
    }

    public static RoundedPanel card() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(8, 8));
        card.setBorder(BorderFactory.createEmptyBorder(20, 22, 22, 22));
        return card;
    }

    public static JScrollPane scroll(JComponent inner) {
        JScrollPane scroll = new JScrollPane(inner);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        scroll.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        return scroll;
    }

    public static void styleField(JComponent field) {
        Theme theme = Theme.get();
        field.setFont(theme.bodyFont);
        field.setForeground(theme.text);
        field.setBackground(theme.card);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 229, 234), 1, true),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
    }

    /** Applies the shared rounded style to standard Swing buttons in modal dialogs. */
    public static void retroButton(JButton button) {
        Theme theme = Theme.get();
        button.setFont(theme.bodyFont.deriveFont(Font.BOLD, 13f));
        button.setForeground(theme.text);
        button.setBackground(theme.card);
        button.setOpaque(true);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(theme.accentSoft, 1, true),
                BorderFactory.createEmptyBorder(6, 11, 6, 11)));
    }
}
