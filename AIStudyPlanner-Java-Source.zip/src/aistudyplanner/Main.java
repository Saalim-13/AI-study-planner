package aistudyplanner;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import aistudyplanner.ui.SplashScreen;
import aistudyplanner.AppContext;
import java.awt.Dimension;
import java.nio.file.Path;

/**
 * Desktop host for {@link StudyApplet}.
 * Modern JDKs cannot run applets in a browser, so this main() method
 * places the applet panel in a normal window.
 */
public final class Main {
    private Main() {
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SplashScreen.SplashHandle splash=SplashScreen.open();
            Path root=Path.of("").toAbsolutePath();
            javax.swing.SwingWorker<AppContext,Void> loader=new javax.swing.SwingWorker<>() {
                protected AppContext doInBackground() {
                    return new AppContext(root.resolve("data").resolve("planner.dat"),root.resolve("data").resolve("questions.csv"));
                }
                protected void done() {
                    splash.close();
                    try { launch(get()); }
                    catch(Exception ex){javax.swing.JOptionPane.showMessageDialog(null,"Could not load the planner data: "+ex.getMessage(),"Startup error",javax.swing.JOptionPane.ERROR_MESSAGE);}
                }
            };
            loader.execute();
        });
    }

    private static void launch(AppContext context) {
            StudyApplet applet = new StudyApplet();
            applet.init(context);
            if (!applet.ready) {
                return;
            }
            JFrame frame = new JFrame("Study-Wise • AI Study Planner");
            frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            frame.setContentPane(applet);
            frame.setMinimumSize(new Dimension(1050, 690));
            frame.setSize(1200, 790);
            frame.setLocationRelativeTo(null);
            applet.attachClosing(frame);
            frame.setVisible(true);
            applet.start();
    }
}
