package aistudyplanner.storage;

import aistudyplanner.model.AppData;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Saves the whole AppData object next to a .bak copy from the previous save. */
public class DataStore {
    private final Path file;

    public DataStore(Path file) {
        this.file = file;
    }

    public AppData load() {
        if (!Files.exists(file)) {
            return new AppData();
        }
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(file))) {
            Object raw = in.readObject();
            if (raw instanceof AppData) {
                AppData data = (AppData) raw;
                data.ensureCollections();
                return data;
            }
        } catch (Exception ignored) {
            // Caller shows a friendly message; we fall back to a blank profile.
        }
        return new AppData();
    }

    public void save(AppData data) throws Exception {
        Files.createDirectories(file.getParent());
        Path tmp = Path.of(file.toString() + ".tmp");
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(tmp))) {
            out.writeObject(data);
        }
        Path backup = Path.of(file.toString() + ".bak");
        if (Files.exists(file)) {
            Files.copy(file, backup, StandardCopyOption.REPLACE_EXISTING);
        }
        Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
    }

    public Path backupPath() {
        return Path.of(file.toString() + ".bak");
    }

    public void restoreBackup() throws Exception {
        Path backup = backupPath();
        if (!Files.exists(backup)) {
            throw new IllegalStateException("No backup exists yet.");
        }
        Files.copy(backup, file, StandardCopyOption.REPLACE_EXISTING);
    }

    public Path file() {
        return file;
    }
}
