package aistudyplanner.storage;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.parser.ParserDelegator;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.InflaterInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** JDK-only readers for common study formats, plus optional local Tesseract OCR. */
public final class MaterialExtractor {
    private static final long MAX_BYTES = 8L * 1024 * 1024;
    private static final int MAX_CHARS = 500_000;

    public String read(Path path) throws Exception {
        if (path == null || !Files.isRegularFile(path)) throw new IllegalArgumentException("Choose an existing file.");
        if (Files.size(path) > MAX_BYTES) throw new IllegalArgumentException("This file is larger than 8 MB. Choose a smaller file.");
        String name = path.getFileName().toString();
        String ext = extension(name);
        String result;
        switch (ext) {
            case "txt": case "md": case "markdown": case "csv":
                result = Files.readString(path, StandardCharsets.UTF_8); break;
            case "html": case "htm":
                result = htmlToText(Files.readString(path, StandardCharsets.UTF_8)); break;
            case "docx": result = officeXml(path, "word/document.xml", "word/", "w:t"); break;
            case "pptx": result = officeXml(path, null, "ppt/slides/slide", "a:t"); break;
            case "pdf": result = pdfText(Files.readAllBytes(path)); break;
            case "png": case "jpg": case "jpeg": case "bmp": case "tif": case "tiff":
                result = runOcr(path); break;
            default: throw new IllegalArgumentException("Unsupported file type: ." + ext
                    + ". Supported formats: PDF, DOCX, PPTX, TXT, Markdown, HTML, and common images.");
        }
        result = result == null ? "" : result.replace('\u0000', ' ').trim();
        if (result.length() > MAX_CHARS) result = result.substring(0, MAX_CHARS);
        if (result.isBlank()) {
            if ("pdf".equals(ext)) throw new IllegalArgumentException("No selectable PDF text was found. This may be a scanned PDF; install Tesseract OCR and upload page images, or paste readable text.");
            throw new IllegalArgumentException("No readable text was found in this file.");
        }
        return result;
    }

    public String readWebLink(String rawUrl) throws Exception {
        URI uri = URI.create(rawUrl == null ? "" : rawUrl.trim());
        String scheme = uri.getScheme();
        if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) {
            throw new IllegalArgumentException("Enter a complete http:// or https:// web address.");
        }
        HttpURLConnection connection = (HttpURLConnection) uri.toURL().openConnection();
        connection.setConnectTimeout(8000);
        connection.setReadTimeout(12000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "StudyWise/1.0 (material text reader)");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IllegalArgumentException("The page returned HTTP " + status + ".");
            String contentType = connection.getContentType();
            if (contentType != null && !(contentType.toLowerCase(Locale.ROOT).contains("text/html")
                    || contentType.toLowerCase(Locale.ROOT).contains("text/plain"))) {
                throw new IllegalArgumentException("This web link is not an HTML/text page (" + contentType + "). Download the file and upload it instead.");
            }
            try (InputStream in = connection.getInputStream()) {
                byte[] bytes = readLimited(in, MAX_BYTES);
                String document = new String(bytes, StandardCharsets.UTF_8);
                return contentType != null && contentType.toLowerCase(Locale.ROOT).contains("text/plain")
                        ? document : htmlToText(document);
            }
        } finally { connection.disconnect(); }
    }

    private static String extension(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private static byte[] readLimited(InputStream in, long limit) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        long total = 0;
        while ((read = in.read(buffer)) >= 0) {
            total += read;
            if (total > limit) throw new IllegalArgumentException("The content is larger than 8 MB.");
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }

    private static String htmlToText(String html) throws Exception {
        StringBuilder text = new StringBuilder();
        HTMLEditorKit.ParserCallback callback = new HTMLEditorKit.ParserCallback() {
            @Override public void handleText(char[] data, int pos) { text.append(data).append(' '); }
            @Override public void handleStartTag(HTML.Tag tag, MutableAttributeSet attrs, int pos) {
                if (tag == HTML.Tag.P || tag == HTML.Tag.DIV || tag == HTML.Tag.BR || tag == HTML.Tag.LI
                        || tag == HTML.Tag.H1 || tag == HTML.Tag.H2 || tag == HTML.Tag.H3) text.append('\n');
            }
        };
        new ParserDelegator().parse(new StringReader(html), callback, true);
        return text.toString();
    }

    private static String officeXml(Path path, String exact, String prefix, String tag) throws Exception {
        StringBuilder out = new StringBuilder();
        try (ZipFile zip = new ZipFile(path.toFile())) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = entry.getName();
                boolean wanted = exact != null ? exact.equals(name)
                        : name.startsWith(prefix) && name.endsWith(".xml");
                if (!wanted || entry.isDirectory()) continue;
                if (entry.getSize() > MAX_BYTES) throw new IllegalArgumentException("An embedded document part is too large.");
                try (InputStream in = zip.getInputStream(entry)) {
                    byte[] data = readLimited(in, MAX_BYTES);
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                    factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
                    factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
                    factory.setXIncludeAware(false);
                    factory.setExpandEntityReferences(false);
                    Document doc = factory.newDocumentBuilder().parse(new InputSource(new ByteArrayInputStream(data)));
                    NodeList nodes = doc.getElementsByTagName(tag);
                    for (int i = 0; i < nodes.getLength(); i++) out.append(nodes.item(i).getTextContent()).append(' ');
                    out.append('\n');
                }
            }
        }
        return out.toString();
    }

    /** Best-effort extraction of plain PDF text streams, including standard Flate streams. */
    private static String pdfText(byte[] bytes) throws Exception {
        String raw = new String(bytes, StandardCharsets.ISO_8859_1);
        if (!raw.startsWith("%PDF-")) throw new IllegalArgumentException("This file does not appear to be a valid PDF.");
        StringBuilder all = new StringBuilder();
        int cursor = 0;
        while ((cursor = raw.indexOf("stream", cursor)) >= 0) {
            int dataStart = cursor + 6;
            if (dataStart < raw.length() && raw.charAt(dataStart) == '\r') dataStart++;
            if (dataStart < raw.length() && raw.charAt(dataStart) == '\n') dataStart++;
            int end = raw.indexOf("endstream", dataStart);
            if (end < 0) break;
            int dictStart = raw.lastIndexOf("<<", cursor);
            String dictionary = dictStart >= 0 ? raw.substring(dictStart, cursor) : "";
            byte[] chunk = raw.substring(dataStart, end).getBytes(StandardCharsets.ISO_8859_1);
            if (dictionary.contains("/FlateDecode")) {
                try (InputStream inflate = new InflaterInputStream(new ByteArrayInputStream(chunk))) {
                    chunk = readLimited(inflate, MAX_BYTES);
                } catch (Exception ignored) { cursor = end + 9; continue; }
            }
            extractPdfOperators(new String(chunk, StandardCharsets.ISO_8859_1), all);
            cursor = end + 9;
        }
        return all.toString();
    }

    private static void extractPdfOperators(String stream, StringBuilder out) {
        java.util.regex.Matcher literal = java.util.regex.Pattern.compile("\\((?:\\\\.|[^\\\\)])*\\)\\s*(?:Tj|'|\")").matcher(stream);
        while (literal.find()) {
            String raw = literal.group().replaceFirst("\\s*(?:Tj|'|\")$", "");
            out.append(unescapePdf(raw.substring(1, raw.length() - 1))).append(' ');
        }
        java.util.regex.Matcher array = java.util.regex.Pattern.compile("\\[(.*?)]\\s*TJ", java.util.regex.Pattern.DOTALL).matcher(stream);
        while (array.find()) {
            java.util.regex.Matcher parts = java.util.regex.Pattern.compile("\\(((?:\\\\.|[^\\\\)])*)\\)").matcher(array.group(1));
            while (parts.find()) out.append(unescapePdf(parts.group(1))).append(' ');
        }
    }

    private static String unescapePdf(String input) {
        return input.replace("\\n", "\n").replace("\\r", "\n").replace("\\t", " ")
                .replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\");
    }

    private static String runOcr(Path image) throws Exception {
        try {
            Process process = new ProcessBuilder("tesseract", image.toAbsolutePath().toString(), "stdout")
                    .redirectErrorStream(true).start();
            byte[] result;
            try (InputStream in = process.getInputStream()) { result = readLimited(in, MAX_BYTES); }
            if (!process.waitFor(45, java.util.concurrent.TimeUnit.SECONDS)) {
                process.destroyForcibly();
                throw new IllegalArgumentException("OCR took too long. Try a smaller or clearer image.");
            }
            if (process.exitValue() != 0) throw new IllegalArgumentException("OCR could not read this image. Check that Tesseract is installed and that the image is clear.");
            return new String(result, StandardCharsets.UTF_8);
        } catch (java.io.IOException ex) {
            throw new IllegalArgumentException("Image OCR requires Tesseract OCR on PATH. Install Tesseract, then restart Study-Wise. The image has not been uploaded.");
        }
    }
}
