package aistudyplanner.storage;

import aistudyplanner.model.QuizQuestion;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * CSV columns: id,subject,topic,question,A,B,C,D,correct,explanation
 * correct is A/B/C/D. Commas inside quotes are supported.
 */
public class QuizBankLoader {
    private final Path file;

    public QuizBankLoader(Path file) {
        this.file = file;
    }

    public List<QuizQuestion> load() {
        List<QuizQuestion> questions = new ArrayList<>();
        if (!Files.exists(file)) {
            return questions;
        }
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            boolean header = true;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank() || line.startsWith("#")) {
                    continue;
                }
                List<String> cells = splitCsv(line);
                if (header && cells.get(0).equalsIgnoreCase("id")) {
                    header = false;
                    continue;
                }
                header = false;
                if (cells.size() < 10) {
                    continue;
                }
                int correct = "ABCD".indexOf(cells.get(8).trim().toUpperCase());
                if (correct < 0) {
                    continue;
                }
                questions.add(new QuizQuestion(
                        cells.get(0).trim(),
                        cells.get(1).trim(),
                        cells.get(2).trim(),
                        cells.get(3).trim(),
                        new String[]{cells.get(4).trim(), cells.get(5).trim(), cells.get(6).trim(), cells.get(7).trim()},
                        correct,
                        cells.get(9).trim()
                ));
            }
        } catch (IOException ignored) {
            // Empty bank is safer than crashing the app on a bad file.
        }
        return questions;
    }

    private List<String> splitCsv(String line) {
        List<String> cells = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                quoted = !quoted;
            } else if (ch == ',' && !quoted) {
                cells.add(current.toString());
                current.setLength(0);
            } else {
                current.append(ch);
            }
        }
        cells.add(current.toString());
        return cells;
    }
}
