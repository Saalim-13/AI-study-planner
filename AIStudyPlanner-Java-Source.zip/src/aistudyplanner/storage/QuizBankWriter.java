package aistudyplanner.storage;

import aistudyplanner.model.QuizQuestion;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

/** CSV writer shared by imported-material and generated-quiz workflows. */
public final class QuizBankWriter {
    private static final String HEADER = "id,subject,topic,question,A,B,C,D,correct,explanation\n";

    public void append(Path path, List<QuizQuestion> questions) throws Exception {
        if (questions == null || questions.isEmpty()) throw new IllegalArgumentException("There are no questions to save.");
        Files.createDirectories(path.getParent());
        boolean hasContent = Files.exists(path) && Files.size(path) > 0;
        StringBuilder csv = new StringBuilder();
        if (!hasContent) csv.append(HEADER);
        else csv.append('\n');
        for (QuizQuestion q : questions) {
            if (q.choices == null || q.choices.length != 4 || q.correctIndex < 0 || q.correctIndex > 3)
                throw new IllegalArgumentException("Every quiz question must have four options and one correct answer.");
            csv.append(cell(q.id)).append(',').append(cell(q.subject)).append(',').append(cell(q.topic)).append(',')
                    .append(cell(q.prompt));
            for (String choice : q.choices) csv.append(',').append(cell(choice));
            csv.append(',').append((char) ('A' + q.correctIndex)).append(',').append(cell(q.explanation)).append('\n');
        }
        Files.writeString(path, csv, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    private static String cell(String value) {
        return "\"" + (value == null ? "" : value.replace("\"", "\"\"")) + "\"";
    }
}
