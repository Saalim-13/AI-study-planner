package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDate;

/** Saved user preferences. Minutes are used internally so timers stay integer-safe. */
public class Profile implements Serializable {
    private static final long serialVersionUID = 1L;

    public String name = "";
    public String course = "";
    public int availableMinutes = 180;
    public int dailyGoalMinutes = 90;
    public int focusMinutes = 25;
    public int breakMinutes = 5;
    public int longBreakMinutes = 15;
    public int quizSeconds = 30;
    /** Energy 1–5 tweaks pomodoro suggestions (low = shorter review blocks). */
    public int energy = 3;
    public String mood = "Okay";
    public LocalDate checkInDate;
    public int todayAvailableMinutes = 180;
    public java.time.LocalDate dailyChallengeDate;
    public java.time.LocalDate dailyPracticeDate;
    public java.time.LocalDate targetExamDate;
    public int targetScore = 80;
    public boolean soundEnabled = false;
    public String reminderTime = "19:00";
    public String accentHex = "#117764";
    public int fontSizePercent = 100;
    public String examType = "UPSC";
    /** Explicit opt-in: document text may be sent to OpenAI when an API key is configured. */
    public boolean onlineAiEnabled = false;
    public boolean autoBreak = true;
    public boolean darkTheme = false;
    /** Quiz average below this percent is treated as a weak topic. */
    public int weakThreshold = 60;
}
