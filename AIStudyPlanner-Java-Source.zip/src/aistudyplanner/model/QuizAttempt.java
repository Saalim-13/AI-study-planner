package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDateTime;

/** One answered question, used later to find weak topics. */
public class QuizAttempt implements Serializable {
    private static final long serialVersionUID = 1L;

    public String questionId = "";
    public String subject = "";
    public String topic = "";
    public boolean correct;
    /** True when the countdown ended and the selected answer was auto-saved. */
    public boolean timedOut;
    public int secondsUsed;
    public String prompt = "";
    public String explanation = "";
    public String correctAnswer = "";
    public String learnerAnswer = "";
    public LocalDateTime when = LocalDateTime.now();
    public String quizSessionId = "";
    public int quizSessionSize;
    public int quizSessionScore;
    public int quizSessionSeconds;
}
