package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDateTime;

/** One locally saved message in the floating mentor conversation. */
public class ChatMessage implements Serializable {
    private static final long serialVersionUID = 1L;
    public String role = "assistant";
    public String text = "";
    public LocalDateTime sentAt = LocalDateTime.now();

    public ChatMessage() { }

    public ChatMessage(String role, String text) {
        this.role = role;
        this.text = text;
        this.sentAt = LocalDateTime.now();
    }
}
