package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDate;

/** One planned block: either a generated slot or a task the student added. */
public class StudyTask implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String LEARN = "LEARN";
    public static final String REVISE = "REVISE";
    public static final String QUIZ = "QUIZ";
    public static final String MANUAL = "MANUAL";

    public String subject = "";
    public String topic = "";
    public int minutes = 30;
    public int priority = 3;
    public LocalDate day = LocalDate.now();
    public LocalDate due = LocalDate.now().plusDays(1);
    public boolean done = false;
    public String kind = MANUAL;

    public StudyTask() {
    }

    public StudyTask(String subject, String topic, int minutes, int priority,
                     LocalDate day, LocalDate due, String kind) {
        this.subject = subject;
        this.topic = topic;
        this.minutes = minutes;
        this.priority = priority;
        this.day = day;
        this.due = due;
        this.kind = kind;
    }

    public String label() {
        return subject + " — " + topic;
    }
}
