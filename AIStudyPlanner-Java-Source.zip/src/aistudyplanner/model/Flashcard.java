package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDate;

/** Local retrieval-practice card created from a missed quiz question or imported notes. */
public class Flashcard implements Serializable {
    private static final long serialVersionUID = 1L;
    public String id="";
    public String subject="";
    public String topic="";
    public String front="";
    public String back="";
    public String explanation="";
    public LocalDate nextReview=LocalDate.now();
    public int intervalDays;
    public int repetitions;
    public Flashcard() { }
    public Flashcard(String id,String subject,String topic,String front,String back,String explanation){
        this.id=id;this.subject=subject;this.topic=topic;this.front=front;this.back=back;this.explanation=explanation;
    }
    public void review(boolean recalled){
        if(recalled){repetitions++;intervalDays=repetitions==1?1:repetitions==2?6:Math.max(1,intervalDays*2);}
        else{repetitions=0;intervalDays=1;}
        nextReview=LocalDate.now().plusDays(intervalDays);
    }
}
