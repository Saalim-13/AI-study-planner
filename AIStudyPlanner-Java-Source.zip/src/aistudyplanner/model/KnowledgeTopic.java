package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDate;

/** A topic's retained knowledge and SM-2 review state. */
public class KnowledgeTopic implements Serializable {
    private static final long serialVersionUID = 1L;
    public String subject = "";
    public String topic = "";
    public int mastery = 50;
    public double confidence = 0.5;
    public LocalDate lastStudied;
    public LocalDate nextReview = LocalDate.now();
    public int intervalDays;
    public double easeFactor = 2.5;
    public int repetitions;
    public int attempts;
    public int correct;

    public double estimatedRetention(LocalDate today) {
        if (lastStudied == null) return mastery / 100.0;
        long elapsed = Math.max(0, java.time.temporal.ChronoUnit.DAYS.between(lastStudied, today));
        double halfLife = Math.max(1.0, intervalDays * Math.max(0.5, easeFactor / 2.5));
        return Math.max(0.0, Math.min(1.0, mastery / 100.0 * Math.pow(0.5, elapsed / halfLife)));
    }
}
