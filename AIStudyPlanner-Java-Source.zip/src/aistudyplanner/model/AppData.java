package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

/** Everything that is saved to disk. Keep this as one object so save/load stays simple. */
public class AppData implements Serializable {
    private static final long serialVersionUID = 2L;

    public Profile profile = new Profile();
    public ArrayList<Subject> subjects = new ArrayList<>();
    public ArrayList<StudyTask> tasks = new ArrayList<>();
    public ArrayList<StudySession> sessions = new ArrayList<>();
    public ArrayList<QuizAttempt> quizAttempts = new ArrayList<>();
    public ArrayList<String> favorites = new ArrayList<>();
    public ArrayList<String> distractions = new ArrayList<>();
    public HashMap<String, String> reflections = new HashMap<>();
    /** Per-topic adaptive learning state; lazily initialized for older saved profiles. */
    public HashMap<String, KnowledgeTopic> knowledge = new HashMap<>();
    public int xp;
    public ArrayList<String> badges = new ArrayList<>();
    public ArrayList<Flashcard> flashcards = new ArrayList<>();
    public ArrayList<ChatMessage> mentorChat = new ArrayList<>();
    public String activeMaterialName = "";
    public String activeMaterialText = "";
    public String activeMaterialAnalysis = "";

    public void ensureCollections() {
        if (profile == null) profile = new Profile();
        if (profile.targetScore <= 0) profile.targetScore = 80;
        if (profile.fontSizePercent < 85 || profile.fontSizePercent > 130) profile.fontSizePercent = 100;
        if (profile.examType == null || profile.examType.isBlank()) profile.examType = "UPSC";
        if (profile.todayAvailableMinutes <= 0) profile.todayAvailableMinutes = profile.availableMinutes;
        if (profile.reminderTime == null) profile.reminderTime = "19:00";
        if (profile.mood == null) profile.mood = "Okay";
        if (profile.accentHex == null) profile.accentHex = "#BA84FF";
        if (subjects == null) subjects = new ArrayList<>();
        if (tasks == null) tasks = new ArrayList<>();
        if (sessions == null) sessions = new ArrayList<>();
        if (quizAttempts == null) quizAttempts = new ArrayList<>();
        if (favorites == null) favorites = new ArrayList<>();
        if (distractions == null) distractions = new ArrayList<>();
        if (reflections == null) reflections = new HashMap<>();
        if (knowledge == null) knowledge = new HashMap<>();
        if (badges == null) badges = new ArrayList<>();
        if (flashcards == null) flashcards = new ArrayList<>();
        if (mentorChat == null) mentorChat = new ArrayList<>();
        if (activeMaterialName == null) activeMaterialName = "";
        if (activeMaterialText == null) activeMaterialText = "";
        if (activeMaterialAnalysis == null) activeMaterialAnalysis = "";
    }

    /** Used after restoring a backup so we keep the same AppData instance. */
    public void replaceWith(AppData other) {
        profile = other.profile;
        subjects = other.subjects;
        tasks = other.tasks;
        sessions = other.sessions;
        quizAttempts = other.quizAttempts;
        favorites = other.favorites;
        distractions = other.distractions;
        reflections = other.reflections;
        knowledge = other.knowledge;
        xp = other.xp;
        badges = other.badges;
        flashcards = other.flashcards;
    }

    public Subject findSubject(String name) {
        for (Subject subject : subjects) {
            if (subject.name.equalsIgnoreCase(name)) {
                return subject;
            }
        }
        return null;
    }

    public int minutesStudiedOn(LocalDate day) {
        int total = 0;
        for (StudySession session : sessions) {
            total += session.minutesOn(day);
        }
        return total;
    }
}
