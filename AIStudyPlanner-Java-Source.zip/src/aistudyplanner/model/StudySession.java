package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** One finished (or skipped) pomodoro / focus block. */
public class StudySession implements Serializable {
    private static final long serialVersionUID = 1L;

    public LocalDate date = LocalDate.now();
    public String subject = "General";
    public String topic = "";
    public int plannedMinutes;
    public int actualMinutes;
    public boolean complete;
    /** Real start time used for time-of-day insights; null for older saved sessions. */
    public LocalDateTime startedAt;

    public StudySession() {
    }

    public StudySession(String subject, int plannedMinutes, int actualMinutes, boolean complete) {
        this(subject, plannedMinutes, actualMinutes, complete, LocalDateTime.now());
    }

    public StudySession(String subject, int plannedMinutes, int actualMinutes, boolean complete, LocalDateTime startedAt) {
        this(subject,"",plannedMinutes,actualMinutes,complete,startedAt);
    }

    public StudySession(String subject, String topic, int plannedMinutes, int actualMinutes, boolean complete, LocalDateTime startedAt) {
        this.subject = subject;
        this.topic = topic;
        this.plannedMinutes = plannedMinutes;
        this.actualMinutes = actualMinutes;
        this.complete = complete;
        this.startedAt = startedAt;
        if (startedAt != null) this.date = startedAt.toLocalDate();
    }

    /** Counts the real focus minutes overlapping a calendar day, including midnight crossings. */
    public int minutesOn(LocalDate day) {
        if (startedAt == null) return date.equals(day) ? actualMinutes : 0;
        LocalDateTime from=startedAt;
        LocalDateTime to=startedAt.plusMinutes(Math.max(0,actualMinutes));
        LocalDateTime dayStart=day.atStartOfDay(),dayEnd=day.plusDays(1).atStartOfDay();
        long seconds=Math.max(0,java.time.Duration.between(from.isAfter(dayStart)?from:dayStart,
                to.isBefore(dayEnd)?to:dayEnd).getSeconds());
        return (int)Math.round(seconds/60.0);
    }
}
