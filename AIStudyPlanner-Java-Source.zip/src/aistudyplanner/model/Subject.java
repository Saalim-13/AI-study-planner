package aistudyplanner.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

/** A course the student is preparing for, with an exam date and topics. */
public class Subject implements Serializable {
    private static final long serialVersionUID = 1L;

    public String name = "";
    public LocalDate examDate = LocalDate.now().plusWeeks(4);
    /** Overall comfort with the subject, 1 = weakest. */
    public int strength = 3;
    public ArrayList<Topic> topics = new ArrayList<>();

    public Subject() {
    }

    public Subject(String name, LocalDate examDate, int strength) {
        this.name = name;
        this.examDate = examDate;
        this.strength = Topic.clampStrength(strength);
    }

    public void ensureDefaultTopics() {
        if (!topics.isEmpty()) {
            return;
        }
        topics.add(new Topic("Core ideas", strength));
        topics.add(new Topic("Practice", strength));
        topics.add(new Topic("Exam review", strength));
    }
}
