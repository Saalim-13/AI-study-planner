package aistudyplanner.model;

import java.io.Serializable;

/** One unit of study inside a subject. Strength is 1 (weak) to 5 (strong). */
public class Topic implements Serializable {
    private static final long serialVersionUID = 1L;

    public String name = "";
    public int strength = 3;

    public Topic() {
    }

    public Topic(String name, int strength) {
        this.name = name;
        this.strength = clampStrength(strength);
    }

    public static int clampStrength(int value) {
        return Math.max(1, Math.min(5, value));
    }
}
