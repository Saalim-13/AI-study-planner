package aistudyplanner.model;

/** One multiple-choice item loaded from CSV. Not serialized; the file is the source. */
public class QuizQuestion {
    public final String id;
    public final String subject;
    public final String topic;
    public final String prompt;
    public final String[] choices;
    public final int correctIndex;
    public final String explanation;

    public QuizQuestion(String id, String subject, String topic, String prompt,
                        String[] choices, int correctIndex, String explanation) {
        this.id = id;
        this.subject = subject;
        this.topic = topic;
        this.prompt = prompt;
        this.choices = choices;
        this.correctIndex = correctIndex;
        this.explanation = explanation;
    }
}
