package aistudyplanner.util;

import java.time.LocalDate;

/** Date-stable original quotes so the dashboard does not need a network call. */
public final class Quotes {
    private static final String[] LINES = {
            "Small steps, repeated daily, become extraordinary progress.",
            "A focused minute is a vote for the future you want.",
            "Start where you are; one page is still progress.",
            "Your effort today makes tomorrow a little easier.",
            "Curiosity turns hard work into discovery.",
            "Consistency is quiet confidence in action.",
            "Make the next twenty minutes count.",
            "Progress grows when you return to the work.",
            "Every question you ask opens a door.",
            "You do not need perfect conditions to begin.",
            "Learning is built one brave attempt at a time.",
            "A clear goal gives your energy somewhere to go.",
            "Show up gently, then keep showing up.",
            "Today is a fresh chance to understand one more thing.",
            "The first step is often the most powerful one.",
            "Your pace is valid; keep moving forward.",
            "Focus on the task in front of you.",
            "Practice turns uncertainty into skill.",
            "Small wins deserve to be noticed.",
            "Give your attention to what matters now.",
            "A short study block can change your whole day.",
            "Rest is part of a thoughtful plan.",
            "Mistakes are evidence that you are stretching.",
            "Build the habit, and the results will follow.",
            "One solved problem can unlock many more.",
            "Keep your promise to your future self.",
            "Steady effort beats waiting for inspiration.",
            "You can learn difficult things one piece at a time.",
            "Begin with five minutes; momentum can follow.",
            "Make room for progress, not perfection."
    };

    private Quotes() {
    }

    public static String forToday() {
        int index = Math.floorMod((int) LocalDate.now().toEpochDay(), LINES.length);
        return LINES[index];
    }
}
