package aistudyplanner.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/** Small date/clock helpers so screens do not copy formatting code. */
public final class TimeFmt {
    public static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("EEE, MMM d");
    public static final DateTimeFormatter LONG = DateTimeFormatter.ofPattern("EEEE, MMMM d");

    private TimeFmt() {
    }

    public static String clock(int totalSeconds) {
        int safe = Math.max(0, totalSeconds);
        return String.format("%02d:%02d", safe / 60, safe % 60);
    }

    public static String hoursLabel(int minutes) {
        if (minutes < 60) {
            return minutes + " min";
        }
        int hours = minutes / 60;
        int rem = minutes % 60;
        if (rem == 0) {
            return hours + " h";
        }
        return hours + " h " + rem + " min";
    }

    public static String day(LocalDate date) {
        return date.format(DAY);
    }
}
