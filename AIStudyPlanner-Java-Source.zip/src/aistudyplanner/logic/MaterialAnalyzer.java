package aistudyplanner.logic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Dependency-free first-pass study report and material-grounded local Q&A. */
public final class MaterialAnalyzer {
    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
            "about", "after", "again", "also", "among", "because", "been", "being", "between", "could",
            "does", "during", "each", "from", "have", "into", "more", "most", "other", "over", "same",
            "some", "such", "than", "that", "their", "them", "then", "there", "these", "they", "this",
            "those", "through", "under", "very", "when", "where", "which", "while", "with", "would",
            "your", "will", "were", "what", "shall", "should", "must", "only", "being", "been", "also",
            "have", "has", "had", "the", "and", "for", "are", "was", "you", "not", "but", "can", "its",
            "who", "why", "how", "all", "any", "our", "out", "one", "two", "use", "used", "using",
            "may", "might", "not", "per", "via", "etc"));

    public String analyze(String raw, String examType) {
        String text = normalize(raw);
        if (text.isBlank()) return "No readable text was found. Try another file or paste the text directly.";
        List<String> sentences = sentences(text);
        List<String> keyTerms = topTerms(text, 8);
        List<String> facts = facts(text);
        int words = text.split("\\s+").length;
        int minutes = Math.max(5, (int) Math.ceil(words / 140.0));
        double average = sentences.stream().mapToInt(s -> s.split("\\s+").length).average().orElse(0);
        String difficulty = words > 2500 || average > 25 ? "Advanced"
                : words > 800 || average > 17 ? "Moderate" : "Introductory";

        StringBuilder out = new StringBuilder();
        out.append("MATERIAL STUDY BRIEF · ").append(examType == null ? "EXAM" : examType.toUpperCase(Locale.ROOT)).append("\n\n");
        out.append("SUMMARY\n").append(summarize(sentences, 3)).append("\n\n");
        out.append("KEY TOPICS\n");
        if (keyTerms.isEmpty()) out.append("• Add a longer source to identify topic terms.\n");
        else for (String term : keyTerms) out.append("• ").append(term).append('\n');
        out.append("\nDEFINITIONS AND FACTS\n");
        if (facts.isEmpty()) out.append("• No explicit definition or date pattern was found in this text.\n");
        else for (String fact : facts) out.append("• ").append(fact).append('\n');
        out.append("\nESTIMATED LEVEL & TIME\n").append(difficulty).append(" · about ").append(minutes)
                .append(" minute(s) for a focused first read (").append(words).append(" words).\n\n");
        out.append("SUGGESTED PLAN\n• Read once and mark key terms (about ").append(Math.max(5, minutes / 3)).append(" min).\n")
                .append("• Explain the main ideas from memory.\n• Attempt a short quiz, then review missed points tomorrow.");
        return out.toString();
    }

    public String answerFromMaterial(String material, String question) {
        String normalizedQuestion = question == null ? "" : question.toLowerCase(Locale.ROOT);
        StringBuilder matched = new StringBuilder();
        for (String sentence : sentences(normalize(material))) {
            for (String term : normalizedQuestion.split("[^\\p{L}\\p{N}]+")) {
                if (term.length() >= 4 && sentence.toLowerCase(Locale.ROOT).contains(term)) {
                    if (matched.length() > 0) matched.append(' ');
                    matched.append(sentence);
                    break;
                }
            }
            if (matched.length() > 900) break;
        }
        if (matched.length() == 0) return "I couldn't find a matching passage in the loaded material. Try asking with a topic or term from the document.";
        return "From your uploaded material: " + matched.toString().trim()
                + "\n\nThis is a local passage match. Enable the optional online mentor in Settings for a generated explanation.";
    }

    private static String normalize(String text) {
        return (text == null ? "" : text).replace('\u0000', ' ').replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\n\n").trim();
    }

    private static List<String> sentences(String text) {
        List<String> list = new ArrayList<>();
        for (String sentence : text.split("(?<=[.!?])\\s+|\\n+")) {
            String clean = sentence.replaceAll("\\s+", " ").trim();
            if (clean.length() > 24) list.add(clean);
        }
        return list;
    }

    private static String summarize(List<String> sentences, int count) {
        if (sentences.isEmpty()) return "The source has text, but no complete sentences could be separated.";
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < Math.min(count, sentences.size()); i++) text.append("• ").append(sentences.get(i)).append('\n');
        return text.toString().trim();
    }

    private static List<String> topTerms(String text, int limit) {
        Map<String, Integer> counts = new HashMap<>();
        Matcher matcher = Pattern.compile("[\\p{L}][\\p{L}\\p{N}-]{3,}").matcher(text.toLowerCase(Locale.ROOT));
        while (matcher.find()) {
            String word = matcher.group();
            if (!STOP.contains(word)) counts.merge(word, 1, Integer::sum);
        }
        List<Map.Entry<String, Integer>> sorted = new ArrayList<>(counts.entrySet());
        sorted.sort(Map.Entry.<String, Integer>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey()));
        List<String> terms = new ArrayList<>();
        for (int i = 0; i < Math.min(limit, sorted.size()); i++) terms.add(sorted.get(i).getKey());
        return terms;
    }

    private static List<String> facts(String text) {
        List<String> out = new ArrayList<>();
        Matcher definitions = Pattern.compile("(?i)([^.!?\\n]{3,100}\\b(?:is|are|means|refers to|defined as)\\b[^.!?\\n]{5,160}[.!?]?)").matcher(text);
        while (definitions.find() && out.size() < 8) out.add(definitions.group(1).trim());
        Matcher dates = Pattern.compile("\\b(?:\\d{1,2}[/-]\\d{1,2}[/-](?:\\d{2,4})|\\d{4}|\\d{1,2}\\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\\s+\\d{4})\\b", Pattern.CASE_INSENSITIVE).matcher(text);
        while (dates.find() && out.size() < 12) out.add("Date or year: " + dates.group());
        return out;
    }
}
