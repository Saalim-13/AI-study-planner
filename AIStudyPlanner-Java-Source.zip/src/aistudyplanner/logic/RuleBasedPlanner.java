package aistudyplanner.logic;

import aistudyplanner.model.AppData;
import aistudyplanner.model.StudyTask;
import aistudyplanner.model.Subject;
import aistudyplanner.model.Topic;
import aistudyplanner.model.KnowledgeTopic;
import aistudyplanner.util.TimeFmt;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Heuristic timetable builder (the local "AI").
 * Weak subjects and flagged quiz topics get more minutes.
 * After a LEARN block we plant revision on +1, +3, +7, +14 days (spaced repetition).
 * Revisions are placed first on those days so we do not overflow the daily hour cap.
 */
public class RuleBasedPlanner implements RecommendationService {
    private final CompetencyAnalyzer competency;
    private final KnowledgeModel knowledge = new KnowledgeModel();

    public RuleBasedPlanner(CompetencyAnalyzer competency) {
        this.competency = competency;
    }

    @Override
    public List<StudyTask> generateSchedule(AppData data, LocalDate start) {
        data.ensureCollections();
        List<StudyTask> plan = new ArrayList<>();
        if (data.subjects.isEmpty()) {
            return plan;
        }

        LocalDate lastExam = start;
        for (Subject subject : data.subjects) {
            subject.ensureDefaultTopics();
            if (subject.examDate.isAfter(lastExam)) {
                lastExam = subject.examDate;
            }
        }
        if (lastExam.isAfter(start.plusDays(28))) {
            lastExam = start.plusDays(28);
        }

        Map<LocalDate, List<StudyTask>> revisions = new HashMap<>();
        int daily = Math.max(0, data.profile.availableMinutes);

        // Existing knowledge records, created by real quiz answers, drive exact review dates.
        for (KnowledgeTopic state : data.knowledge.values()) {
            Subject subject = data.findSubject(state.subject);
            if (subject == null || state.nextReview == null || state.nextReview.isAfter(lastExam) || state.mastery >= 95) continue;
            LocalDate reviewDay=state.nextReview.isBefore(start)?start:state.nextReview;
            if(reviewDay.isAfter(subject.examDate))continue;
            StudyTask revise = new StudyTask(state.subject, state.topic,
                    state.mastery < 45 ? 30 : 20, state.mastery < 45 ? 5 : 4,
                    reviewDay, subject.examDate, StudyTask.REVISE);
            revisions.computeIfAbsent(reviewDay, d -> new ArrayList<>()).add(revise);
        }

        for (LocalDate day = start; !day.isAfter(lastExam); day = day.plusDays(1)) {
            int dayBudget = daily;
            if (day.equals(start) && start.equals(data.profile.checkInDate)) {
                dayBudget = Math.max(0, data.profile.todayAvailableMinutes);
            }
            int leftover = dayBudget;

            List<StudyTask> due = revisions.getOrDefault(day, new ArrayList<>());
            for (StudyTask revise : due) {
                if (leftover < 15) {
                    break;
                }
                int minutes = Math.min(leftover, revise.minutes);
                revise.minutes = minutes;
                leftover -= minutes;
                plan.add(revise);
            }

            List<WeightedTopic> pool = new ArrayList<>();
            for (Subject subject : data.subjects) {
                if (day.isAfter(subject.examDate)) {
                    continue;
                }
                for (Topic topic : subject.topics) {
                    pool.add(new WeightedTopic(subject, topic, weight(data, subject, topic, day)));
                }
            }
            if (pool.isEmpty() || leftover < 15) {
                continue;
            }
            pool.sort(Comparator.comparingDouble((WeightedTopic w) -> w.weight).reversed());
            double totalWeight = 0;
            for (WeightedTopic item : pool) {
                totalWeight += item.weight;
            }
            int budget = leftover;
            for (int i = 0; i < pool.size() && leftover >= 15; i++) {
                WeightedTopic item = pool.get(i);
                int share = (int) Math.round(budget * (item.weight / totalWeight));
                share = Math.max(15, Math.min(leftover, share));
                if (day.equals(start) && start.equals(data.profile.checkInDate) && data.profile.energy <= 2)
                    share = Math.min(20, share);
                leftover -= share;
                int priority = item.topic.strength <= 2 ? 5 : item.subject.strength <= 2 ? 4 : 3;
                StudyTask task = new StudyTask(
                        item.subject.name, item.topic.name, share, priority,
                        day, item.subject.examDate, StudyTask.LEARN);
                plan.add(task);
            }
        }
        plan.sort(Comparator.comparing((StudyTask t) -> t.day).thenComparingInt(t -> -t.priority));
        return plan;
    }

    @Override
    public StudyTask nextTask(AppData data) {
        LocalDate today = LocalDate.now();
        return data.tasks.stream()
                .filter(task -> !task.done && !task.day.isAfter(today))
                .max(Comparator.comparingInt(this::urgency))
                .orElse(null);
    }

    @Override
    public String recoveryAdvice(AppData data) {
        List<StudyTask> open = new ArrayList<>();
        for (StudyTask task : data.tasks) {
            if (!task.done) {
                open.add(task);
            }
        }
        open.sort(Comparator.comparingInt(this::urgency).reversed());
        int total = 0;
        for (StudyTask task : open) {
            total += task.minutes;
        }
        int left = Math.max(0, data.profile.availableMinutes - data.minutesStudiedOn(LocalDate.now()));
        StringBuilder text = new StringBuilder();
        text.append("Unfinished work: ").append(TimeFmt.hoursLabel(total)).append(".\n");
        text.append("Time still free today: ").append(TimeFmt.hoursLabel(left)).append(".\n\n");
        text.append("Suggested order (weak + overdue first):\n");
        int shown = 0;
        for (StudyTask task : open) {
            text.append("• ").append(task.label()).append(" — ").append(task.minutes)
                    .append(" min, due ").append(task.due).append(" (").append(task.kind).append(")\n");
            shown++;
            if (shown >= 12) {
                break;
            }
        }
        if (total > left) {
            text.append("\nOverloaded by ").append(total - left)
                    .append(" minutes. Postpone low-priority MANUAL tasks; keep REVISE slots.");
        }
        return text.toString();
    }

    private int urgency(StudyTask task) {
        int score = task.priority * 12 - task.minutes / 5;
        LocalDate today = LocalDate.now();
        if (task.due.isBefore(today) && !task.done) {
            score += 80;
        } else if (task.due.equals(today)) {
            score += 45;
        } else if (task.due.equals(today.plusDays(1))) {
            score += 25;
        }
        if (StudyTask.REVISE.equals(task.kind)) {
            score += 10;
        }
        return score;
    }

    private double weight(AppData data, Subject subject, Topic topic, LocalDate day) {
        KnowledgeTopic state = data.knowledge.get(KnowledgeModel.key(subject.name, topic.name));
        double retention = state == null ? topic.strength / 5.0 : state.estimatedRetention(day);
        double weakness = 1.0 - retention;
        if (data.profile.energy >= 4) weakness *= 1.25;
        long daysLeft = Math.max(1, ChronoUnit.DAYS.between(day, subject.examDate));
        double urgency = 1.0 / daysLeft;
        double gap = state == null ? competency.gapWeight(data, subject.name, topic.name)
                : Math.max(competency.gapWeight(data, subject.name, topic.name), 1.0 - state.mastery / 100.0);
        double subjectWeak = (6 - subject.strength) / 5.0;
        return 0.35 * weakness + 0.25 * subjectWeak + 0.2 * Math.min(1.0, urgency * 7)
                + 0.2 * gap + (data.profile.energy >= 4 ? 0.15 * (1.0 - retention) : 0);
    }

    private static class WeightedTopic {
        final Subject subject;
        final Topic topic;
        final double weight;

        WeightedTopic(Subject subject, Topic topic, double weight) {
            this.subject = subject;
            this.topic = topic;
            this.weight = weight;
        }
    }
}
