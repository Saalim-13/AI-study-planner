package aistudyplanner.logic;

import aistudyplanner.model.QuizQuestion;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Creates transparent source-grounded four-option MCQs from study material. */
public final class MaterialQuizGenerator {
    private static final Pattern WORD = Pattern.compile("[\\p{L}][\\p{L}0-9_-]{3,}");
    private static final Set<String> COMMON = new HashSet<>(java.util.Arrays.asList(
            "this", "that", "with", "from", "into", "when", "where", "which", "what", "their", "there", "these", "those", "have", "were", "will", "your", "about", "than", "then", "also", "such", "some", "each", "they", "them", "being", "using", "used", "over", "under", "more", "most", "many", "because", "while", "after", "before", "between", "through", "does", "make", "made", "only", "other", "very", "both", "much", "must", "should", "would", "could", "chapter", "section", "from", "into", "when", "were", "been", "will", "shall", "upon", "such", "also", "these", "those"));

    private MaterialQuizGenerator() { }

    public static List<String> suggestTopics(String text) {
        Map<String, Integer> counts = new HashMap<>();
        Matcher words = WORD.matcher(text == null ? "" : text);
        while (words.find()) {
            String word = words.group();
            if (!COMMON.contains(word.toLowerCase(Locale.ROOT))) counts.merge(word, 1, Integer::sum);
        }
        List<Map.Entry<String, Integer>> sorted = new ArrayList<>(counts.entrySet());
        sorted.sort(Map.Entry.<String, Integer>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey(String.CASE_INSENSITIVE_ORDER)));
        List<String> result = new ArrayList<>();
        for (int i = 0; i < Math.min(12, sorted.size()); i++) result.add(sorted.get(i).getKey());
        return result;
    }

    /** Difficulty influences key-term selection and exam-style wording. */
    public static List<QuizQuestion> generate(String text, String subject, String topic,
                                               int limit, String difficulty) {
        return generate(text, subject, topic, topic, limit, difficulty);
    }

    /** Separates the requested topic filter from the saved topic label. */
    public static List<QuizQuestion> generate(String text, String subject, String topicFilter,
                                               String topicLabel, int limit, String difficulty) {
        List<QuizQuestion> result = new ArrayList<>();
        String safeText = text == null ? "" : text;
        String selectedTopic = topicFilter == null ? "" : topicFilter.trim();
        String savedTopic = topicLabel == null || topicLabel.isBlank() || "All topics".equalsIgnoreCase(topicLabel)
                ? "Uploaded material" : topicLabel.trim();
        Set<String> vocabulary = new LinkedHashSet<>(suggestTopics(safeText));
        Matcher all = WORD.matcher(safeText);
        while (all.find()) {
            String word = all.group();
            if (!COMMON.contains(word.toLowerCase(Locale.ROOT))) vocabulary.add(word);
        }
        if (vocabulary.size() < 4) return result;

        String level = difficulty == null ? "Medium" : difficulty;
        int minLength = "Hard".equalsIgnoreCase(level) ? 7 : "Medium".equalsIgnoreCase(level) ? 5 : 4;
        String[] sentences = safeText.replaceAll("(?m)^\\s*#.*$", " ").split("(?<=[.!?])\\s+|\\R+");
        for (String sentence : sentences) {
            String clean = sentence.trim().replaceAll("\\s+", " ");
            if (clean.length() < 35 || clean.length() > 500) continue;
            if (!selectedTopic.isBlank() && !selectedTopic.equalsIgnoreCase("All topics")
                    && !clean.toLowerCase(Locale.ROOT).contains(selectedTopic.toLowerCase(Locale.ROOT))) continue;
            Matcher words = WORD.matcher(clean);
            List<String> candidates = new ArrayList<>();
            while (words.find()) {
                String candidate = words.group();
                if (!COMMON.contains(candidate.toLowerCase(Locale.ROOT)) && candidate.length() >= minLength) candidates.add(candidate);
            }
            if (candidates.isEmpty()) continue;
            String answer = "Hard".equalsIgnoreCase(level) ? candidates.get(candidates.size() - 1) : candidates.get(0);
            List<String> options = new ArrayList<>();
            options.add(answer);
            List<String> distractors = new ArrayList<>(vocabulary);
            distractors.sort(Comparator.comparingInt((String word) -> Math.abs(word.length() - answer.length()))
                    .thenComparing(String.CASE_INSENSITIVE_ORDER));
            for (String word : distractors) {
                if (!word.equalsIgnoreCase(answer) && !options.contains(word)) options.add(word);
                if (options.size() == 4) break;
            }
            if (options.size() < 4) continue;
            int rotation = Math.floorMod(clean.hashCode(), options.size());
            List<String> choices = new ArrayList<>(options);
            for (int i = 0; i < rotation; i++) choices.add(choices.remove(0));
            int correct = choices.indexOf(answer);
            String prompt = clean.replaceFirst("(?i)\\b" + Pattern.quote(answer) + "\\b", "________");
            String style = "Easy".equalsIgnoreCase(level) ? "Complete the statement"
                    : "Hard".equalsIgnoreCase(level) ? "Identify the exam concept omitted from this passage"
                    : "Choose the key term that completes this source statement";
            result.add(new QuizQuestion("material-" + UUID.randomUUID(), subject,
                    selectedTopic.isBlank() || "All topics".equalsIgnoreCase(selectedTopic) ? savedTopic : selectedTopic,
                    style + ": " + prompt,
                    choices.toArray(new String[0]), correct,
                    "Source sentence: " + clean + " The omitted term is “" + answer + "”."));
            if (result.size() >= Math.max(1, limit)) break;
        }
        return result;
    }

    /** Preserves the original call signature for older local import flows. */
    public static List<QuizQuestion> generate(String text, String subject, String topic, int limit) {
        return generate(text, subject, topic, limit, "Medium");
    }
}
