package aistudyplanner.logic;

import aistudyplanner.AppContext;
import aistudyplanner.model.KnowledgeTopic;
import java.util.ArrayList;
import java.util.List;

/** Awards modest XP for actual answered questions and records milestone badges. */
public final class GamificationService {
    public static final class Award {
        public final int oldLevel, newLevel, gained, totalXp;
        public final List<String> newBadges;
        Award(int oldLevel, int newLevel, int gained, int totalXp, List<String> badges) {
            this.oldLevel=oldLevel; this.newLevel=newLevel; this.gained=gained; this.totalXp=totalXp; this.newBadges=badges;
        }
    }

    public Award awardQuiz(AppContext ctx, int correct, int total) {
        ctx.data.ensureCollections();
        int oldLevel = level(ctx.data.xp);
        int gained = Math.max(0, correct) * 10 + Math.max(0, total - correct) * 2 + (total > 0 && correct == total ? 20 : 0);
        ctx.data.xp += gained;
        List<String> unlocked = new ArrayList<>();
        badge(ctx, "7-day streak", DashboardScreenStreak.streak(ctx) >= 7, unlocked);
        badge(ctx, "100 questions answered", ctx.data.quizAttempts.size() >= 100, unlocked);
        for (KnowledgeTopic topic : ctx.data.knowledge.values()) {
            if (topic.attempts >= 3 && topic.mastery >= 80) {
                badge(ctx, "Weak topic conquered: " + topic.subject + " / " + topic.topic, true, unlocked);
            }
        }
        return new Award(oldLevel, level(ctx.data.xp), gained, ctx.data.xp, unlocked);
    }

    public static int level(int xp) { return Math.max(1, xp / 100 + 1); }
    public static int progressInLevel(int xp) { return Math.floorMod(xp, 100); }

    private static void badge(AppContext ctx, String name, boolean qualifies, List<String> unlocked) {
        if (qualifies && !ctx.data.badges.contains(name)) {
            ctx.data.badges.add(name);
            unlocked.add(name);
        }
    }

    /** Keeps streak computation local to the service and based on real sessions. */
    private static final class DashboardScreenStreak {
        static int streak(AppContext ctx) {
            java.util.Set<java.time.LocalDate> days = new java.util.HashSet<>();
            ctx.data.sessions.stream().filter(s -> s.actualMinutes > 0).forEach(s -> {days.add(s.date);if(s.minutesOn(s.date.plusDays(1))>0)days.add(s.date.plusDays(1));});
            int n=0; java.time.LocalDate d=days.contains(java.time.LocalDate.now())?java.time.LocalDate.now():java.time.LocalDate.now().minusDays(1);
            while(days.contains(d)){n++;d=d.minusDays(1);} return n;
        }
    }
}
