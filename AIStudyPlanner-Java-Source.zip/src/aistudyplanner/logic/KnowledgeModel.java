package aistudyplanner.logic;

import aistudyplanner.model.AppData;
import aistudyplanner.model.KnowledgeTopic;
import aistudyplanner.model.Subject;
import aistudyplanner.model.Topic;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Local adaptive knowledge model. No network or generated/fabricated scores. */
public final class KnowledgeModel {
    public static String key(String subject, String topic) {
        return (subject.trim() + "\n" + topic.trim()).toLowerCase(java.util.Locale.ROOT);
    }

    public KnowledgeTopic getOrCreate(AppData data, String subject, String topic) {
        data.ensureCollections();
        String key = key(subject, topic);
        KnowledgeTopic state = data.knowledge.get(key);
        if (state == null) {
            state = new KnowledgeTopic();
            state.subject = subject;
            state.topic = topic;
            Subject found = data.findSubject(subject);
            if (found != null) {
                for (Topic item : found.topics) {
                    if (item.name.equalsIgnoreCase(topic)) {
                        state.mastery = (int) Math.round(item.strength * 20.0);
                        break;
                    }
                }
            }
            data.knowledge.put(key, state);
        }
        return state;
    }

    /** Applies a quiz answer using the SM-2 interval/ease-factor update. */
    public KnowledgeTopic recordQuiz(AppData data, String subject, String topic, boolean correct, LocalDate on) {
        return recordQuiz(data, subject, topic, correct ? 1.0 : 0.0, on);
    }

    /** One aggregate result per topic per quiz; accuracy determines SM-2 quality 0–5. */
    public KnowledgeTopic recordQuiz(AppData data, String subject, String topic, double accuracy, LocalDate on) {
        KnowledgeTopic state = getOrCreate(data, subject, topic);
        accuracy=Math.max(0,Math.min(1,accuracy));
        int quality=(int)Math.round(accuracy*5);
        state.attempts++;
        if (accuracy>=0.5) state.correct++;
        int oldMastery = state.mastery;
        state.mastery = clamp((int) Math.round(oldMastery + (accuracy>=0.6
                ? Math.max(2, (100 - oldMastery) * accuracy * 0.22)
                : -Math.max(4, oldMastery * (0.34-accuracy*0.18)))));
        state.confidence = Math.max(0.05, Math.min(0.99,
                state.confidence * 0.72 + accuracy * 0.28));

        if (quality < 3) {
            state.repetitions = 0;
            state.intervalDays = 1;
        } else {
            state.repetitions++;
            if (state.repetitions == 1) state.intervalDays = 1;
            else if (state.repetitions == 2) state.intervalDays = 6;
            else state.intervalDays = Math.max(1, (int) Math.round(state.intervalDays * state.easeFactor));
        }
        state.easeFactor = Math.max(1.3, state.easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)));
        state.lastStudied = on;
        state.nextReview = on.plusDays(state.intervalDays);
        syncStrength(data, state);
        return state;
    }

    /** Records a real focus session without guessing that exposure equals mastery. */
    public void recordStudy(AppData data, String subject, String topic, LocalDate on) {
        if(subject==null||subject.isBlank()||topic==null||topic.isBlank())return;
        KnowledgeTopic state=getOrCreate(data,subject,topic);
        state.lastStudied=on;
        if(state.attempts==0 && (state.nextReview==null||!state.nextReview.isAfter(on))) {
            state.intervalDays=1;
            state.nextReview=on.plusDays(1);
        }
    }

    public List<KnowledgeTopic> dueTopics(AppData data, LocalDate through) {
        data.ensureCollections();
        List<KnowledgeTopic> due = new ArrayList<>();
        for (KnowledgeTopic topic : data.knowledge.values()) {
            if (topic.nextReview != null && !topic.nextReview.isAfter(through)) due.add(topic);
        }
        due.sort(Comparator.comparing((KnowledgeTopic t) -> t.nextReview)
                .thenComparingInt(t -> t.mastery));
        return due;
    }

    public String explain(KnowledgeTopic state) {
        if (state.correct < state.attempts) {
            return state.topic + " is scheduled sooner because a recent answer was missed. SM-2 set its next review for " + state.nextReview + ".";
        }
        return state.topic + " is scheduled for " + state.nextReview + " based on " + state.intervalDays
                + " day(s) of successful recall (SM-2).";
    }

    public static boolean selfCheckSm2() {
        AppData data = new AppData();
        KnowledgeModel model = new KnowledgeModel();
        LocalDate day = LocalDate.of(2026, 1, 1);
        KnowledgeTopic first = model.recordQuiz(data, "History", "Reform", true, day);
        if (first.intervalDays != 1 || !day.plusDays(1).equals(first.nextReview)) return false;
        int masteryAfterCorrect = first.mastery;
        KnowledgeTopic failed = model.recordQuiz(data, "History", "Reform", false, day.plusDays(1));
        return failed.repetitions == 0 && failed.intervalDays == 1 && failed.mastery < masteryAfterCorrect;
    }

    public static boolean selfCheckMasteryUpdate() {
        AppData data = new AppData();
        KnowledgeModel model = new KnowledgeModel();
        int initial = model.getOrCreate(data, "Science", "Cells").mastery;
        KnowledgeTopic correct = model.recordQuiz(data, "Science", "Cells", true, LocalDate.now());
        int raised = correct.mastery;
        KnowledgeTopic wrong = model.recordQuiz(data, "Science", "Cells", false, LocalDate.now());
        return raised > initial && wrong.mastery < raised && wrong.confidence > 0;
    }

    public static boolean selfCheckScheduler() {
        AppData data = new AppData();
        Subject subject = new Subject("Science", LocalDate.now().plusDays(10), 3);
        subject.topics.add(new Topic("Cells", 2));
        data.subjects.add(subject);
        KnowledgeTopic state = new KnowledgeModel().getOrCreate(data, "Science", "Cells");
        state.lastStudied = LocalDate.now().minusDays(1);
        state.nextReview = LocalDate.now();
        state.intervalDays = 1;
        List<aistudyplanner.model.StudyTask> tasks = new RuleBasedPlanner(new CompetencyAnalyzer())
                .generateSchedule(data, LocalDate.now());
        for (aistudyplanner.model.StudyTask task : tasks) {
            if (aistudyplanner.model.StudyTask.REVISE.equals(task.kind)
                    && task.topic.equals("Cells") && task.day.equals(LocalDate.now())) return true;
        }
        return false;
    }

    private void syncStrength(AppData data, KnowledgeTopic state) {
        Subject subject = data.findSubject(state.subject);
        if (subject == null) return;
        for (Topic topic : subject.topics) {
            if (topic.name.equalsIgnoreCase(state.topic)) {
                topic.strength = Math.max(1, Math.min(5, (int) Math.round(state.mastery / 20.0)));
                break;
            }
        }
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
}
