package aistudyplanner.logic;

import aistudyplanner.model.AppData;
import aistudyplanner.model.QuizAttempt;
import aistudyplanner.model.Subject;
import aistudyplanner.model.Topic;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Turns quiz history into "this topic is weak" flags the planner can use. */
public class CompetencyAnalyzer {

    public static class TopicScore {
        public final String subject;
        public final String topic;
        public final int attempts;
        public final int correct;
        public final int percent;
        public final boolean weak;

        public TopicScore(String subject, String topic, int attempts, int correct, int percent, boolean weak) {
            this.subject = subject;
            this.topic = topic;
            this.attempts = attempts;
            this.correct = correct;
            this.percent = percent;
            this.weak = weak;
        }
    }

    public List<TopicScore> scores(AppData data) {
        Map<String, int[]> buckets = new LinkedHashMap<>();
        for (QuizAttempt attempt : data.quizAttempts) {
            String key = attempt.subject + "\n" + attempt.topic;
            int[] pair = buckets.get(key);
            if (pair == null) {
                pair = new int[2];
                buckets.put(key, pair);
            }
            pair[0]++;
            if (attempt.correct) {
                pair[1]++;
            }
        }
        List<TopicScore> result = new ArrayList<>();
        for (Map.Entry<String, int[]> entry : buckets.entrySet()) {
            String[] parts = entry.getKey().split("\n", 2);
            int attempts = entry.getValue()[0];
            int correct = entry.getValue()[1];
            int percent = attempts == 0 ? 0 : (int) Math.round(100.0 * correct / attempts);
            boolean weak = attempts >= 2 && percent < data.profile.weakThreshold;
            result.add(new TopicScore(parts[0], parts[1], attempts, correct, percent, weak));
        }
        return result;
    }

    public List<TopicScore> weakTopics(AppData data) {
        List<TopicScore> weak = new ArrayList<>();
        for (TopicScore score : scores(data)) {
            if (score.weak) {
                weak.add(score);
            }
        }
        return weak;
    }

    /** Extra weight for the scheduler: 0 if unknown, up to 1.0 if very weak. */
    public double gapWeight(AppData data, String subject, String topic) {
        for (TopicScore score : scores(data)) {
            if (score.subject.equalsIgnoreCase(subject) && score.topic.equalsIgnoreCase(topic)) {
                if (score.attempts == 0) {
                    return 0.35;
                }
                double miss = 1.0 - score.percent / 100.0;
                return score.weak ? 0.5 + miss * 0.5 : miss * 0.3;
            }
        }
        return 0.35;
    }

    public int subjectPercent(AppData data, String subject) {
        int attempts = 0;
        int correct = 0;
        for (QuizAttempt attempt : data.quizAttempts) {
            if (attempt.subject.equalsIgnoreCase(subject)) {
                attempts++;
                if (attempt.correct) {
                    correct++;
                }
            }
        }
        if (attempts == 0) {
            Subject found = data.findSubject(subject);
            if (found == null) {
                return 50;
            }
            return found.strength * 20;
        }
        return (int) Math.round(100.0 * correct / attempts);
    }

    /** Push quiz gaps back onto topic strength so the next generated plan tilts toward them. */
    public void applyGapsToSubjects(AppData data) {
        for (TopicScore score : weakTopics(data)) {
            Subject subject = data.findSubject(score.subject);
            if (subject == null) {
                continue;
            }
            for (Topic topic : subject.topics) {
                if (topic.name.equalsIgnoreCase(score.topic)) {
                    topic.strength = Math.max(1, topic.strength - 1);
                }
            }
        }
    }
}
