package aistudyplanner.logic;

import aistudyplanner.model.AppData;
import aistudyplanner.model.QuizAttempt;
import aistudyplanner.model.QuizQuestion;
import aistudyplanner.model.KnowledgeTopic;
import aistudyplanner.model.Flashcard;
import aistudyplanner.logic.CompetencyAnalyzer.TopicScore;
import aistudyplanner.storage.QuizBankLoader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Map;
import java.util.TreeMap;

/** Picks questions and records answers. Stays separate from Swing so it is easy to test. */
public class QuizService {
    private final QuizBankLoader loader;
    private List<QuizQuestion> bank = new ArrayList<>();

    public QuizService(QuizBankLoader loader) {
        this.loader = loader;
        reload();
    }

    public void reload() {
        bank = loader.load();
    }

    public List<String> subjects() {
        List<String> names = new ArrayList<>();
        for (QuizQuestion question : bank) {
            if (!names.contains(question.subject)) {
                names.add(question.subject);
            }
        }
        Collections.sort(names);
        return names;
    }

    public List<QuizQuestion> startQuiz(String subject, int count) {
        List<QuizQuestion> pool = new ArrayList<>();
        for (QuizQuestion question : bank) {
            if (subject == null || subject.isBlank() || question.subject.equalsIgnoreCase(subject)) {
                pool.add(question);
            }
        }
        Collections.shuffle(pool, new Random());
        if (pool.size() > count) {
            return new ArrayList<>(pool.subList(0, count));
        }
        return pool;
    }

    /** Builds a quiz from topics the learner has missed before. */
    public List<QuizQuestion> startReviewQuiz(AppData data, int count, boolean weakOnly) {
        List<String> topicKeys = new ArrayList<>();
        if (weakOnly) {
            for (TopicScore score : new CompetencyAnalyzer().weakTopics(data)) {
                topicKeys.add((score.subject + "\n" + score.topic).toLowerCase());
            }
        } else {
            for (QuizAttempt attempt : data.quizAttempts) {
                if (!attempt.correct) topicKeys.add((attempt.subject + "\n" + attempt.topic).toLowerCase());
            }
        }
        List<QuizQuestion> pool = new ArrayList<>();
        for (QuizQuestion question : bank) {
            String key = (question.subject + "\n" + question.topic).toLowerCase();
            if (topicKeys.contains(key)) pool.add(question);
        }
        Collections.shuffle(pool, new Random());
        return pool.size() > count ? new ArrayList<>(pool.subList(0, count)) : pool;
    }

    /** Daily challenge samples up to five bank questions from the learner's lowest mastery topics. */
    public List<QuizQuestion> startDailyChallenge(AppData data) {
        data.ensureCollections();
        List<KnowledgeTopic> weakest = new ArrayList<>(data.knowledge.values());
        weakest.sort(Comparator.comparingInt((KnowledgeTopic t) -> t.mastery)
                .thenComparingDouble(t -> t.confidence));
        List<String> keys = new ArrayList<>();
        for (int i = 0; i < Math.min(5, weakest.size()); i++) {
            keys.add((weakest.get(i).subject + "\n" + weakest.get(i).topic).toLowerCase());
        }
        List<QuizQuestion> pool = new ArrayList<>();
        for (QuizQuestion question : bank) {
            if (keys.contains((question.subject + "\n" + question.topic).toLowerCase())) pool.add(question);
        }
        Collections.shuffle(pool, new Random());
        return pool.size() > 5 ? new ArrayList<>(pool.subList(0, 5)) : pool;
    }

    /** Retakes questions whose most recent recorded answer was incorrect. */
    public List<QuizQuestion> startMistakeQuiz(AppData data, int count) {
        Map<String, QuizAttempt> latest = new TreeMap<>();
        for (QuizAttempt attempt : data.quizAttempts) latest.put(attempt.questionId, attempt);
        List<QuizQuestion> pool = new ArrayList<>();
        for (QuizQuestion question : bank) {
            QuizAttempt attempt = latest.get(question.id);
            if (attempt != null && !attempt.correct) pool.add(question);
        }
        Collections.shuffle(pool, new Random());
        return pool.size() > count ? new ArrayList<>(pool.subList(0, count)) : pool;
    }

    public static void addFlashcard(AppData data, QuizQuestion question) {
        data.ensureCollections();
        for (Flashcard card : data.flashcards) if (card.id.equals(question.id)) return;
        data.flashcards.add(new Flashcard(question.id, question.subject, question.topic,
                question.prompt, question.choices[question.correctIndex], question.explanation));
    }

    public void record(AppData data, QuizQuestion question, int chosenIndex, int secondsUsed) {
        record(data, question, chosenIndex, secondsUsed, false);
    }

    /** Saves a submitted or timer-expired answer. A timeout keeps the selected option. */
    public void record(AppData data, QuizQuestion question, int chosenIndex, int secondsUsed, boolean timedOut) {
        data.ensureCollections();
        QuizAttempt attempt = new QuizAttempt();
        attempt.questionId = question.id;
        attempt.subject = question.subject;
        attempt.topic = question.topic;
        attempt.correct = chosenIndex == question.correctIndex;
        attempt.timedOut = timedOut;
        attempt.secondsUsed = secondsUsed;
        attempt.prompt = question.prompt;
        attempt.explanation = question.explanation;
        attempt.correctAnswer = question.choices[question.correctIndex];
        attempt.learnerAnswer = chosenIndex >= 0 && chosenIndex < question.choices.length
                ? question.choices[chosenIndex] : "Skipped";
        data.quizAttempts.add(attempt);
        if (!attempt.correct) addFlashcard(data, question);
    }

    public int bankSize() {
        return bank.size();
    }

    public String bankSummary() {
        Map<String, Integer> counts = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (QuizQuestion question : bank) {
            counts.merge(question.subject + " / " + question.topic, 1, Integer::sum);
        }
        if (counts.isEmpty()) return "Your quiz bank is empty. Upload a TXT or Markdown study file to create practice questions.";
        StringBuilder summary = new StringBuilder("Questions by subject and topic\n\n");
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            summary.append(entry.getKey()).append("  •  ").append(entry.getValue()).append(" questions\n");
        }
        summary.append("\nTotal: ").append(bank.size()).append(" questions");
        return summary.toString();
    }
}


