package aistudyplanner.logic;

import aistudyplanner.model.AppData;
import aistudyplanner.model.StudyTask;

import java.time.LocalDate;
import java.util.List;

/**
 * Pluggable "AI" brain.
 * Today's implementation is rule-based (see RuleBasedPlanner).
 * Later you can add a class that calls an online API and still return List&lt;StudyTask&gt;.
 */
public interface RecommendationService {
    /** Build a day-by-day timetable from subjects, hours, strength, and quiz gaps. */
    List<StudyTask> generateSchedule(AppData data, LocalDate start);

    /** Pick the most useful unfinished task for right now. */
    StudyTask nextTask(AppData data);

    /** Explain why the current plan looks overloaded, without changing tasks. */
    String recoveryAdvice(AppData data);
}
