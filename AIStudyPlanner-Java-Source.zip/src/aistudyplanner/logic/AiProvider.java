package aistudyplanner.logic;

import aistudyplanner.AppContext;

/** Interface boundary for local or future online study mentors. */
public interface AiProvider {
    String reply(AppContext context, String message);

    /** Context-aware extension that can answer follow-up questions about loaded material. */
    default String replyWithMaterial(AppContext context, String message, String material) {
        if (material != null && !material.isBlank()) {
            return new MaterialAnalyzer().answerFromMaterial(material, message);
        }
        return reply(context, message);
    }

    /** Produces a local study-focused material report unless a configured provider overrides it. */
    default String analyzeMaterial(AppContext context, String material) {
        return new MaterialAnalyzer().analyze(material, context.data.profile.examType);
    }
}
