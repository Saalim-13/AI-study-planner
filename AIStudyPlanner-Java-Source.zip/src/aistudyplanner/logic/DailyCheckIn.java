package aistudyplanner.logic;

import aistudyplanner.AppContext;
import aistudyplanner.model.Profile;
import aistudyplanner.model.StudySession;
import aistudyplanner.model.StudyTask;
import javax.swing.*;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Set;

/** Once-a-day check-in and cautious, explainable burnout signals. */
public final class DailyCheckIn {
    private DailyCheckIn() { }

    public static void run(AppContext ctx) {
        Profile profile = ctx.data.profile;
        LocalDate today = LocalDate.now();
        if (today.equals(profile.checkInDate)) return;
        JSpinner energy = new JSpinner(new SpinnerNumberModel(profile.energy, 1, 5, 1));
        JSpinner available = new JSpinner(new SpinnerNumberModel(
                Math.min(profile.availableMinutes, profile.todayAvailableMinutes <= 0 ? profile.availableMinutes : profile.todayAvailableMinutes),
                0, Math.max(15, profile.availableMinutes), 15));
        JComboBox<String> mood = new JComboBox<>(new String[]{"Great", "Okay", "Low", "Stressed"});
        mood.setSelectedItem(profile.mood == null ? "Okay" : profile.mood);
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Energy (1 low – 5 high)")); form.add(energy);
        form.add(new JLabel("How are you feeling?")); form.add(mood);
        form.add(new JLabel("Study minutes available today")); form.add(available);
        int answer = JOptionPane.showConfirmDialog(ctx.applet, form,
                "Good morning, " + profile.name + " — quick check-in", JOptionPane.OK_CANCEL_OPTION);
        if (answer != JOptionPane.OK_OPTION) return;
        profile.energy = (Integer) energy.getValue();
        profile.mood = (String) mood.getSelectedItem();
        profile.todayAvailableMinutes = (Integer) available.getValue();
        profile.checkInDate = today;
        adjustToday(ctx);
        ctx.saveQuietly();
        String signals = burnoutAdvice(ctx);
        if (!signals.isBlank()) JOptionPane.showMessageDialog(ctx.applet, signals,
                "A gentle check on your study rhythm", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void adjustToday(AppContext ctx) {
        LocalDate today = LocalDate.now();
        int cap = ctx.data.profile.todayAvailableMinutes;
        if (cap <= 0) return;
        int used = ctx.data.minutesStudiedOn(today);
        int left = Math.max(0, cap - used);
        java.util.List<StudyTask> tasks = ctx.data.tasks.stream()
                .filter(t -> !t.done && t.day.equals(today) && !StudyTask.MANUAL.equals(t.kind))
                .sorted(java.util.Comparator.comparingInt((StudyTask t) -> t.priority).reversed())
                .toList();
        for (StudyTask task : tasks) {
            if (left <= 0) { task.day = today.plusDays(1); continue; }
            int energyLimit = ctx.data.profile.energy <= 2 ? 20 : Integer.MAX_VALUE;
            task.minutes = Math.max(0, Math.min(task.minutes, Math.min(left, energyLimit)));
            left -= task.minutes;
        }
    }

    /** Returns signals with evidence, never a diagnosis. */
    public static String burnoutAdvice(AppContext ctx) {
        LocalDate today = LocalDate.now();
        Set<LocalDate> sessionDays = new HashSet<>();
        boolean longBlock = false;
        for (StudySession session : ctx.data.sessions) {
            if (!session.date.isBefore(today.minusDays(7))) sessionDays.add(session.date);
            if (!session.date.isBefore(today.minusDays(7)) && session.actualMinutes >= 90) longBlock = true;
        }
        int plannedMisses = 0;
        for (int i = 1; i <= 7; i++) {
            LocalDate day = today.minusDays(i);
            boolean hadPlan = ctx.data.tasks.stream().anyMatch(t -> t.day.equals(day));
            if (hadPlan && !sessionDays.contains(day)) plannedMisses++;
        }
        boolean falling = false;
        if (ctx.data.quizAttempts.size() >= 12) {
            int n = ctx.data.quizAttempts.size();
            double oldRate = ctx.data.quizAttempts.subList(Math.max(0, n - 20), n - 10).stream().filter(a -> a.correct).count() / 10.0;
            double recentRate = ctx.data.quizAttempts.subList(n - 10, n).stream().filter(a -> a.correct).count() / 10.0;
            falling = recentRate <= oldRate - 0.2;
        }
        if (plannedMisses < 2 && !falling && !longBlock && !"Stressed".equals(ctx.data.profile.mood)) return "";
        StringBuilder text = new StringBuilder("Your recent records suggest it may help to take an easier day. This is only a gentle pattern check, not a diagnosis.\n\n");
        if (plannedMisses >= 2) text.append("• ").append(plannedMisses).append(" planned days in the last week had no recorded study session.\n");
        if (falling) text.append("• Accuracy in your latest 10 answers is lower than the 10 before them.\n");
        if (longBlock) text.append("• At least one recent focus session was 90 minutes or longer; schedule a break between long blocks.\n");
        if ("Stressed".equals(ctx.data.profile.mood) || "Low".equals(ctx.data.profile.mood)) text.append("• You checked in as feeling ").append(ctx.data.profile.mood.toLowerCase()).append(".\n");
        text.append("Consider lowering today's goal, taking a full break, or postponing a lower-priority task.");
        return text.toString();
    }
}
