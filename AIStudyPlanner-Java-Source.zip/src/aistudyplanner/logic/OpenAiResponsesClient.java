package aistudyplanner.logic;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Small JDK HTTP client for the official OpenAI Responses API; secrets stay in environment variables. */
final class OpenAiResponsesClient {
    private static final URI ENDPOINT = URI.create("https://api.openai.com/v1/responses");

    String respond(String instructions, String input) throws Exception {
        String key = System.getenv("OPENAI_API_KEY");
        if (key == null || key.isBlank()) throw new IllegalStateException("OPENAI_API_KEY is not set.");
        String model = System.getenv("OPENAI_MODEL");
        if (model == null || model.isBlank()) model = "gpt-4.1-mini";
        String body = "{\"model\":" + quote(model) + ",\"instructions\":" + quote(instructions)
                + ",\"input\":" + quote(input) + ",\"max_output_tokens\":1000}";
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(12)).build();
        HttpRequest request = HttpRequest.newBuilder(ENDPOINT)
                .timeout(Duration.ofSeconds(50))
                .header("Authorization", "Bearer " + key)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("OpenAI API returned HTTP " + response.statusCode() + ". Check the key, model, quota, and network connection.");
        }
        String result = extractOutputText(response.body());
        if (result.isBlank()) throw new IllegalStateException("The AI response did not contain readable text.");
        return result;
    }

    private static String quote(String text) {
        StringBuilder out = new StringBuilder("\"");
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 32) out.append(String.format("\\u%04x", (int) c));
                    else out.append(c);
            }
        }
        return out.append('"').toString();
    }

    /** Reads text fields only from the response output array; handles JSON string escapes. */
    private static String extractOutputText(String json) {
        int output = json.indexOf("\"output\"");
        if (output < 0) return "";
        StringBuilder out = new StringBuilder();
        int cursor = output;
        while ((cursor = json.indexOf("\"text\"", cursor)) >= 0) {
            int colon = json.indexOf(':', cursor + 6);
            if (colon < 0) break;
            int start = colon + 1;
            while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
            if (start >= json.length() || json.charAt(start) != '"') { cursor = colon + 1; continue; }
            ParseString parsed = parseString(json, start);
            if (out.length() > 0) out.append('\n');
            out.append(parsed.value);
            cursor = parsed.next;
        }
        return out.toString().trim();
    }

    private static ParseString parseString(String json, int quoteAt) {
        StringBuilder value = new StringBuilder();
        int i = quoteAt + 1;
        while (i < json.length()) {
            char c = json.charAt(i++);
            if (c == '"') break;
            if (c != '\\') { value.append(c); continue; }
            if (i >= json.length()) break;
            char escaped = json.charAt(i++);
            switch (escaped) {
                case '"': case '\\': case '/': value.append(escaped); break;
                case 'n': value.append('\n'); break;
                case 'r': value.append('\r'); break;
                case 't': value.append('\t'); break;
                case 'b': value.append('\b'); break;
                case 'f': value.append('\f'); break;
                case 'u':
                    if (i + 4 <= json.length()) {
                        try { value.append((char) Integer.parseInt(json.substring(i, i + 4), 16)); } catch (NumberFormatException ignored) { }
                        i += 4;
                    }
                    break;
                default: value.append(escaped);
            }
        }
        return new ParseString(value.toString(), i);
    }

    private static final class ParseString {
        final String value; final int next;
        ParseString(String value, int next) { this.value = value; this.next = next; }
    }
}
