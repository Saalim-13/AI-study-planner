package aistudyplanner.logic;

import aistudyplanner.AppContext;
import aistudyplanner.model.ChatMessage;
import aistudyplanner.model.KnowledgeTopic;
import aistudyplanner.model.StudyTask;

import java.util.Comparator;
import java.util.Locale;

/** Uses online AI only after an explicit app opt-in and a valid environment API key. */
public final class ConfigurableAiProvider implements AiProvider {
    private final RuleBasedMentor local = new RuleBasedMentor();
    private final MaterialAnalyzer analyzer = new MaterialAnalyzer();
    private final OpenAiResponsesClient online = new OpenAiResponsesClient();

    @Override public String reply(AppContext ctx, String message) {
        return replyWithMaterial(ctx, message, ctx.data.activeMaterialText);
    }

    @Override public String replyWithMaterial(AppContext ctx, String message, String material) {
        boolean hasMaterial = material != null && !material.isBlank();
        if (onlineEnabled(ctx)) {
            try {
                return online.respond(instructions(ctx), chatInput(ctx, message, material));
            } catch (Exception ex) {
                return "I couldn't reach the online AI mentor (" + cleanError(ex) + "). "
                        + localAnswer(ctx, message, material, hasMaterial);
            }
        }
        String answer = localAnswer(ctx, message, material, hasMaterial);
        if (ctx.data.profile.onlineAiEnabled && !hasApiKey()) {
            answer += "\n\nOnline AI is enabled in Settings, but OPENAI_API_KEY is missing. Using the local mentor for now.";
        }
        return answer;
    }

    @Override public String analyzeMaterial(AppContext ctx, String material) {
        String localReport = analyzer.analyze(material, ctx.data.profile.examType);
        if (!onlineEnabled(ctx)) {
            String note = ctx.data.profile.onlineAiEnabled
                    ? "Online AI is enabled in Settings, but OPENAI_API_KEY is missing; this is a local study brief."
                    : "Local analysis is active. Enable optional online AI in Settings for generated tutor-style analysis.";
            return localReport + "\n\n" + note;
        }
        try {
            return online.respond("You are a careful " + ctx.data.profile.examType
                            + " study coach. Analyze only the supplied material. Separate summary, key points, important terms/facts/dates, difficulty, realistic study time, and a short study plan. State when a fact is not present; do not invent it.",
                    "Analyze this uploaded study material:\n\n" + truncate(material, 26000));
        } catch (Exception ex) {
            return localReport + "\n\nOnline analysis was unavailable: " + cleanError(ex) + ". Showing the local study brief.";
        }
    }

    private String localAnswer(AppContext ctx, String message, String material, boolean hasMaterial) {
        String q = message == null ? "" : message.toLowerCase(Locale.ROOT);
        boolean asksAboutFile = q.contains("material") || q.contains("document") || q.contains("file")
                || q.contains("notes") || q.contains("summar") || q.contains("define") || q.contains("explain this");
        if (hasMaterial && asksAboutFile) return analyzer.answerFromMaterial(material, message);
        return local.reply(ctx, message);
    }

    private static boolean onlineEnabled(AppContext ctx) {
        return ctx.data.profile.onlineAiEnabled && hasApiKey();
    }

    private static boolean hasApiKey() {
        String key = System.getenv("OPENAI_API_KEY");
        return key != null && !key.isBlank();
    }

    private static String instructions(AppContext ctx) {
        return "You are Study-Wise, a supportive " + ctx.data.profile.examType + " learning coach. Be concise and practical. "
                + "Use the student's saved mastery and planner information below. Do not claim an answer is based on their data unless it appears here. "
                + "For exam current affairs, do not invent recent facts; ask for a source if none is supplied.\n\n" + learnerSummary(ctx);
    }

    private static String learnerSummary(AppContext ctx) {
        StringBuilder out = new StringBuilder("Learner: ").append(ctx.data.profile.name)
                .append("; exam: ").append(ctx.data.profile.examType).append(".\n");
        KnowledgeTopic weakest = ctx.data.knowledge.values().stream().min(Comparator.comparingInt(k -> k.mastery)).orElse(null);
        if (weakest != null) out.append("Lowest mastery: ").append(weakest.subject).append(" / ").append(weakest.topic)
                .append(" at ").append(weakest.mastery).append("%.\n");
        StudyTask next = ctx.planner.nextTask(ctx.data);
        if (next != null) out.append("Next planner task: ").append(next.label()).append(" ( ").append(next.minutes).append(" min).\n");
        out.append("Recent conversation:\n");
        int from = Math.max(0, ctx.data.mentorChat.size() - 8);
        for (int i = from; i < ctx.data.mentorChat.size(); i++) {
            ChatMessage m = ctx.data.mentorChat.get(i);
            out.append(m.role).append(": ").append(truncate(m.text, 500)).append('\n');
        }
        return out.toString();
    }

    private static String chatInput(AppContext ctx, String message, String material) {
        StringBuilder out = new StringBuilder();
        if (material != null && !material.isBlank()) out.append("Current uploaded material:\n").append(truncate(material, 22000)).append("\n\n");
        out.append("Student's latest message:\n").append(message == null ? "" : message);
        return out.toString();
    }

    private static String truncate(String value, int max) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return value.substring(0, max) + "\n[content shortened for the AI request]";
    }

    private static String cleanError(Exception ex) {
        String message = ex.getMessage();
        return message == null ? ex.getClass().getSimpleName() : message.replaceAll("[\\r\\n]+", " ");
    }
}
