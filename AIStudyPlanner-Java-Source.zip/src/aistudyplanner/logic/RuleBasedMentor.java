package aistudyplanner.logic;

import aistudyplanner.AppContext;
import aistudyplanner.model.KnowledgeTopic;
import aistudyplanner.model.StudyTask;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Keyword-matched mentor that answers only from this learner's saved local records. */
public final class RuleBasedMentor implements AiProvider {
    @Override
    public String reply(AppContext ctx, String message) {
        String q = message == null ? "" : message.trim().toLowerCase(Locale.ROOT);
        if (q.isBlank()) return "Tell me what you want help with: your next task, a topic, a lighter week, or your progress.";
        if (q.contains("weak") || q.contains("struggle") || q.contains("hard")) return topicReply(ctx, message);
        if ((q.contains("lighter") || q.contains("lighten") || q.contains("less")) && (q.contains("week") || q.contains("plan"))) {
            int changed = 0;
            LocalDate end = LocalDate.now().plusDays(7);
            for (StudyTask task : ctx.data.tasks) {
                if (!task.done && !StudyTask.MANUAL.equals(task.kind) && !task.day.isBefore(LocalDate.now()) && !task.day.isAfter(end)) {
                    task.minutes = Math.max(15, (int) Math.round(task.minutes * 0.75)); changed++;
                }
            }
            ctx.saveQuietly();
            return changed == 0 ? "I couldn't find generated study blocks for the next seven days to adjust. Create a plan first."
                    : "I made the next seven days lighter by trimming generated study blocks by about 25% (minimum 15 minutes each). "
                    + changed + " blocks changed. Your manual tasks stayed as you set them.";
        }
        if (q.contains("study now") || q.contains("next task") || q.contains("what should i study") || q.contains("recommend")) {
            StudyTask task = ctx.planner.nextTask(ctx.data);
            if (task == null) return "There are no due tasks in your planner right now. Add a task or generate a study plan.";
            KnowledgeTopic state = ctx.knowledge.getOrCreate(ctx.data, task.subject, task.topic);
            return "Start with " + task.subject + " — " + task.topic + " for " + task.minutes + " minutes (" + task.kind + "). "
                    + "Current mastery estimate: " + state.mastery + "%. Next review: " + state.nextReview + ".";
        }
        if (q.contains("progress") || q.contains("how am i") || q.contains("explain")) return progress(ctx);
        return "I can help with a weak topic, a lighter week, your next study task, or your progress. I use your saved planner and quiz records; I don't send your data online.";
    }

    private String topicReply(AppContext ctx, String input) {
        String q = input.toLowerCase(Locale.ROOT);
        List<KnowledgeTopic> matches = new ArrayList<>();
        for (KnowledgeTopic state : ctx.data.knowledge.values())
            if (q.contains(state.subject.toLowerCase(Locale.ROOT)) || q.contains(state.topic.toLowerCase(Locale.ROOT))) matches.add(state);
        matches.sort(Comparator.comparingInt(s -> s.mastery));
        if (matches.isEmpty()) return "I don't have quiz-based knowledge data matching that topic yet. Add it under Subjects and take a quiz so I can estimate mastery.";
        KnowledgeTopic state = matches.get(0);
        return state.subject + " / " + state.topic + " is at an estimated " + state.mastery + "% mastery, based on "
                + state.attempts + " quiz answer(s). Confidence estimate: " + Math.round(state.confidence * 100)
                + "%. Next review: " + state.nextReview + ". I'd schedule a short retrieval practice block.";
    }

    private String progress(AppContext ctx) {
        int questions = ctx.data.quizAttempts.size();
        int correct = (int) ctx.data.quizAttempts.stream().filter(a -> a.correct).count();
        int minutes = ctx.data.minutesStudiedOn(LocalDate.now());
        int avg = ctx.data.knowledge.isEmpty() ? 0 : (int) Math.round(ctx.data.knowledge.values().stream().mapToInt(k -> k.mastery).average().orElse(0));
        KnowledgeTopic weakest = ctx.data.knowledge.values().stream().min(Comparator.comparingInt(k -> k.mastery)).orElse(null);
        String weakestText = weakest == null ? "No topic quiz history yet." : "Your lowest current estimate is " + weakest.subject + " / " + weakest.topic + " at " + weakest.mastery + "% (" + weakest.nextReview + " review).";
        return "Today's focused study: " + minutes + " minutes. Quiz accuracy: " + correct + "/" + questions
                + (questions == 0 ? " (no answers recorded yet)" : " (" + Math.round(100.0 * correct / questions) + "%).")
                + (avg == 0 ? "" : " Average topic mastery estimate: " + avg + "%. ") + weakestText;
    }
}
